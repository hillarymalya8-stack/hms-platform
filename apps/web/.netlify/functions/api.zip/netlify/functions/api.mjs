
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);

var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __require = /* @__PURE__ */ ((x) => typeof require !== "undefined" ? require : typeof Proxy !== "undefined" ? new Proxy(x, {
  get: (a, b) => (typeof require !== "undefined" ? require : a)[b]
}) : x)(function(x) {
  if (typeof require !== "undefined") return require.apply(this, arguments);
  throw Error('Dynamic require of "' + x + '" is not supported');
});
var __commonJS = (cb, mod) => function __require2() {
  try {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  } catch (e) {
    throw mod = 0, e;
  }
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// apps/api/dist/common/auth/current-user.decorator.js
var require_current_user_decorator = __commonJS({
  "apps/api/dist/common/auth/current-user.decorator.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.CurrentUser = void 0;
    var common_1 = __require("@nestjs/common");
    exports.CurrentUser = (0, common_1.createParamDecorator)((_data, context) => {
      const request = context.switchToHttp().getRequest();
      return request.user;
    });
  }
});

// apps/api/dist/common/auth/require-permissions.decorator.js
var require_require_permissions_decorator = __commonJS({
  "apps/api/dist/common/auth/require-permissions.decorator.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.RequirePermissions = exports.PERMISSIONS_KEY = void 0;
    var common_1 = __require("@nestjs/common");
    exports.PERMISSIONS_KEY = "permissions";
    var RequirePermissions = (...permissions) => (0, common_1.SetMetadata)(exports.PERMISSIONS_KEY, permissions);
    exports.RequirePermissions = RequirePermissions;
  }
});

// apps/api/dist/modules/audit/audit-query.dto.js
var require_audit_query_dto = __commonJS({
  "apps/api/dist/modules/audit/audit-query.dto.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = exports && exports.__metadata || function(k, v) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.AuditQueryDto = void 0;
    var class_validator_1 = __require("class-validator");
    var AuditQueryDto = class {
      page;
      pageSize;
      userId;
      from;
      to;
      itemId;
      action;
      module;
      q;
    };
    exports.AuditQueryDto = AuditQueryDto;
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.Matches)(/^\d{1,6}$/),
      __metadata("design:type", String)
    ], AuditQueryDto.prototype, "page", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.Matches)(/^\d{1,3}$/),
      __metadata("design:type", String)
    ], AuditQueryDto.prototype, "pageSize", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsUUID)(),
      __metadata("design:type", String)
    ], AuditQueryDto.prototype, "userId", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsString)(),
      (0, class_validator_1.MaxLength)(40),
      __metadata("design:type", String)
    ], AuditQueryDto.prototype, "from", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsString)(),
      (0, class_validator_1.MaxLength)(40),
      __metadata("design:type", String)
    ], AuditQueryDto.prototype, "to", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsUUID)(),
      __metadata("design:type", String)
    ], AuditQueryDto.prototype, "itemId", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsString)(),
      (0, class_validator_1.MaxLength)(80),
      __metadata("design:type", String)
    ], AuditQueryDto.prototype, "action", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsString)(),
      (0, class_validator_1.MaxLength)(40),
      __metadata("design:type", String)
    ], AuditQueryDto.prototype, "module", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsString)(),
      (0, class_validator_1.MaxLength)(120),
      __metadata("design:type", String)
    ], AuditQueryDto.prototype, "q", void 0);
  }
});

// apps/api/dist/common/prisma/prisma.service.js
var require_prisma_service = __commonJS({
  "apps/api/dist/common/prisma/prisma.service.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.PrismaService = void 0;
    var common_1 = __require("@nestjs/common");
    var client_1 = __require("@prisma/client");
    var PrismaService = class PrismaService extends client_1.PrismaClient {
      async onModuleDestroy() {
        await this.$disconnect();
      }
    };
    exports.PrismaService = PrismaService;
    exports.PrismaService = PrismaService = __decorate([
      (0, common_1.Injectable)()
    ], PrismaService);
  }
});

// apps/api/dist/modules/audit/audit-labels.js
var require_audit_labels = __commonJS({
  "apps/api/dist/modules/audit/audit-labels.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.auditActionLabel = auditActionLabel;
    exports.describeAuditTarget = describeAuditTarget;
    var labels = {
      "pos.create_order": "Sale created",
      "pos.take_payment": "Payment collected",
      "pos.edit_order": "Order edited",
      "pos.void_order": "Order voided",
      "inventory.stock_receipt": "Stock received",
      "inventory.stock_issue": "Stock issued",
      "inventory.stock_transfer": "Stock transferred",
      "inventory.stock_adjustment": "Stock adjusted",
      "inventory.sale_deduction": "Stock deducted by sale",
      "inventory.sale_return": "Stock returned (order edit/void)",
      "inventory.purchase_receipt": "Stock received (purchase order)",
      "inventory.item_created": "Item created",
      "inventory.item_updated": "Item edited",
      "purchasing.receive_purchase_order": "Purchase order received"
    };
    function auditActionLabel(module2, action) {
      const known = labels[`${module2}.${action}`];
      if (known)
        return known;
      const text = action.replaceAll("_", " ").replaceAll(".", " ");
      return text.charAt(0).toUpperCase() + text.slice(1);
    }
    function describeAuditTarget(recordType, recordId, newValue, previousValue, resolved) {
      if (recordId && resolved.has(recordId)) {
        return resolved.get(recordId);
      }
      const value = pickObject(newValue) ?? pickObject(previousValue) ?? {};
      const text = (key) => typeof value[key] === "string" && value[key] ? String(value[key]) : null;
      const named = text("orderNumber") ?? text("systemReceiptNumber") ?? text("reservationNumber") ?? text("entryNumber") ?? text("invoiceNumber") ?? text("itemName") ?? text("name") ?? text("fullName") ?? text("email");
      const type = recordType.replaceAll("_", " ");
      const typeLabel = type.charAt(0).toUpperCase() + type.slice(1);
      if (named)
        return `${typeLabel} ${named}`;
      return recordId ? `${typeLabel} ${recordId.slice(0, 8)}` : typeLabel;
    }
    function pickObject(value) {
      return value && typeof value === "object" && !Array.isArray(value) ? value : null;
    }
  }
});

// apps/api/dist/modules/audit/audit.service.js
var require_audit_service = __commonJS({
  "apps/api/dist/modules/audit/audit.service.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = exports && exports.__metadata || function(k, v) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.AuditService = void 0;
    exports.auditData = auditData;
    exports.parseDateBoundary = parseDateBoundary;
    var common_1 = __require("@nestjs/common");
    var prisma_service_1 = require_prisma_service();
    var audit_labels_1 = require_audit_labels();
    var MAX_PAGE_SIZE = 100;
    var UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
    var AuditService = class AuditService {
      prisma;
      constructor(prisma) {
        this.prisma = prisma;
      }
      // Pass a transaction client to keep the audit entry in the same transaction as the change.
      record(input, client = this.prisma) {
        return client.auditLog.create({ data: auditData(input) });
      }
      listRecent(organizationId, propertyId) {
        return this.prisma.auditLog.findMany({
          where: {
            organizationId,
            OR: propertyId ? [{ propertyId }, { propertyId: null }] : void 0
          },
          orderBy: {
            createdAt: "desc"
          },
          take: 100
        });
      }
      // Searchable, paginated audit trail. Read-only: there is no API to edit or delete entries,
      // and the database rejects UPDATE/DELETE on audit_logs.
      async search(user, filters) {
        const page = clampInt(filters.page, 1, 1, 1e5);
        const pageSize = clampInt(filters.pageSize, 25, 1, MAX_PAGE_SIZE);
        const where = this.buildWhere(user, filters);
        const [total, rows] = await Promise.all([
          this.prisma.auditLog.count({ where }),
          this.prisma.auditLog.findMany({
            where,
            include: { user: { select: { id: true, fullName: true, status: true } } },
            orderBy: [{ createdAt: "desc" }, { id: "desc" }],
            skip: (page - 1) * pageSize,
            take: pageSize
          })
        ]);
        const names = await this.resolveRecordNames(rows);
        return {
          page,
          pageSize,
          total,
          totalPages: Math.max(1, Math.ceil(total / pageSize)),
          entries: rows.map((row) => {
            const staffName = row.actorName ?? row.user?.fullName ?? null;
            return {
              id: row.id,
              createdAt: row.createdAt.toISOString(),
              module: row.module,
              action: row.action,
              actionLabel: (0, audit_labels_1.auditActionLabel)(row.module, row.action),
              recordType: row.recordType,
              recordId: row.recordId,
              staff: {
                userId: row.userId,
                // null means the old entry has no reliable staff information ("Not recorded").
                name: staffName,
                disabled: row.user ? row.user.status !== "ACTIVE" : false
              },
              itemId: row.itemId,
              itemName: row.itemName ?? (row.recordType === "inventory_item" && row.recordId ? names.get(row.recordId) ?? null : null),
              target: (0, audit_labels_1.describeAuditTarget)(row.recordType, row.recordId, row.newValue, row.previousValue, names),
              summary: row.summary,
              previousValue: row.previousValue,
              newValue: row.newValue
            };
          })
        };
      }
      // Options for the audit trail filters. Disabled staff stay listed so their history can be found.
      async filterOptions(user) {
        const [users, actions, items] = await Promise.all([
          this.prisma.user.findMany({
            where: { organizationId: user.organizationId },
            select: { id: true, fullName: true, status: true },
            orderBy: { fullName: "asc" }
          }),
          this.prisma.auditLog.groupBy({
            by: ["module", "action"],
            where: this.scopeWhere(user),
            orderBy: [{ module: "asc" }, { action: "asc" }]
          }),
          user.propertyId ? this.prisma.inventoryItem.findMany({
            where: { propertyId: user.propertyId },
            select: { id: true, name: true, sku: true, active: true },
            orderBy: { name: "asc" }
          }) : Promise.resolve([])
        ]);
        return {
          staff: users.map((entry) => ({ id: entry.id, name: entry.fullName, disabled: entry.status !== "ACTIVE" })),
          actions: actions.map((entry) => ({
            module: entry.module,
            action: entry.action,
            label: (0, audit_labels_1.auditActionLabel)(entry.module, entry.action)
          })),
          items: items.map((item) => ({ id: item.id, name: item.name, sku: item.sku, active: item.active }))
        };
      }
      scopeWhere(user) {
        return {
          organizationId: user.organizationId,
          OR: user.propertyId ? [{ propertyId: user.propertyId }, { propertyId: null }] : void 0
        };
      }
      buildWhere(user, filters) {
        const and = [this.scopeWhere(user)];
        if (filters.userId) {
          if (!UUID.test(filters.userId))
            throw new common_1.BadRequestException("Choose a valid staff member.");
          and.push({ userId: filters.userId });
        }
        if (filters.itemId) {
          if (!UUID.test(filters.itemId))
            throw new common_1.BadRequestException("Choose a valid item.");
          and.push({ OR: [{ itemId: filters.itemId }, { recordType: "inventory_item", recordId: filters.itemId }] });
        }
        if (filters.action) {
          and.push({ action: filters.action.trim() });
        }
        if (filters.module) {
          and.push({ module: filters.module.trim() });
        }
        const from = parseDateBoundary(filters.from, "start");
        const to = parseDateBoundary(filters.to, "end");
        if (from && to && from >= to) {
          throw new common_1.BadRequestException("The start date must be before the end date.");
        }
        if (from || to) {
          and.push({ createdAt: { ...from ? { gte: from } : {}, ...to ? { lt: to } : {} } });
        }
        const q = filters.q?.trim();
        if (q) {
          const contains = { contains: q.slice(0, 120), mode: "insensitive" };
          and.push({
            OR: [
              { actorName: contains },
              { itemName: contains },
              { summary: contains },
              { action: contains },
              { module: contains },
              { recordType: contains },
              { recordId: contains },
              { user: { fullName: contains } }
            ]
          });
        }
        return { AND: and };
      }
      // Looks up readable names for older entries that only stored a record id.
      async resolveRecordNames(rows) {
        const idsByType = /* @__PURE__ */ new Map();
        for (const row of rows) {
          if (!row.recordId || !UUID.test(row.recordId))
            continue;
          const list = idsByType.get(row.recordType) ?? [];
          list.push(row.recordId);
          idsByType.set(row.recordType, list);
        }
        const names = /* @__PURE__ */ new Map();
        const ids = (type) => idsByType.get(type) ?? [];
        const [orders, payments, items, users, purchaseOrders, reservations] = await Promise.all([
          ids("pos_order").length ? this.prisma.posOrder.findMany({ where: { id: { in: ids("pos_order") } }, select: { id: true, orderNumber: true } }) : [],
          ids("payment").length ? this.prisma.payment.findMany({
            where: { id: { in: ids("payment") } },
            select: { id: true, systemReceiptNumber: true, order: { select: { orderNumber: true } } }
          }) : [],
          ids("inventory_item").length ? this.prisma.inventoryItem.findMany({ where: { id: { in: ids("inventory_item") } }, select: { id: true, name: true } }) : [],
          ids("user").length ? this.prisma.user.findMany({ where: { id: { in: ids("user") } }, select: { id: true, fullName: true } }) : [],
          ids("purchase_order").length ? this.prisma.purchaseOrder.findMany({ where: { id: { in: ids("purchase_order") } }, select: { id: true, orderNumber: true } }) : [],
          ids("reservation").length ? this.prisma.reservation.findMany({ where: { id: { in: ids("reservation") } }, select: { id: true, reservationNumber: true } }) : []
        ]);
        for (const order of orders)
          names.set(order.id, `Order ${order.orderNumber}`);
        for (const payment of payments) {
          names.set(payment.id, `Receipt ${payment.systemReceiptNumber}${payment.order ? ` (${payment.order.orderNumber})` : ""}`);
        }
        for (const item of items)
          names.set(item.id, item.name);
        for (const entry of users)
          names.set(entry.id, `Staff account ${entry.fullName}`);
        for (const order of purchaseOrders)
          names.set(order.id, `Purchase order ${order.orderNumber}`);
        for (const reservation of reservations)
          names.set(reservation.id, `Reservation ${reservation.reservationNumber}`);
        return names;
      }
    };
    exports.AuditService = AuditService;
    exports.AuditService = AuditService = __decorate([
      (0, common_1.Injectable)(),
      __metadata("design:paramtypes", [prisma_service_1.PrismaService])
    ], AuditService);
    function auditData(input) {
      return {
        organizationId: input.organizationId,
        propertyId: input.propertyId,
        userId: input.userId,
        actorName: input.actorName ?? void 0,
        module: input.module,
        action: input.action,
        recordType: input.recordType,
        recordId: input.recordId,
        itemId: input.itemId ?? void 0,
        itemName: input.itemName ?? void 0,
        summary: input.summary ?? void 0,
        previousValue: input.previousValue,
        newValue: input.newValue,
        ipAddress: input.ipAddress,
        userAgent: input.userAgent
      };
    }
    function clampInt(value, fallback, min, max) {
      const parsed = Number.parseInt(value ?? "", 10);
      if (!Number.isFinite(parsed))
        return fallback;
      return Math.min(max, Math.max(min, parsed));
    }
    function parseDateBoundary(value, edge) {
      if (!value?.trim())
        return void 0;
      const text = value.trim();
      const dateOnly = /^\d{4}-\d{2}-\d{2}$/.test(text);
      const date = new Date(dateOnly ? `${text}T00:00:00.000Z` : text);
      if (Number.isNaN(date.getTime())) {
        throw new common_1.BadRequestException("Dates must be valid, for example 2026-11-04.");
      }
      if (dateOnly && edge === "end") {
        date.setUTCDate(date.getUTCDate() + 1);
      }
      return date;
    }
  }
});

// apps/api/dist/modules/audit/audit.controller.js
var require_audit_controller = __commonJS({
  "apps/api/dist/modules/audit/audit.controller.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = exports && exports.__metadata || function(k, v) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var __param = exports && exports.__param || function(paramIndex, decorator) {
      return function(target, key) {
        decorator(target, key, paramIndex);
      };
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.AuditController = void 0;
    var common_1 = __require("@nestjs/common");
    var current_user_decorator_1 = require_current_user_decorator();
    var require_permissions_decorator_1 = require_require_permissions_decorator();
    var audit_query_dto_1 = require_audit_query_dto();
    var audit_service_1 = require_audit_service();
    var AuditController = class AuditController {
      audit;
      constructor(audit) {
        this.audit = audit;
      }
      search(user, filters) {
        return this.audit.search(user, filters ?? {});
      }
      filterOptions(user) {
        return this.audit.filterOptions(user);
      }
    };
    exports.AuditController = AuditController;
    __decorate([
      (0, require_permissions_decorator_1.RequirePermissions)("audit.view"),
      (0, common_1.Get)(),
      __param(0, (0, current_user_decorator_1.CurrentUser)()),
      __param(1, (0, common_1.Query)()),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", [Object, audit_query_dto_1.AuditQueryDto]),
      __metadata("design:returntype", void 0)
    ], AuditController.prototype, "search", null);
    __decorate([
      (0, require_permissions_decorator_1.RequirePermissions)("audit.view"),
      (0, common_1.Get)("filters"),
      __param(0, (0, current_user_decorator_1.CurrentUser)()),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", [Object]),
      __metadata("design:returntype", void 0)
    ], AuditController.prototype, "filterOptions", null);
    exports.AuditController = AuditController = __decorate([
      (0, common_1.Controller)("audit"),
      __metadata("design:paramtypes", [audit_service_1.AuditService])
    ], AuditController);
  }
});

// apps/api/dist/modules/audit/audit.module.js
var require_audit_module = __commonJS({
  "apps/api/dist/modules/audit/audit.module.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.AuditModule = void 0;
    var common_1 = __require("@nestjs/common");
    var audit_controller_1 = require_audit_controller();
    var audit_service_1 = require_audit_service();
    var AuditModule = class AuditModule {
    };
    exports.AuditModule = AuditModule;
    exports.AuditModule = AuditModule = __decorate([
      (0, common_1.Module)({
        controllers: [audit_controller_1.AuditController],
        providers: [audit_service_1.AuditService],
        exports: [audit_service_1.AuditService]
      })
    ], AuditModule);
  }
});

// apps/api/dist/modules/accounting/journal-balancer.js
var require_journal_balancer = __commonJS({
  "apps/api/dist/modules/accounting/journal-balancer.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.JournalValidationError = void 0;
    exports.validateBalancedJournal = validateBalancedJournal;
    var client_1 = __require("@prisma/client");
    var JournalValidationError = class extends Error {
      constructor(message) {
        super(message);
        this.name = "JournalValidationError";
      }
    };
    exports.JournalValidationError = JournalValidationError;
    function validateBalancedJournal(lines) {
      if (lines.length < 2) {
        throw new JournalValidationError("A journal entry must have at least two lines.");
      }
      let totalDebit = new client_1.Prisma.Decimal(0);
      let totalCredit = new client_1.Prisma.Decimal(0);
      for (const [index, line] of lines.entries()) {
        const debit = toMoneyDecimal(line.debitAmount ?? "0", `lines.${index}.debitAmount`);
        const credit = toMoneyDecimal(line.creditAmount ?? "0", `lines.${index}.creditAmount`);
        if (debit.isNegative() || credit.isNegative()) {
          throw new JournalValidationError("Journal amounts cannot be negative.");
        }
        if (debit.gt(0) && credit.gt(0)) {
          throw new JournalValidationError("A journal line cannot contain both debit and credit amounts.");
        }
        if (debit.eq(0) && credit.eq(0)) {
          throw new JournalValidationError("A journal line must contain either a debit or a credit amount.");
        }
        totalDebit = totalDebit.plus(debit);
        totalCredit = totalCredit.plus(credit);
      }
      if (!totalDebit.eq(totalCredit)) {
        throw new JournalValidationError(`Journal entry is not balanced. Debits ${totalDebit.toFixed(4)} do not equal credits ${totalCredit.toFixed(4)}.`);
      }
      return {
        balanced: true,
        totalDebit: totalDebit.toFixed(4),
        totalCredit: totalCredit.toFixed(4),
        lineCount: lines.length
      };
    }
    function toMoneyDecimal(value, fieldName) {
      if (typeof value === "number" && !Number.isInteger(value)) {
        throw new JournalValidationError(`${fieldName} must be sent as a decimal string, not a floating point number.`);
      }
      try {
        return new client_1.Prisma.Decimal(value);
      } catch {
        throw new JournalValidationError(`${fieldName} is not a valid decimal amount.`);
      }
    }
  }
});

// apps/api/dist/modules/accounting/accounting.service.js
var require_accounting_service = __commonJS({
  "apps/api/dist/modules/accounting/accounting.service.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = exports && exports.__metadata || function(k, v) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.AccountingService = void 0;
    var common_1 = __require("@nestjs/common");
    var client_1 = __require("@prisma/client");
    var prisma_service_1 = require_prisma_service();
    var audit_service_1 = require_audit_service();
    var journal_balancer_1 = require_journal_balancer();
    var MANUAL_SOURCE_TYPE = "MANUAL";
    var OPEN_BUSINESS_DATE_STATUSES = [client_1.BusinessDateStatus.OPEN, client_1.BusinessDateStatus.REOPENED];
    var LEDGER_STATUSES = [client_1.JournalStatus.POSTED, client_1.JournalStatus.REVERSED];
    var journalInclude = {
      lines: {
        include: {
          account: {
            select: { id: true, accountCode: true, accountName: true, accountType: true }
          }
        },
        orderBy: { createdAt: "asc" }
      },
      financialPeriod: {
        select: { id: true, startDate: true, endDate: true, status: true }
      }
    };
    var AccountingService = class AccountingService {
      audit;
      prisma;
      constructor(audit, prisma) {
        this.audit = audit;
        this.prisma = prisma;
      }
      // ---------------------------------------------------------------------------
      // Chart of accounts
      // ---------------------------------------------------------------------------
      listAccounts(user) {
        return this.prisma.account.findMany({
          where: this.accountScope(user),
          orderBy: [{ accountCode: "asc" }]
        });
      }
      async createAccount(user, dto) {
        const accountCode = dto.accountCode.trim();
        const accountName = dto.accountName.trim();
        if (!accountCode || !accountName) {
          throw new common_1.BadRequestException("Account code and account name are required.");
        }
        const existing = await this.prisma.account.findFirst({
          where: {
            organizationId: user.organizationId,
            propertyId: user.propertyId ?? null,
            accountCode
          }
        });
        if (existing) {
          throw new common_1.ConflictException("An account with this code already exists for this property.");
        }
        if (dto.parentId) {
          const parent = await this.prisma.account.findFirst({
            where: { id: dto.parentId, ...this.accountScope(user) }
          });
          if (!parent) {
            throw new common_1.BadRequestException("The parent account was not found.");
          }
        }
        const account = await this.prisma.account.create({
          data: {
            organizationId: user.organizationId,
            propertyId: user.propertyId,
            parentId: dto.parentId,
            accountCode,
            accountName,
            accountType: dto.accountType,
            isControlAccount: dto.isControlAccount ?? false
          }
        });
        await this.audit.record({
          organizationId: user.organizationId,
          propertyId: user.propertyId,
          userId: user.userId,
          module: "accounting",
          action: "create_account",
          recordType: "account",
          recordId: account.id,
          newValue: {
            accountCode: account.accountCode,
            accountName: account.accountName,
            accountType: account.accountType,
            isControlAccount: account.isControlAccount
          }
        });
        return account;
      }
      validateJournal(dto) {
        return this.assertBalanced(dto.lines);
      }
      // ---------------------------------------------------------------------------
      // Trial balance
      // ---------------------------------------------------------------------------
      async trialBalance(user, from, to) {
        const propertyId = this.requireProperty(user);
        const fromDate = from ? parseDateOnly(from, "from") : void 0;
        const toDate = to ? parseDateOnly(to, "to") : void 0;
        if (fromDate && toDate && fromDate > toDate) {
          throw new common_1.BadRequestException("The start date must be on or before the end date.");
        }
        const toExclusive = toDate ? addDays(toDate, 1) : void 0;
        const grouped = await this.prisma.journalLine.groupBy({
          by: ["accountId"],
          where: {
            journalEntry: {
              propertyId,
              status: { in: LEDGER_STATUSES },
              postedAt: fromDate || toExclusive ? { gte: fromDate, lt: toExclusive } : void 0
            }
          },
          _sum: { debitAmount: true, creditAmount: true }
        });
        const accounts = grouped.length ? await this.prisma.account.findMany({
          where: { id: { in: grouped.map((row) => row.accountId) } },
          select: { id: true, accountCode: true, accountName: true, accountType: true }
        }) : [];
        const accountById = new Map(accounts.map((account) => [account.id, account]));
        let totalDebit = new client_1.Prisma.Decimal(0);
        let totalCredit = new client_1.Prisma.Decimal(0);
        let balanceDebit = new client_1.Prisma.Decimal(0);
        let balanceCredit = new client_1.Prisma.Decimal(0);
        const rows = grouped.map((row) => {
          const account = accountById.get(row.accountId);
          const debit = row._sum.debitAmount ?? new client_1.Prisma.Decimal(0);
          const credit = row._sum.creditAmount ?? new client_1.Prisma.Decimal(0);
          const net = debit.minus(credit);
          const debitBalance = net.gt(0) ? net : new client_1.Prisma.Decimal(0);
          const creditBalance = net.lt(0) ? net.negated() : new client_1.Prisma.Decimal(0);
          totalDebit = totalDebit.plus(debit);
          totalCredit = totalCredit.plus(credit);
          balanceDebit = balanceDebit.plus(debitBalance);
          balanceCredit = balanceCredit.plus(creditBalance);
          return {
            accountId: row.accountId,
            accountCode: account?.accountCode ?? "",
            accountName: account?.accountName ?? "Unknown account",
            accountType: account?.accountType ?? null,
            totalDebit: money(debit),
            totalCredit: money(credit),
            debitBalance: money(debitBalance),
            creditBalance: money(creditBalance)
          };
        }).sort((a, b) => a.accountCode.localeCompare(b.accountCode));
        return {
          from: fromDate ? isoDate(fromDate) : null,
          to: toDate ? isoDate(toDate) : null,
          generatedAt: (/* @__PURE__ */ new Date()).toISOString(),
          rows,
          totals: {
            totalDebit: money(totalDebit),
            totalCredit: money(totalCredit),
            debitBalance: money(balanceDebit),
            creditBalance: money(balanceCredit)
          },
          balanced: totalDebit.eq(totalCredit)
        };
      }
      // ---------------------------------------------------------------------------
      // Journals
      // ---------------------------------------------------------------------------
      async listJournals(user, status, limit) {
        const propertyId = this.requireProperty(user);
        const statusFilter = parseJournalStatus(status);
        const take = Math.min(Math.max(Number.parseInt(limit ?? "", 10) || 50, 1), 200);
        const journals = await this.prisma.journalEntry.findMany({
          where: { propertyId, status: statusFilter },
          include: journalInclude,
          orderBy: [{ createdAt: "desc" }],
          take
        });
        return journals.map(serializeJournal);
      }
      async createJournal(user, dto) {
        const propertyId = this.requireProperty(user);
        const totals = this.assertBalanced(dto.lines);
        const idempotencyKey = dto.idempotencyKey?.trim() || void 0;
        if (idempotencyKey) {
          const existing = await this.prisma.journalEntry.findUnique({
            where: { propertyId_idempotencyKey: { propertyId, idempotencyKey } },
            include: journalInclude
          });
          if (existing) {
            return serializeJournal(existing);
          }
        }
        const codes = [...new Set(dto.lines.map((line) => line.accountCode.trim()))];
        const accounts = await this.prisma.account.findMany({
          where: { ...this.accountScope(user), accountCode: { in: codes } }
        });
        const accountByCode = /* @__PURE__ */ new Map();
        for (const account of accounts) {
          const current = accountByCode.get(account.accountCode);
          if (!current || current.propertyId === null && account.propertyId !== null) {
            accountByCode.set(account.accountCode, account);
          }
        }
        const missing = codes.filter((code) => !accountByCode.has(code));
        if (missing.length) {
          throw new common_1.BadRequestException(`Unknown account code(s): ${missing.join(", ")}.`);
        }
        const inactive = codes.filter((code) => !accountByCode.get(code).active);
        if (inactive.length) {
          throw new common_1.BadRequestException(`Inactive account code(s) cannot be used: ${inactive.join(", ")}.`);
        }
        const memo = dto.memo?.trim() || void 0;
        const reference = dto.reference?.trim() || void 0;
        const businessDate = await this.currentOrInitialBusinessDate(user, propertyId);
        const journal = await this.withEntryNumberRetry(() => this.prisma.$transaction(async (tx) => {
          const period = await this.resolveOpenPeriod(tx, propertyId, businessDate.businessDate);
          const entryNumber = await nextEntryNumber(tx, propertyId, businessDate.businessDate);
          return tx.journalEntry.create({
            data: {
              propertyId,
              financialPeriodId: period.id,
              entryNumber,
              sourceType: MANUAL_SOURCE_TYPE,
              sourceNumber: reference,
              status: client_1.JournalStatus.DRAFT,
              idempotencyKey,
              lines: {
                create: dto.lines.map((line) => ({
                  accountId: accountByCode.get(line.accountCode.trim()).id,
                  debitAmount: new client_1.Prisma.Decimal(line.debitAmount?.trim() || "0"),
                  creditAmount: new client_1.Prisma.Decimal(line.creditAmount?.trim() || "0"),
                  description: line.description?.trim() || memo
                }))
              }
            },
            include: journalInclude
          });
        }));
        await this.audit.record({
          organizationId: user.organizationId,
          propertyId,
          userId: user.userId,
          module: "accounting",
          action: "create_journal",
          recordType: "journal_entry",
          recordId: journal.id,
          newValue: {
            entryNumber: journal.entryNumber,
            status: journal.status,
            reference: reference ?? null,
            memo: memo ?? null,
            businessDate: isoDate(businessDate.businessDate),
            totalDebit: totals.totalDebit,
            totalCredit: totals.totalCredit,
            lineCount: totals.lineCount
          }
        });
        return serializeJournal(journal);
      }
      async postJournal(user, journalId) {
        const propertyId = this.requireProperty(user);
        const journal = await this.prisma.journalEntry.findFirst({
          where: { id: journalId, propertyId },
          include: journalInclude
        });
        if (!journal) {
          throw new common_1.NotFoundException("Journal entry not found.");
        }
        if (journal.status !== client_1.JournalStatus.DRAFT) {
          throw new common_1.ConflictException(`Only draft journals can be posted. This journal is ${journal.status.toLowerCase()}.`);
        }
        if (journal.financialPeriod.status !== client_1.FinancialPeriodStatus.OPEN) {
          throw new common_1.ConflictException("The financial period for this journal is closed. Reopen it before posting.");
        }
        this.assertBalanced(journal.lines.map((line) => ({
          accountCode: line.account.accountCode,
          debitAmount: line.debitAmount.toString(),
          creditAmount: line.creditAmount.toString()
        })));
        const postedAt = /* @__PURE__ */ new Date();
        const updated = await this.prisma.journalEntry.updateMany({
          where: { id: journal.id, propertyId, status: client_1.JournalStatus.DRAFT },
          data: { status: client_1.JournalStatus.POSTED, postedAt }
        });
        if (updated.count === 0) {
          throw new common_1.ConflictException("This journal was already posted by someone else.");
        }
        const posted = await this.prisma.journalEntry.findUniqueOrThrow({
          where: { id: journal.id },
          include: journalInclude
        });
        await this.audit.record({
          organizationId: user.organizationId,
          propertyId,
          userId: user.userId,
          module: "accounting",
          action: "post_journal",
          recordType: "journal_entry",
          recordId: journal.id,
          previousValue: { status: journal.status },
          newValue: {
            entryNumber: posted.entryNumber,
            status: posted.status,
            postedAt: postedAt.toISOString()
          }
        });
        return serializeJournal(posted);
      }
      // ---------------------------------------------------------------------------
      // Business date
      // ---------------------------------------------------------------------------
      async getBusinessDate(user) {
        const propertyId = this.requireProperty(user);
        const current = await this.currentOrInitialBusinessDate(user, propertyId);
        const [history, draftJournalCount] = await Promise.all([
          this.prisma.businessDate.findMany({
            where: { propertyId },
            include: businessDateInclude,
            orderBy: { businessDate: "desc" },
            take: 10
          }),
          this.prisma.journalEntry.count({ where: { propertyId, status: client_1.JournalStatus.DRAFT } })
        ]);
        return {
          current: serializeBusinessDate(current),
          draftJournalCount,
          history: history.map(serializeBusinessDate)
        };
      }
      async closeBusinessDate(user, dto) {
        const propertyId = this.requireProperty(user);
        const result = await this.prisma.$transaction(async (tx) => {
          const current = await tx.businessDate.findFirst({
            where: { propertyId, status: { in: OPEN_BUSINESS_DATE_STATUSES } },
            orderBy: { businessDate: "desc" }
          });
          if (!current) {
            throw new common_1.ConflictException("There is no open business date to close.");
          }
          if (!dto.allowDraftJournals) {
            const drafts = await tx.journalEntry.count({ where: { propertyId, status: client_1.JournalStatus.DRAFT } });
            if (drafts > 0) {
              throw new common_1.ConflictException(`${drafts} draft journal${drafts === 1 ? " is" : "s are"} waiting to be posted. Post them before closing the business date.`);
            }
          }
          const closedAt = /* @__PURE__ */ new Date();
          const closed = await tx.businessDate.updateMany({
            where: { id: current.id, status: { in: OPEN_BUSINESS_DATE_STATUSES } },
            data: { status: client_1.BusinessDateStatus.CLOSED, closedAt, closedById: user.userId }
          });
          if (closed.count === 0) {
            throw new common_1.ConflictException("This business date was already closed.");
          }
          const nextDate = addDays(current.businessDate, 1);
          const existingNext = await tx.businessDate.findUnique({
            where: { propertyId_businessDate: { propertyId, businessDate: nextDate } }
          });
          let next;
          if (existingNext) {
            if (existingNext.status === client_1.BusinessDateStatus.CLOSED) {
              throw new common_1.ConflictException(`${isoDate(nextDate)} is already closed. Reopen it before closing ${isoDate(current.businessDate)}.`);
            }
            next = existingNext;
          } else {
            next = await tx.businessDate.create({
              data: {
                propertyId,
                businessDate: nextDate,
                status: client_1.BusinessDateStatus.OPEN,
                openedById: user.userId,
                openedAt: closedAt
              }
            });
          }
          return { closedId: current.id, closedDate: current.businessDate, nextId: next.id };
        });
        const [closedRecord, openRecord] = await Promise.all([
          this.prisma.businessDate.findUniqueOrThrow({ where: { id: result.closedId }, include: businessDateInclude }),
          this.prisma.businessDate.findUniqueOrThrow({ where: { id: result.nextId }, include: businessDateInclude })
        ]);
        await this.audit.record({
          organizationId: user.organizationId,
          propertyId,
          userId: user.userId,
          module: "accounting",
          action: "close_business_date",
          recordType: "business_date",
          recordId: result.closedId,
          previousValue: { businessDate: isoDate(result.closedDate), status: "OPEN" },
          newValue: {
            businessDate: isoDate(result.closedDate),
            status: client_1.BusinessDateStatus.CLOSED,
            nextBusinessDate: isoDate(openRecord.businessDate),
            allowDraftJournals: Boolean(dto.allowDraftJournals)
          }
        });
        return {
          closed: serializeBusinessDate(closedRecord),
          current: serializeBusinessDate(openRecord)
        };
      }
      // ---------------------------------------------------------------------------
      // Helpers
      // ---------------------------------------------------------------------------
      accountScope(user) {
        return {
          organizationId: user.organizationId,
          OR: user.propertyId ? [{ propertyId: user.propertyId }, { propertyId: null }] : void 0
        };
      }
      requireProperty(user) {
        if (!user.propertyId) {
          throw new common_1.BadRequestException("A property context is required.");
        }
        return user.propertyId;
      }
      assertBalanced(lines) {
        try {
          return (0, journal_balancer_1.validateBalancedJournal)(lines);
        } catch (error) {
          if (error instanceof journal_balancer_1.JournalValidationError) {
            throw new common_1.BadRequestException(error.message);
          }
          throw error;
        }
      }
      /**
       * Returns the property's open business date. A property that has never had a business date
       * gets one opened for today so finance work can start; this is recorded in the audit log.
       */
      async currentOrInitialBusinessDate(user, propertyId) {
        const current = await this.prisma.businessDate.findFirst({
          where: { propertyId, status: { in: OPEN_BUSINESS_DATE_STATUSES } },
          include: businessDateInclude,
          orderBy: { businessDate: "desc" }
        });
        if (current) {
          return current;
        }
        const anyDate = await this.prisma.businessDate.findFirst({
          where: { propertyId },
          orderBy: { businessDate: "desc" }
        });
        if (anyDate) {
          throw new common_1.ConflictException(`No business date is open. The last business date (${isoDate(anyDate.businessDate)}) is closed and must be reopened.`);
        }
        const today = parseDateOnly((/* @__PURE__ */ new Date()).toISOString().slice(0, 10), "date");
        const created = await this.prisma.businessDate.upsert({
          where: { propertyId_businessDate: { propertyId, businessDate: today } },
          update: {},
          create: { propertyId, businessDate: today, status: client_1.BusinessDateStatus.OPEN, openedById: user.userId },
          include: businessDateInclude
        });
        await this.audit.record({
          organizationId: user.organizationId,
          propertyId,
          userId: user.userId,
          module: "accounting",
          action: "open_business_date",
          recordType: "business_date",
          recordId: created.id,
          newValue: { businessDate: isoDate(created.businessDate), status: created.status }
        });
        return created;
      }
      /** Finds the financial period that contains the date, opening a calendar-month period when none exists. */
      async resolveOpenPeriod(tx, propertyId, date) {
        const period = await tx.financialPeriod.findFirst({
          where: { propertyId, startDate: { lte: date }, endDate: { gte: date } },
          orderBy: { startDate: "desc" }
        });
        if (period) {
          if (period.status !== client_1.FinancialPeriodStatus.OPEN) {
            throw new common_1.ConflictException(`The financial period ${isoDate(period.startDate)} to ${isoDate(period.endDate)} is ${period.status.toLowerCase()}.`);
          }
          return period;
        }
        const startDate = new Date(Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), 1));
        const endDate = new Date(Date.UTC(date.getUTCFullYear(), date.getUTCMonth() + 1, 0));
        return tx.financialPeriod.upsert({
          where: { propertyId_startDate_endDate: { propertyId, startDate, endDate } },
          update: {},
          create: { propertyId, startDate, endDate, status: client_1.FinancialPeriodStatus.OPEN }
        });
      }
      async withEntryNumberRetry(work) {
        for (let attempt = 0; ; attempt += 1) {
          try {
            return await work();
          } catch (error) {
            const isUniqueClash = error instanceof client_1.Prisma.PrismaClientKnownRequestError && error.code === "P2002" && String(error.meta?.target ?? "").includes("entry_number");
            if (!isUniqueClash || attempt >= 2) {
              throw error;
            }
          }
        }
      }
    };
    exports.AccountingService = AccountingService;
    exports.AccountingService = AccountingService = __decorate([
      (0, common_1.Injectable)(),
      __metadata("design:paramtypes", [
        audit_service_1.AuditService,
        prisma_service_1.PrismaService
      ])
    ], AccountingService);
    var businessDateInclude = {
      openedBy: { select: { id: true, fullName: true } },
      closedBy: { select: { id: true, fullName: true } }
    };
    function serializeBusinessDate(record) {
      return {
        id: record.id,
        businessDate: isoDate(record.businessDate),
        status: record.status,
        openedAt: record.openedAt.toISOString(),
        openedBy: record.openedBy?.fullName ?? null,
        closedAt: record.closedAt?.toISOString() ?? null,
        closedBy: record.closedBy?.fullName ?? null
      };
    }
    function serializeJournal(journal) {
      const totalDebit = journal.lines.reduce((sum, line) => sum.plus(line.debitAmount), new client_1.Prisma.Decimal(0));
      const totalCredit = journal.lines.reduce((sum, line) => sum.plus(line.creditAmount), new client_1.Prisma.Decimal(0));
      return {
        id: journal.id,
        entryNumber: journal.entryNumber,
        sourceType: journal.sourceType,
        sourceId: journal.sourceId,
        sourceNumber: journal.sourceNumber,
        status: journal.status,
        description: journal.lines.find((line) => line.description)?.description ?? null,
        createdAt: journal.createdAt.toISOString(),
        postedAt: journal.postedAt?.toISOString() ?? null,
        financialPeriod: {
          id: journal.financialPeriod.id,
          startDate: isoDate(journal.financialPeriod.startDate),
          endDate: isoDate(journal.financialPeriod.endDate),
          status: journal.financialPeriod.status
        },
        totalDebit: money(totalDebit),
        totalCredit: money(totalCredit),
        lines: journal.lines.map((line) => ({
          id: line.id,
          accountId: line.accountId,
          accountCode: line.account.accountCode,
          accountName: line.account.accountName,
          accountType: line.account.accountType,
          debitAmount: money(line.debitAmount),
          creditAmount: money(line.creditAmount),
          description: line.description
        }))
      };
    }
    async function nextEntryNumber(tx, propertyId, date) {
      const prefix = `JE-${date.getUTCFullYear()}-`;
      const latest = await tx.journalEntry.findFirst({
        where: { propertyId, entryNumber: { startsWith: prefix } },
        orderBy: { entryNumber: "desc" },
        select: { entryNumber: true }
      });
      const lastSequence = latest ? Number.parseInt(latest.entryNumber.slice(prefix.length), 10) || 0 : 0;
      return `${prefix}${String(lastSequence + 1).padStart(5, "0")}`;
    }
    function parseJournalStatus(value) {
      if (!value || value.toUpperCase() === "ALL")
        return void 0;
      const status = value.toUpperCase();
      if (!Object.values(client_1.JournalStatus).includes(status)) {
        throw new common_1.BadRequestException(`Unknown journal status "${value}".`);
      }
      return status;
    }
    function parseDateOnly(value, fieldName) {
      const datePart = value.slice(0, 10);
      if (!/^\d{4}-\d{2}-\d{2}$/.test(datePart)) {
        throw new common_1.BadRequestException(`${fieldName} must be a date in YYYY-MM-DD format.`);
      }
      const date = /* @__PURE__ */ new Date(`${datePart}T00:00:00.000Z`);
      if (Number.isNaN(date.getTime())) {
        throw new common_1.BadRequestException(`${fieldName} is not a valid date.`);
      }
      return date;
    }
    function addDays(date, days) {
      const next = new Date(date);
      next.setUTCDate(next.getUTCDate() + days);
      return next;
    }
    function isoDate(date) {
      return date.toISOString().slice(0, 10);
    }
    function money(value) {
      return value.toFixed(2);
    }
  }
});

// apps/api/dist/modules/front-office/day-expenses.service.js
var require_day_expenses_service = __commonJS({
  "apps/api/dist/modules/front-office/day-expenses.service.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = exports && exports.__metadata || function(k, v) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.DayExpensesService = void 0;
    exports.serializeExpense = serializeExpense;
    exports.totalsByCurrency = totalsByCurrency;
    exports.parseDay = parseDay;
    exports.isoDay = isoDay;
    var common_1 = __require("@nestjs/common");
    var client_1 = __require("@prisma/client");
    var prisma_service_1 = require_prisma_service();
    var DayExpensesService = class DayExpensesService {
      prisma;
      constructor(prisma) {
        this.prisma = prisma;
      }
      async list(user, date) {
        const propertyId = requireProperty(user);
        const expenseDate = parseDay(date);
        const rows = await this.prisma.frontOfficeExpense.findMany({
          where: { propertyId, expenseDate },
          orderBy: { createdAt: "asc" }
        });
        return { date: isoDay(expenseDate), expenses: rows.map(serializeExpense), totals: totalsByCurrency(rows) };
      }
      async create(user, dto) {
        const propertyId = requireProperty(user);
        const amount = new client_1.Prisma.Decimal(dto.amount);
        if (amount.lte(0))
          throw new common_1.BadRequestException("Enter an amount greater than zero.");
        const description = dto.description.trim();
        if (description.length < 2)
          throw new common_1.BadRequestException("Describe what the money was spent on.");
        const expense = await this.prisma.frontOfficeExpense.create({
          data: {
            propertyId,
            expenseDate: parseDay(dto.date),
            description,
            amount,
            currencyCode: dto.currencyCode ?? "TZS",
            paidBy: dto.paidBy?.trim() || null,
            recordedByUserId: user.userId,
            recordedByName: user.fullName
          }
        });
        await this.audit(user, "record_day_expense", expense.id, `Recorded day expense "${description}" (${expense.currencyCode} ${amount.toFixed(2)}).`);
        return serializeExpense(expense);
      }
      async void(user, id) {
        const propertyId = requireProperty(user);
        const expense = await this.prisma.frontOfficeExpense.findFirst({ where: { id, propertyId } });
        if (!expense)
          throw new common_1.NotFoundException("Expense not found.");
        if (expense.voidedAt)
          return serializeExpense(expense);
        const updated = await this.prisma.frontOfficeExpense.update({
          where: { id },
          data: { voidedAt: /* @__PURE__ */ new Date(), voidedByUserId: user.userId, voidedByName: user.fullName }
        });
        await this.audit(user, "remove_day_expense", id, `Removed day expense "${expense.description}" (${expense.currencyCode} ${expense.amount.toFixed(2)}), recorded by ${expense.recordedByName ?? "Not recorded"}.`);
        return serializeExpense(updated);
      }
      async audit(user, action, recordId, summary) {
        await this.prisma.auditLog.create({
          data: {
            organizationId: user.organizationId,
            propertyId: user.propertyId,
            userId: user.userId,
            actorName: user.fullName,
            module: "front_office",
            action,
            recordType: "front_office_expense",
            recordId,
            summary
          }
        });
      }
    };
    exports.DayExpensesService = DayExpensesService;
    exports.DayExpensesService = DayExpensesService = __decorate([
      (0, common_1.Injectable)(),
      __metadata("design:paramtypes", [prisma_service_1.PrismaService])
    ], DayExpensesService);
    function serializeExpense(row) {
      return {
        id: row.id,
        date: isoDay(row.expenseDate),
        description: row.description,
        amount: row.amount.toFixed(2),
        currencyCode: row.currencyCode,
        paidBy: row.paidBy,
        recordedBy: row.recordedByName ?? "Not recorded",
        createdAt: row.createdAt,
        voided: Boolean(row.voidedAt),
        voidedBy: row.voidedAt ? row.voidedByName ?? "Not recorded" : null
      };
    }
    function totalsByCurrency(rows) {
      const totals = /* @__PURE__ */ new Map();
      for (const row of rows) {
        if (row.voidedAt)
          continue;
        totals.set(row.currencyCode, (totals.get(row.currencyCode) ?? new client_1.Prisma.Decimal(0)).plus(row.amount));
      }
      return [...totals.entries()].map(([currencyCode, amount]) => ({ currencyCode, amount: amount.toFixed(2) }));
    }
    function parseDay(value) {
      const datePart = value?.slice(0, 10) || (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
      const date = /* @__PURE__ */ new Date(`${datePart}T00:00:00.000Z`);
      if (Number.isNaN(date.getTime()))
        throw new common_1.BadRequestException("Date is invalid.");
      return date;
    }
    function isoDay(value) {
      return value.toISOString().slice(0, 10);
    }
    function requireProperty(user) {
      if (!user.propertyId)
        throw new common_1.BadRequestException("A property context is required.");
      return user.propertyId;
    }
  }
});

// apps/api/dist/modules/accounting/day-sales.service.js
var require_day_sales_service = __commonJS({
  "apps/api/dist/modules/accounting/day-sales.service.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = exports && exports.__metadata || function(k, v) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.DaySalesService = void 0;
    var common_1 = __require("@nestjs/common");
    var client_1 = __require("@prisma/client");
    var prisma_service_1 = require_prisma_service();
    var day_expenses_service_1 = require_day_expenses_service();
    var DaySalesService = class DaySalesService {
      prisma;
      constructor(prisma) {
        this.prisma = prisma;
      }
      async daySales(user, date) {
        if (!user.propertyId)
          throw new common_1.BadRequestException("A property context is required.");
        const propertyId = user.propertyId;
        const day = (0, day_expenses_service_1.parseDay)(date);
        const next = new Date(day);
        next.setUTCDate(next.getUTCDate() + 1);
        const inDay = { gte: day, lt: next };
        const [folioItems, folioPayments, orders, posPayments, expenses] = await Promise.all([
          this.prisma.folioItem.findMany({
            where: {
              postedAt: inDay,
              folio: { propertyId },
              OR: [
                { itemType: client_1.FolioItemType.ROOM_CHARGE },
                { itemType: client_1.FolioItemType.OTHER, sourceType: "FRONT_OFFICE" },
                { itemType: client_1.FolioItemType.DEPOSIT, sourceType: "PREPAID_BOOKING" }
              ]
            },
            include: { folio: { include: folioInclude } },
            orderBy: { postedAt: "asc" }
          }),
          this.prisma.payment.findMany({
            where: { propertyId, sourceType: "FOLIO", status: client_1.PaymentStatus.COMPLETED, createdAt: inDay },
            orderBy: { createdAt: "asc" }
          }),
          this.prisma.posOrder.findMany({
            where: { propertyId, createdAt: inDay, status: { not: client_1.PosOrderStatus.VOID } },
            include: { outlet: true },
            orderBy: { createdAt: "asc" }
          }),
          this.prisma.payment.findMany({
            where: { propertyId, orderId: { not: null }, status: client_1.PaymentStatus.COMPLETED, createdAt: inDay },
            include: { order: { select: { currencyCode: true, status: true, orderNumber: true } } }
          }),
          this.prisma.frontOfficeExpense.findMany({
            where: { propertyId, expenseDate: day },
            orderBy: { createdAt: "asc" }
          })
        ]);
        const folioIds = [...new Set(folioPayments.map((payment) => payment.sourceId))];
        const folios = folioIds.length ? await this.prisma.folio.findMany({ where: { id: { in: folioIds } }, include: folioInclude }) : [];
        const folioById = new Map(folios.map((folio) => [folio.id, folio]));
        const roomCharges = /* @__PURE__ */ new Map();
        const prepaid = /* @__PURE__ */ new Map();
        const roomRows = folioItems.map((item) => {
          const currency = stayCurrency(item.folio);
          add(item.itemType === client_1.FolioItemType.DEPOSIT ? prepaid : roomCharges, currency, item.totalAmount);
          return {
            type: item.itemType === client_1.FolioItemType.DEPOSIT ? "PREPAID" : "CHARGE",
            description: item.description,
            room: item.folio.reservation.reservationRooms.map((entry) => entry.room?.roomNumber).filter(Boolean).join(", "),
            guest: guestName(item.folio.reservation.primaryGuest),
            reservationNumber: item.folio.reservation.reservationNumber,
            amount: money(item.totalAmount),
            currencyCode: currency,
            postedAt: item.postedAt
          };
        });
        const roomCollected = /* @__PURE__ */ new Map();
        const roomByMethod = /* @__PURE__ */ new Map();
        for (const payment of folioPayments) {
          const folio = folioById.get(payment.sourceId);
          const currency = folio ? stayCurrency(folio) : "TZS";
          add(roomCollected, currency, payment.amount);
          addMethod(roomByMethod, payment.paymentMethod, currency, payment.amount);
        }
        const posSales = /* @__PURE__ */ new Map();
        const outlets = /* @__PURE__ */ new Map();
        for (const order of orders) {
          add(posSales, order.currencyCode, order.grandTotal);
          const outlet = outlets.get(order.outlet.name) ?? { orders: 0, totals: /* @__PURE__ */ new Map() };
          outlet.orders += 1;
          add(outlet.totals, order.currencyCode, order.grandTotal);
          outlets.set(order.outlet.name, outlet);
        }
        const posCollected = /* @__PURE__ */ new Map();
        const posToRooms = /* @__PURE__ */ new Map();
        const posByMethod = /* @__PURE__ */ new Map();
        for (const payment of posPayments) {
          if (!payment.order || payment.order.status === client_1.PosOrderStatus.VOID)
            continue;
          const currency = payment.order.currencyCode;
          if (payment.paymentMethod === client_1.PaymentMethod.ROOM_CHARGE) {
            add(posToRooms, currency, payment.amount);
            continue;
          }
          add(posCollected, currency, payment.amount);
          addMethod(posByMethod, payment.paymentMethod, currency, payment.amount);
        }
        const expenseTotals = (0, day_expenses_service_1.totalsByCurrency)(expenses);
        const expenseBucket = new Map(expenseTotals.map((row) => [row.currencyCode, new client_1.Prisma.Decimal(row.amount)]));
        const cashIn = /* @__PURE__ */ new Map();
        for (const method of [roomByMethod.get(client_1.PaymentMethod.CASH), posByMethod.get(client_1.PaymentMethod.CASH)]) {
          for (const [currency, amount] of method ?? [])
            add(cashIn, currency, amount);
        }
        const currencies = [
          ...new Set([roomCharges, prepaid, roomCollected, posSales, posCollected, expenseBucket].flatMap((bucket) => [...bucket.keys()]))
        ].sort((a, b) => a === "TZS" ? -1 : b === "TZS" ? 1 : a.localeCompare(b));
        if (!currencies.length)
          currencies.push("TZS");
        const totals = currencies.map((currencyCode) => {
          const sales = get(roomCharges, currencyCode).plus(get(posSales, currencyCode));
          const collected = get(roomCollected, currencyCode).plus(get(prepaid, currencyCode)).plus(get(posCollected, currencyCode));
          const spent = get(expenseBucket, currencyCode);
          return {
            currencyCode,
            roomSales: money(get(roomCharges, currencyCode)),
            roomCollected: money(get(roomCollected, currencyCode)),
            prepaidBookings: money(get(prepaid, currencyCode)),
            posSales: money(get(posSales, currencyCode)),
            posCollected: money(get(posCollected, currencyCode)),
            posChargedToRooms: money(get(posToRooms, currencyCode)),
            totalSales: money(sales),
            totalCollected: money(collected),
            expenses: money(spent),
            netAfterExpenses: money(collected.minus(spent)),
            cashCollected: money(get(cashIn, currencyCode)),
            cashAfterExpenses: money(get(cashIn, currencyCode).minus(spent))
          };
        });
        return {
          date: (0, day_expenses_service_1.isoDay)(day),
          generatedAt: (/* @__PURE__ */ new Date()).toISOString(),
          totals,
          rooms: {
            rows: roomRows,
            paymentCount: folioPayments.length,
            byMethod: methodRows(roomByMethod)
          },
          pos: {
            orderCount: orders.length,
            byOutlet: [...outlets.entries()].map(([name, outlet]) => ({
              name,
              orders: outlet.orders,
              totals: bucketRows(outlet.totals)
            })),
            byMethod: methodRows(posByMethod)
          },
          expenses: {
            rows: expenses.map(day_expenses_service_1.serializeExpense),
            totals: expenseTotals
          }
        };
      }
    };
    exports.DaySalesService = DaySalesService;
    exports.DaySalesService = DaySalesService = __decorate([
      (0, common_1.Injectable)(),
      __metadata("design:paramtypes", [prisma_service_1.PrismaService])
    ], DaySalesService);
    var folioInclude = {
      reservation: {
        include: {
          primaryGuest: true,
          reservationRooms: { include: { room: true } }
        }
      }
    };
    function stayCurrency(folio) {
      return folio.reservation.reservationRooms[0]?.currencyCode ?? "TZS";
    }
    function guestName(guest) {
      return `${guest.firstName} ${guest.lastName}`.trim();
    }
    function add(bucket, currency, amount) {
      bucket.set(currency, get(bucket, currency).plus(amount));
    }
    function get(bucket, currency) {
      return bucket.get(currency) ?? new client_1.Prisma.Decimal(0);
    }
    function addMethod(methods, method, currency, amount) {
      const bucket = methods.get(method) ?? /* @__PURE__ */ new Map();
      add(bucket, currency, amount);
      methods.set(method, bucket);
    }
    function bucketRows(bucket) {
      return [...bucket.entries()].map(([currencyCode, amount]) => ({ currencyCode, amount: money(amount) }));
    }
    function methodRows(methods) {
      return [...methods.entries()].map(([method, bucket]) => ({ method, totals: bucketRows(bucket) }));
    }
    function money(value) {
      return value.toFixed(2);
    }
  }
});

// apps/api/dist/modules/accounting/dto/close-business-date.dto.js
var require_close_business_date_dto = __commonJS({
  "apps/api/dist/modules/accounting/dto/close-business-date.dto.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = exports && exports.__metadata || function(k, v) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.CloseBusinessDateDto = void 0;
    var class_validator_1 = __require("class-validator");
    var CloseBusinessDateDto = class {
      /** When true, the close proceeds even if draft journals are still waiting to be posted. */
      allowDraftJournals;
    };
    exports.CloseBusinessDateDto = CloseBusinessDateDto;
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsBoolean)(),
      __metadata("design:type", Boolean)
    ], CloseBusinessDateDto.prototype, "allowDraftJournals", void 0);
  }
});

// apps/api/dist/modules/accounting/dto/create-account.dto.js
var require_create_account_dto = __commonJS({
  "apps/api/dist/modules/accounting/dto/create-account.dto.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = exports && exports.__metadata || function(k, v) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.CreateAccountDto = void 0;
    var client_1 = __require("@prisma/client");
    var class_validator_1 = __require("class-validator");
    var CreateAccountDto = class {
      accountCode;
      accountName;
      accountType;
      parentId;
      isControlAccount;
    };
    exports.CreateAccountDto = CreateAccountDto;
    __decorate([
      (0, class_validator_1.IsString)(),
      (0, class_validator_1.MaxLength)(20),
      __metadata("design:type", String)
    ], CreateAccountDto.prototype, "accountCode", void 0);
    __decorate([
      (0, class_validator_1.IsString)(),
      (0, class_validator_1.MaxLength)(160),
      __metadata("design:type", String)
    ], CreateAccountDto.prototype, "accountName", void 0);
    __decorate([
      (0, class_validator_1.IsEnum)(client_1.AccountType),
      __metadata("design:type", String)
    ], CreateAccountDto.prototype, "accountType", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsString)(),
      __metadata("design:type", String)
    ], CreateAccountDto.prototype, "parentId", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsBoolean)(),
      __metadata("design:type", Boolean)
    ], CreateAccountDto.prototype, "isControlAccount", void 0);
  }
});

// apps/api/dist/modules/accounting/dto/validate-journal.dto.js
var require_validate_journal_dto = __commonJS({
  "apps/api/dist/modules/accounting/dto/validate-journal.dto.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = exports && exports.__metadata || function(k, v) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.ValidateJournalDto = exports.ValidateJournalLineDto = void 0;
    var class_transformer_1 = __require("class-transformer");
    var class_validator_1 = __require("class-validator");
    var ValidateJournalLineDto = class {
      accountCode;
      debitAmount;
      creditAmount;
      description;
    };
    exports.ValidateJournalLineDto = ValidateJournalLineDto;
    __decorate([
      (0, class_validator_1.IsString)(),
      __metadata("design:type", String)
    ], ValidateJournalLineDto.prototype, "accountCode", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsString)(),
      __metadata("design:type", String)
    ], ValidateJournalLineDto.prototype, "debitAmount", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsString)(),
      __metadata("design:type", String)
    ], ValidateJournalLineDto.prototype, "creditAmount", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsString)(),
      __metadata("design:type", String)
    ], ValidateJournalLineDto.prototype, "description", void 0);
    var ValidateJournalDto = class {
      lines;
    };
    exports.ValidateJournalDto = ValidateJournalDto;
    __decorate([
      (0, class_validator_1.IsArray)(),
      (0, class_validator_1.ArrayMinSize)(2),
      (0, class_validator_1.ValidateNested)({ each: true }),
      (0, class_transformer_1.Type)(() => ValidateJournalLineDto),
      __metadata("design:type", Array)
    ], ValidateJournalDto.prototype, "lines", void 0);
  }
});

// apps/api/dist/modules/accounting/dto/create-journal.dto.js
var require_create_journal_dto = __commonJS({
  "apps/api/dist/modules/accounting/dto/create-journal.dto.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = exports && exports.__metadata || function(k, v) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.CreateJournalDto = void 0;
    var class_transformer_1 = __require("class-transformer");
    var class_validator_1 = __require("class-validator");
    var validate_journal_dto_1 = require_validate_journal_dto();
    var CreateJournalDto = class {
      reference;
      memo;
      idempotencyKey;
      lines;
    };
    exports.CreateJournalDto = CreateJournalDto;
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsString)(),
      (0, class_validator_1.MaxLength)(80),
      __metadata("design:type", String)
    ], CreateJournalDto.prototype, "reference", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsString)(),
      (0, class_validator_1.MaxLength)(240),
      __metadata("design:type", String)
    ], CreateJournalDto.prototype, "memo", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsString)(),
      (0, class_validator_1.MaxLength)(120),
      __metadata("design:type", String)
    ], CreateJournalDto.prototype, "idempotencyKey", void 0);
    __decorate([
      (0, class_validator_1.IsArray)(),
      (0, class_validator_1.ArrayMinSize)(2),
      (0, class_validator_1.ValidateNested)({ each: true }),
      (0, class_transformer_1.Type)(() => validate_journal_dto_1.ValidateJournalLineDto),
      __metadata("design:type", Array)
    ], CreateJournalDto.prototype, "lines", void 0);
  }
});

// apps/api/dist/modules/accounting/accounting.controller.js
var require_accounting_controller = __commonJS({
  "apps/api/dist/modules/accounting/accounting.controller.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = exports && exports.__metadata || function(k, v) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var __param = exports && exports.__param || function(paramIndex, decorator) {
      return function(target, key) {
        decorator(target, key, paramIndex);
      };
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.AccountingController = void 0;
    var common_1 = __require("@nestjs/common");
    var current_user_decorator_1 = require_current_user_decorator();
    var require_permissions_decorator_1 = require_require_permissions_decorator();
    var accounting_service_1 = require_accounting_service();
    var day_sales_service_1 = require_day_sales_service();
    var close_business_date_dto_1 = require_close_business_date_dto();
    var create_account_dto_1 = require_create_account_dto();
    var create_journal_dto_1 = require_create_journal_dto();
    var validate_journal_dto_1 = require_validate_journal_dto();
    var AccountingController = class AccountingController {
      accounting;
      daySalesService;
      constructor(accounting, daySalesService) {
        this.accounting = accounting;
        this.daySalesService = daySalesService;
      }
      // Room and POS sales, collections and front-office expenses for one day.
      daySales(user, date) {
        return this.daySalesService.daySales(user, date);
      }
      listAccounts(user) {
        return this.accounting.listAccounts(user);
      }
      createAccount(user, dto) {
        return this.accounting.createAccount(user, dto);
      }
      trialBalance(user, from, to) {
        return this.accounting.trialBalance(user, from, to);
      }
      listJournals(user, status, limit) {
        return this.accounting.listJournals(user, status, limit);
      }
      validateJournal(dto) {
        return this.accounting.validateJournal(dto);
      }
      createJournal(user, dto) {
        return this.accounting.createJournal(user, dto);
      }
      postJournal(user, id) {
        return this.accounting.postJournal(user, id);
      }
      businessDate(user) {
        return this.accounting.getBusinessDate(user);
      }
      // Closing the day locks the ledger for that date, so it requires journal posting authority.
      closeBusinessDate(user, dto) {
        return this.accounting.closeBusinessDate(user, dto ?? {});
      }
    };
    exports.AccountingController = AccountingController;
    __decorate([
      (0, require_permissions_decorator_1.RequirePermissions)("accounting.view"),
      (0, common_1.Get)("day-sales"),
      __param(0, (0, current_user_decorator_1.CurrentUser)()),
      __param(1, (0, common_1.Query)("date")),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", [Object, String]),
      __metadata("design:returntype", void 0)
    ], AccountingController.prototype, "daySales", null);
    __decorate([
      (0, require_permissions_decorator_1.RequirePermissions)("accounting.view"),
      (0, common_1.Get)("accounts"),
      __param(0, (0, current_user_decorator_1.CurrentUser)()),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", [Object]),
      __metadata("design:returntype", void 0)
    ], AccountingController.prototype, "listAccounts", null);
    __decorate([
      (0, require_permissions_decorator_1.RequirePermissions)("accounting.accounts.manage"),
      (0, common_1.Post)("accounts"),
      __param(0, (0, current_user_decorator_1.CurrentUser)()),
      __param(1, (0, common_1.Body)()),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", [Object, create_account_dto_1.CreateAccountDto]),
      __metadata("design:returntype", void 0)
    ], AccountingController.prototype, "createAccount", null);
    __decorate([
      (0, require_permissions_decorator_1.RequirePermissions)("accounting.view"),
      (0, common_1.Get)("trial-balance"),
      __param(0, (0, current_user_decorator_1.CurrentUser)()),
      __param(1, (0, common_1.Query)("from")),
      __param(2, (0, common_1.Query)("to")),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", [Object, String, String]),
      __metadata("design:returntype", void 0)
    ], AccountingController.prototype, "trialBalance", null);
    __decorate([
      (0, require_permissions_decorator_1.RequirePermissions)("accounting.view"),
      (0, common_1.Get)("journals"),
      __param(0, (0, current_user_decorator_1.CurrentUser)()),
      __param(1, (0, common_1.Query)("status")),
      __param(2, (0, common_1.Query)("limit")),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", [Object, String, String]),
      __metadata("design:returntype", void 0)
    ], AccountingController.prototype, "listJournals", null);
    __decorate([
      (0, require_permissions_decorator_1.RequirePermissions)("accounting.journals.create"),
      (0, common_1.Post)("journals/validate"),
      __param(0, (0, common_1.Body)()),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", [validate_journal_dto_1.ValidateJournalDto]),
      __metadata("design:returntype", void 0)
    ], AccountingController.prototype, "validateJournal", null);
    __decorate([
      (0, require_permissions_decorator_1.RequirePermissions)("accounting.journals.create"),
      (0, common_1.Post)("journals"),
      __param(0, (0, current_user_decorator_1.CurrentUser)()),
      __param(1, (0, common_1.Body)()),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", [Object, create_journal_dto_1.CreateJournalDto]),
      __metadata("design:returntype", void 0)
    ], AccountingController.prototype, "createJournal", null);
    __decorate([
      (0, require_permissions_decorator_1.RequirePermissions)("accounting.journals.post"),
      (0, common_1.Post)("journals/:id/post"),
      __param(0, (0, current_user_decorator_1.CurrentUser)()),
      __param(1, (0, common_1.Param)("id", new common_1.ParseUUIDPipe())),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", [Object, String]),
      __metadata("design:returntype", void 0)
    ], AccountingController.prototype, "postJournal", null);
    __decorate([
      (0, require_permissions_decorator_1.RequirePermissions)("accounting.view"),
      (0, common_1.Get)("business-date"),
      __param(0, (0, current_user_decorator_1.CurrentUser)()),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", [Object]),
      __metadata("design:returntype", void 0)
    ], AccountingController.prototype, "businessDate", null);
    __decorate([
      (0, require_permissions_decorator_1.RequirePermissions)("accounting.journals.post"),
      (0, common_1.Post)("business-date/close"),
      __param(0, (0, current_user_decorator_1.CurrentUser)()),
      __param(1, (0, common_1.Body)()),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", [Object, close_business_date_dto_1.CloseBusinessDateDto]),
      __metadata("design:returntype", void 0)
    ], AccountingController.prototype, "closeBusinessDate", null);
    exports.AccountingController = AccountingController = __decorate([
      (0, common_1.Controller)("accounting"),
      __metadata("design:paramtypes", [
        accounting_service_1.AccountingService,
        day_sales_service_1.DaySalesService
      ])
    ], AccountingController);
  }
});

// apps/api/dist/modules/accounting/accounting.module.js
var require_accounting_module = __commonJS({
  "apps/api/dist/modules/accounting/accounting.module.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.AccountingModule = void 0;
    var common_1 = __require("@nestjs/common");
    var audit_module_1 = require_audit_module();
    var accounting_controller_1 = require_accounting_controller();
    var accounting_service_1 = require_accounting_service();
    var day_sales_service_1 = require_day_sales_service();
    var AccountingModule = class AccountingModule {
    };
    exports.AccountingModule = AccountingModule;
    exports.AccountingModule = AccountingModule = __decorate([
      (0, common_1.Module)({
        imports: [audit_module_1.AuditModule],
        controllers: [accounting_controller_1.AccountingController],
        providers: [accounting_service_1.AccountingService, day_sales_service_1.DaySalesService],
        exports: [accounting_service_1.AccountingService]
      })
    ], AccountingModule);
  }
});

// apps/api/dist/modules/iam/iam.service.js
var require_iam_service = __commonJS({
  "apps/api/dist/modules/iam/iam.service.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = exports && exports.__metadata || function(k, v) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.IamService = void 0;
    var common_1 = __require("@nestjs/common");
    var prisma_service_1 = require_prisma_service();
    var IamService = class IamService {
      prisma;
      constructor(prisma) {
        this.prisma = prisma;
      }
      async getPermissionCodes(userId, propertyId) {
        const userRoles = await this.prisma.userRole.findMany({
          where: {
            userId,
            OR: propertyId ? [{ propertyId }, { propertyId: null }] : [{ propertyId: null }]
          },
          include: {
            role: {
              include: {
                rolePermissions: {
                  include: {
                    permission: true
                  }
                }
              }
            }
          }
        });
        const permissionCodes = /* @__PURE__ */ new Set();
        for (const userRole of userRoles) {
          for (const rolePermission of userRole.role.rolePermissions) {
            permissionCodes.add(rolePermission.permission.code);
          }
        }
        const userPermissions = await this.prisma.userPermission.findMany({
          where: { userId },
          include: { permission: true }
        });
        for (const userPermission of userPermissions) {
          permissionCodes.add(userPermission.permission.code);
        }
        return [...permissionCodes].sort();
      }
      listPermissions() {
        return this.prisma.permission.findMany({
          orderBy: [{ module: "asc" }, { action: "asc" }]
        });
      }
      listRoles(organizationId, propertyId) {
        return this.prisma.role.findMany({
          where: {
            organizationId,
            OR: propertyId ? [{ propertyId }, { propertyId: null }] : void 0
          },
          include: {
            rolePermissions: {
              include: {
                permission: true
              }
            }
          },
          orderBy: {
            name: "asc"
          }
        });
      }
    };
    exports.IamService = IamService;
    exports.IamService = IamService = __decorate([
      (0, common_1.Injectable)(),
      __metadata("design:paramtypes", [prisma_service_1.PrismaService])
    ], IamService);
  }
});

// apps/api/dist/modules/iam/iam.controller.js
var require_iam_controller = __commonJS({
  "apps/api/dist/modules/iam/iam.controller.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = exports && exports.__metadata || function(k, v) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var __param = exports && exports.__param || function(paramIndex, decorator) {
      return function(target, key) {
        decorator(target, key, paramIndex);
      };
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.IamController = void 0;
    var common_1 = __require("@nestjs/common");
    var current_user_decorator_1 = require_current_user_decorator();
    var require_permissions_decorator_1 = require_require_permissions_decorator();
    var iam_service_1 = require_iam_service();
    var IamController = class IamController {
      iam;
      constructor(iam) {
        this.iam = iam;
      }
      listRoles(user) {
        return this.iam.listRoles(user.organizationId, user.propertyId);
      }
      listPermissions() {
        return this.iam.listPermissions();
      }
    };
    exports.IamController = IamController;
    __decorate([
      (0, require_permissions_decorator_1.RequirePermissions)("roles.view"),
      (0, common_1.Get)("roles"),
      __param(0, (0, current_user_decorator_1.CurrentUser)()),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", [Object]),
      __metadata("design:returntype", void 0)
    ], IamController.prototype, "listRoles", null);
    __decorate([
      (0, require_permissions_decorator_1.RequirePermissions)("roles.view"),
      (0, common_1.Get)("permissions"),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", []),
      __metadata("design:returntype", void 0)
    ], IamController.prototype, "listPermissions", null);
    exports.IamController = IamController = __decorate([
      (0, common_1.Controller)(),
      __metadata("design:paramtypes", [iam_service_1.IamService])
    ], IamController);
  }
});

// apps/api/dist/modules/iam/iam.module.js
var require_iam_module = __commonJS({
  "apps/api/dist/modules/iam/iam.module.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.IamModule = void 0;
    var common_1 = __require("@nestjs/common");
    var iam_controller_1 = require_iam_controller();
    var iam_service_1 = require_iam_service();
    var IamModule = class IamModule {
    };
    exports.IamModule = IamModule;
    exports.IamModule = IamModule = __decorate([
      (0, common_1.Module)({
        controllers: [iam_controller_1.IamController],
        providers: [iam_service_1.IamService],
        exports: [iam_service_1.IamService]
      })
    ], IamModule);
  }
});

// apps/api/dist/common/auth/public.decorator.js
var require_public_decorator = __commonJS({
  "apps/api/dist/common/auth/public.decorator.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.Public = exports.IS_PUBLIC_KEY = void 0;
    var common_1 = __require("@nestjs/common");
    exports.IS_PUBLIC_KEY = "isPublic";
    var Public = () => (0, common_1.SetMetadata)(exports.IS_PUBLIC_KEY, true);
    exports.Public = Public;
  }
});

// apps/api/dist/common/auth/jwt-secret.service.js
var require_jwt_secret_service = __commonJS({
  "apps/api/dist/common/auth/jwt-secret.service.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = exports && exports.__metadata || function(k, v) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.JwtSecretService = void 0;
    var node_crypto_1 = __require("node:crypto");
    var common_1 = __require("@nestjs/common");
    var config_1 = __require("@nestjs/config");
    var prisma_service_1 = require_prisma_service();
    var secretKey = "jwt_secret";
    var JwtSecretService = class JwtSecretService {
      config;
      prisma;
      cached;
      constructor(config2, prisma) {
        this.config = config2;
        this.prisma = prisma;
      }
      getSecret() {
        if (!this.cached) {
          this.cached = this.resolve().catch((error) => {
            this.cached = void 0;
            throw error;
          });
        }
        return this.cached;
      }
      async resolve() {
        const configured = this.config.get("JWT_SECRET")?.trim();
        if (configured && configured.length >= 32)
          return configured;
        const existing = await this.prisma.systemSecret.findUnique({ where: { key: secretKey } });
        if (existing)
          return existing.value;
        await this.prisma.systemSecret.createMany({
          data: [{ key: secretKey, value: (0, node_crypto_1.randomBytes)(48).toString("base64url") }],
          skipDuplicates: true
        });
        const stored = await this.prisma.systemSecret.findUniqueOrThrow({ where: { key: secretKey } });
        return stored.value;
      }
    };
    exports.JwtSecretService = JwtSecretService;
    exports.JwtSecretService = JwtSecretService = __decorate([
      (0, common_1.Injectable)(),
      __metadata("design:paramtypes", [
        config_1.ConfigService,
        prisma_service_1.PrismaService
      ])
    ], JwtSecretService);
  }
});

// apps/api/dist/modules/auth/auth.service.js
var require_auth_service = __commonJS({
  "apps/api/dist/modules/auth/auth.service.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = exports && exports.__metadata || function(k, v) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var __importDefault = exports && exports.__importDefault || function(mod) {
      return mod && mod.__esModule ? mod : { "default": mod };
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.AuthService = void 0;
    var node_crypto_1 = __require("node:crypto");
    var common_1 = __require("@nestjs/common");
    var config_1 = __require("@nestjs/config");
    var bcryptjs_1 = __importDefault(__require("bcryptjs"));
    var jsonwebtoken_1 = __importDefault(__require("jsonwebtoken"));
    var jwt_secret_service_1 = require_jwt_secret_service();
    var prisma_service_1 = require_prisma_service();
    var iam_service_1 = require_iam_service();
    var AuthService = class AuthService {
      config;
      iam;
      jwtSecret;
      prisma;
      constructor(config2, iam, jwtSecret, prisma) {
        this.config = config2;
        this.iam = iam;
        this.jwtSecret = jwtSecret;
        this.prisma = prisma;
      }
      async login(dto, metadata) {
        const identifier = dto.email.trim().toLowerCase();
        const user = await this.prisma.user.findFirst({
          where: { OR: [{ email: identifier }, { username: identifier }] }
        });
        if (!user || user.status !== "ACTIVE") {
          throw new common_1.UnauthorizedException("Invalid username or password.");
        }
        const passwordMatches = await bcryptjs_1.default.compare(dto.password, user.passwordHash);
        if (!passwordMatches) {
          throw new common_1.UnauthorizedException("Invalid username or password.");
        }
        const sessionId = (0, node_crypto_1.randomUUID)();
        const expiresAt = this.resolveExpiry();
        const secret = await this.jwtSecret.getSecret();
        const signOptions = {
          expiresIn: this.config.get("JWT_EXPIRES_IN") ?? "8h"
        };
        const token = jsonwebtoken_1.default.sign({
          sub: user.id,
          sid: sessionId,
          organizationId: user.organizationId,
          email: user.email
        }, secret, signOptions);
        await this.prisma.userSession.create({
          data: {
            id: sessionId,
            userId: user.id,
            tokenHash: (0, node_crypto_1.createHash)("sha256").update(token).digest("hex"),
            expiresAt,
            ipAddress: metadata.ipAddress,
            userAgent: metadata.userAgent
          }
        });
        const permissions = await this.iam.getPermissionCodes(user.id, user.defaultPropertyId ?? void 0);
        await this.prisma.auditLog.create({
          data: {
            organizationId: user.organizationId,
            propertyId: user.defaultPropertyId,
            userId: user.id,
            module: "auth",
            action: "login",
            recordType: "user_session",
            recordId: sessionId,
            ipAddress: metadata.ipAddress,
            userAgent: metadata.userAgent,
            newValue: {
              email: user.email
            }
          }
        });
        return {
          accessToken: token,
          expiresAt,
          user: {
            id: user.id,
            email: user.email,
            username: user.username,
            fullName: user.fullName,
            organizationId: user.organizationId,
            defaultPropertyId: user.defaultPropertyId,
            homePath: user.homePath,
            permissions
          }
        };
      }
      resolveExpiry() {
        const value = this.config.get("JWT_EXPIRES_IN") ?? "8h";
        const match = value.match(/^(\d+)([hm])$/);
        if (!match) {
          return new Date(Date.now() + 8 * 60 * 60 * 1e3);
        }
        const amount = Number(match[1]);
        const unit = match[2];
        const multiplier = unit === "h" ? 60 * 60 * 1e3 : 60 * 1e3;
        return new Date(Date.now() + amount * multiplier);
      }
    };
    exports.AuthService = AuthService;
    exports.AuthService = AuthService = __decorate([
      (0, common_1.Injectable)(),
      __metadata("design:paramtypes", [
        config_1.ConfigService,
        iam_service_1.IamService,
        jwt_secret_service_1.JwtSecretService,
        prisma_service_1.PrismaService
      ])
    ], AuthService);
  }
});

// apps/api/dist/modules/auth/dto/login.dto.js
var require_login_dto = __commonJS({
  "apps/api/dist/modules/auth/dto/login.dto.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = exports && exports.__metadata || function(k, v) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.LoginDto = void 0;
    var class_validator_1 = __require("class-validator");
    var LoginDto = class {
      // Accepts either the staff username or the email address.
      email;
      password;
    };
    exports.LoginDto = LoginDto;
    __decorate([
      (0, class_validator_1.IsString)(),
      (0, class_validator_1.MinLength)(1),
      __metadata("design:type", String)
    ], LoginDto.prototype, "email", void 0);
    __decorate([
      (0, class_validator_1.IsString)(),
      (0, class_validator_1.MinLength)(8),
      __metadata("design:type", String)
    ], LoginDto.prototype, "password", void 0);
  }
});

// apps/api/dist/modules/auth/auth.controller.js
var require_auth_controller = __commonJS({
  "apps/api/dist/modules/auth/auth.controller.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = exports && exports.__metadata || function(k, v) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var __param = exports && exports.__param || function(paramIndex, decorator) {
      return function(target, key) {
        decorator(target, key, paramIndex);
      };
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.AuthController = void 0;
    var common_1 = __require("@nestjs/common");
    var public_decorator_1 = require_public_decorator();
    var auth_service_1 = require_auth_service();
    var login_dto_1 = require_login_dto();
    var AuthController = class AuthController {
      auth;
      constructor(auth) {
        this.auth = auth;
      }
      login(dto, ipAddress, userAgent) {
        return this.auth.login(dto, { ipAddress, userAgent });
      }
    };
    exports.AuthController = AuthController;
    __decorate([
      (0, public_decorator_1.Public)(),
      (0, common_1.Post)("login"),
      __param(0, (0, common_1.Body)()),
      __param(1, (0, common_1.Ip)()),
      __param(2, (0, common_1.Headers)("user-agent")),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", [login_dto_1.LoginDto, String, String]),
      __metadata("design:returntype", void 0)
    ], AuthController.prototype, "login", null);
    exports.AuthController = AuthController = __decorate([
      (0, common_1.Controller)("auth"),
      __metadata("design:paramtypes", [auth_service_1.AuthService])
    ], AuthController);
  }
});

// apps/api/dist/modules/auth/auth.module.js
var require_auth_module = __commonJS({
  "apps/api/dist/modules/auth/auth.module.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.AuthModule = void 0;
    var common_1 = __require("@nestjs/common");
    var iam_module_1 = require_iam_module();
    var auth_controller_1 = require_auth_controller();
    var auth_service_1 = require_auth_service();
    var AuthModule = class AuthModule {
    };
    exports.AuthModule = AuthModule;
    exports.AuthModule = AuthModule = __decorate([
      (0, common_1.Module)({
        imports: [iam_module_1.IamModule],
        controllers: [auth_controller_1.AuthController],
        providers: [auth_service_1.AuthService],
        exports: [auth_service_1.AuthService]
      })
    ], AuthModule);
  }
});

// apps/api/dist/modules/health/health.controller.js
var require_health_controller = __commonJS({
  "apps/api/dist/modules/health/health.controller.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = exports && exports.__metadata || function(k, v) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.HealthController = void 0;
    var common_1 = __require("@nestjs/common");
    var public_decorator_1 = require_public_decorator();
    var prisma_service_1 = require_prisma_service();
    var HealthController = class HealthController {
      prisma;
      constructor(prisma) {
        this.prisma = prisma;
      }
      async check() {
        let database = "connected";
        try {
          await this.prisma.$queryRaw`SELECT 1`;
        } catch {
          database = "unavailable";
        }
        return {
          status: database === "connected" ? "ok" : "degraded",
          service: "hms-api",
          database,
          mode: "production",
          checkedAt: (/* @__PURE__ */ new Date()).toISOString()
        };
      }
    };
    exports.HealthController = HealthController;
    __decorate([
      (0, public_decorator_1.Public)(),
      (0, common_1.Get)(),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", []),
      __metadata("design:returntype", Promise)
    ], HealthController.prototype, "check", null);
    exports.HealthController = HealthController = __decorate([
      (0, common_1.Controller)("health"),
      __metadata("design:paramtypes", [prisma_service_1.PrismaService])
    ], HealthController);
  }
});

// apps/api/dist/modules/health/health.module.js
var require_health_module = __commonJS({
  "apps/api/dist/modules/health/health.module.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.HealthModule = void 0;
    var common_1 = __require("@nestjs/common");
    var health_controller_1 = require_health_controller();
    var HealthModule = class HealthModule {
    };
    exports.HealthModule = HealthModule;
    exports.HealthModule = HealthModule = __decorate([
      (0, common_1.Module)({
        controllers: [health_controller_1.HealthController]
      })
    ], HealthModule);
  }
});

// apps/api/dist/modules/front-office/dto/check-in.dto.js
var require_check_in_dto = __commonJS({
  "apps/api/dist/modules/front-office/dto/check-in.dto.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = exports && exports.__metadata || function(k, v) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.CheckInDto = exports.mealPlans = void 0;
    var class_validator_1 = __require("class-validator");
    exports.mealPlans = ["FULL_BOARD", "HALF_BOARD", "BED_AND_BREAKFAST"];
    var CheckInDto = class {
      mealPlan;
      companyName;
      // Total already paid for the booking, in the stay's currency.
      prepaidAmount;
      paymentReference;
    };
    exports.CheckInDto = CheckInDto;
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsIn)(exports.mealPlans),
      __metadata("design:type", String)
    ], CheckInDto.prototype, "mealPlan", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsString)(),
      (0, class_validator_1.MaxLength)(160),
      __metadata("design:type", String)
    ], CheckInDto.prototype, "companyName", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsString)(),
      __metadata("design:type", String)
    ], CheckInDto.prototype, "prepaidAmount", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsString)(),
      (0, class_validator_1.MaxLength)(120),
      __metadata("design:type", String)
    ], CheckInDto.prototype, "paymentReference", void 0);
  }
});

// apps/api/dist/modules/front-office/dto/create-guest.dto.js
var require_create_guest_dto = __commonJS({
  "apps/api/dist/modules/front-office/dto/create-guest.dto.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = exports && exports.__metadata || function(k, v) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.CreateGuestDto = void 0;
    var class_validator_1 = __require("class-validator");
    var CreateGuestDto = class {
      firstName;
      lastName;
      email;
      phone;
      documentNumber;
    };
    exports.CreateGuestDto = CreateGuestDto;
    __decorate([
      (0, class_validator_1.IsString)(),
      (0, class_validator_1.IsNotEmpty)(),
      (0, class_validator_1.MaxLength)(80),
      __metadata("design:type", String)
    ], CreateGuestDto.prototype, "firstName", void 0);
    __decorate([
      (0, class_validator_1.IsString)(),
      (0, class_validator_1.IsNotEmpty)(),
      (0, class_validator_1.MaxLength)(80),
      __metadata("design:type", String)
    ], CreateGuestDto.prototype, "lastName", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsEmail)(),
      __metadata("design:type", String)
    ], CreateGuestDto.prototype, "email", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsString)(),
      (0, class_validator_1.MaxLength)(40),
      __metadata("design:type", String)
    ], CreateGuestDto.prototype, "phone", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsString)(),
      (0, class_validator_1.MaxLength)(80),
      __metadata("design:type", String)
    ], CreateGuestDto.prototype, "documentNumber", void 0);
  }
});

// apps/api/dist/modules/front-office/dto/create-reservation.dto.js
var require_create_reservation_dto = __commonJS({
  "apps/api/dist/modules/front-office/dto/create-reservation.dto.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = exports && exports.__metadata || function(k, v) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.CreateReservationDto = void 0;
    var class_validator_1 = __require("class-validator");
    var CreateReservationDto = class {
      primaryGuestId;
      roomTypeId;
      roomId;
      arrivalDate;
      departureDate;
      adults;
      children;
      nightlyRate;
      // Currency the stay is sold in; the folio is kept in this currency. Defaults to TZS.
      currencyCode;
      bookingSource;
      notes;
    };
    exports.CreateReservationDto = CreateReservationDto;
    __decorate([
      (0, class_validator_1.IsUUID)(),
      __metadata("design:type", String)
    ], CreateReservationDto.prototype, "primaryGuestId", void 0);
    __decorate([
      (0, class_validator_1.IsUUID)(),
      __metadata("design:type", String)
    ], CreateReservationDto.prototype, "roomTypeId", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsUUID)(),
      __metadata("design:type", String)
    ], CreateReservationDto.prototype, "roomId", void 0);
    __decorate([
      (0, class_validator_1.IsISO8601)(),
      __metadata("design:type", String)
    ], CreateReservationDto.prototype, "arrivalDate", void 0);
    __decorate([
      (0, class_validator_1.IsISO8601)(),
      __metadata("design:type", String)
    ], CreateReservationDto.prototype, "departureDate", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsInt)(),
      (0, class_validator_1.Min)(1),
      __metadata("design:type", Number)
    ], CreateReservationDto.prototype, "adults", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsInt)(),
      (0, class_validator_1.Min)(0),
      __metadata("design:type", Number)
    ], CreateReservationDto.prototype, "children", void 0);
    __decorate([
      (0, class_validator_1.IsNumberString)(),
      __metadata("design:type", String)
    ], CreateReservationDto.prototype, "nightlyRate", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsIn)(["TZS", "USD"]),
      __metadata("design:type", String)
    ], CreateReservationDto.prototype, "currencyCode", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsString)(),
      __metadata("design:type", String)
    ], CreateReservationDto.prototype, "bookingSource", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsString)(),
      __metadata("design:type", String)
    ], CreateReservationDto.prototype, "notes", void 0);
  }
});

// apps/api/dist/modules/front-office/dto/create-room.dto.js
var require_create_room_dto = __commonJS({
  "apps/api/dist/modules/front-office/dto/create-room.dto.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = exports && exports.__metadata || function(k, v) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.CreateRoomDto = void 0;
    var class_validator_1 = __require("class-validator");
    var CreateRoomDto = class {
      roomTypeId;
      floorId;
      roomNumber;
    };
    exports.CreateRoomDto = CreateRoomDto;
    __decorate([
      (0, class_validator_1.IsUUID)(),
      __metadata("design:type", String)
    ], CreateRoomDto.prototype, "roomTypeId", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsUUID)(),
      __metadata("design:type", String)
    ], CreateRoomDto.prototype, "floorId", void 0);
    __decorate([
      (0, class_validator_1.IsString)(),
      (0, class_validator_1.IsNotEmpty)(),
      (0, class_validator_1.MaxLength)(20),
      __metadata("design:type", String)
    ], CreateRoomDto.prototype, "roomNumber", void 0);
  }
});

// apps/api/dist/modules/front-office/dto/create-room-type.dto.js
var require_create_room_type_dto = __commonJS({
  "apps/api/dist/modules/front-office/dto/create-room-type.dto.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = exports && exports.__metadata || function(k, v) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.CreateRoomTypeDto = void 0;
    var class_validator_1 = __require("class-validator");
    var CreateRoomTypeDto = class {
      code;
      name;
      baseOccupancy;
      maxOccupancy;
      // TSh rate per night.
      baseRate;
      // Optional USD rate per night.
      baseRateUsd;
      active;
    };
    exports.CreateRoomTypeDto = CreateRoomTypeDto;
    __decorate([
      (0, class_validator_1.IsString)(),
      (0, class_validator_1.IsNotEmpty)(),
      (0, class_validator_1.MaxLength)(20),
      __metadata("design:type", String)
    ], CreateRoomTypeDto.prototype, "code", void 0);
    __decorate([
      (0, class_validator_1.IsString)(),
      (0, class_validator_1.IsNotEmpty)(),
      (0, class_validator_1.MaxLength)(120),
      __metadata("design:type", String)
    ], CreateRoomTypeDto.prototype, "name", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsInt)(),
      (0, class_validator_1.Min)(1),
      __metadata("design:type", Number)
    ], CreateRoomTypeDto.prototype, "baseOccupancy", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsInt)(),
      (0, class_validator_1.Min)(1),
      __metadata("design:type", Number)
    ], CreateRoomTypeDto.prototype, "maxOccupancy", void 0);
    __decorate([
      (0, class_validator_1.IsNumberString)(),
      __metadata("design:type", String)
    ], CreateRoomTypeDto.prototype, "baseRate", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsNumberString)(),
      __metadata("design:type", String)
    ], CreateRoomTypeDto.prototype, "baseRateUsd", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsBoolean)(),
      __metadata("design:type", Boolean)
    ], CreateRoomTypeDto.prototype, "active", void 0);
  }
});

// apps/api/dist/modules/front-office/dto/extend-stay.dto.js
var require_extend_stay_dto = __commonJS({
  "apps/api/dist/modules/front-office/dto/extend-stay.dto.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = exports && exports.__metadata || function(k, v) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.ExtendStayDto = void 0;
    var class_validator_1 = __require("class-validator");
    var ExtendStayDto = class {
      nights;
      // Optional nightly rate for the extra nights, in the stay's currency. Defaults to the booked rate.
      nightlyRate;
    };
    exports.ExtendStayDto = ExtendStayDto;
    __decorate([
      (0, class_validator_1.IsInt)(),
      (0, class_validator_1.Min)(1),
      (0, class_validator_1.Max)(365),
      __metadata("design:type", Number)
    ], ExtendStayDto.prototype, "nights", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsNumberString)(),
      __metadata("design:type", String)
    ], ExtendStayDto.prototype, "nightlyRate", void 0);
  }
});

// apps/api/dist/modules/front-office/dto/post-room-charge.dto.js
var require_post_room_charge_dto = __commonJS({
  "apps/api/dist/modules/front-office/dto/post-room-charge.dto.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = exports && exports.__metadata || function(k, v) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.PostRoomChargeDto = void 0;
    var class_validator_1 = __require("class-validator");
    var PostRoomChargeDto = class {
      description;
      amount;
      quantity;
    };
    exports.PostRoomChargeDto = PostRoomChargeDto;
    __decorate([
      (0, class_validator_1.IsString)(),
      (0, class_validator_1.MaxLength)(160),
      __metadata("design:type", String)
    ], PostRoomChargeDto.prototype, "description", void 0);
    __decorate([
      (0, class_validator_1.IsNumberString)(),
      __metadata("design:type", String)
    ], PostRoomChargeDto.prototype, "amount", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsNumberString)(),
      __metadata("design:type", String)
    ], PostRoomChargeDto.prototype, "quantity", void 0);
  }
});

// apps/api/dist/modules/front-office/dto/settle-folio-payment.dto.js
var require_settle_folio_payment_dto = __commonJS({
  "apps/api/dist/modules/front-office/dto/settle-folio-payment.dto.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = exports && exports.__metadata || function(k, v) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.SettleFolioPaymentDto = void 0;
    var client_1 = __require("@prisma/client");
    var class_validator_1 = __require("class-validator");
    var SettleFolioPaymentDto = class {
      paymentMethod;
      amount;
      paymentProvider;
      externalReceiptNumber;
    };
    exports.SettleFolioPaymentDto = SettleFolioPaymentDto;
    __decorate([
      (0, class_validator_1.IsEnum)(client_1.PaymentMethod),
      __metadata("design:type", String)
    ], SettleFolioPaymentDto.prototype, "paymentMethod", void 0);
    __decorate([
      (0, class_validator_1.IsString)(),
      __metadata("design:type", String)
    ], SettleFolioPaymentDto.prototype, "amount", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsString)(),
      __metadata("design:type", String)
    ], SettleFolioPaymentDto.prototype, "paymentProvider", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsString)(),
      __metadata("design:type", String)
    ], SettleFolioPaymentDto.prototype, "externalReceiptNumber", void 0);
  }
});

// apps/api/dist/modules/front-office/dto/update-room-chart.dto.js
var require_update_room_chart_dto = __commonJS({
  "apps/api/dist/modules/front-office/dto/update-room-chart.dto.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = exports && exports.__metadata || function(k, v) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.UpdateRoomChartDto = void 0;
    var client_1 = __require("@prisma/client");
    var class_validator_1 = __require("class-validator");
    var UpdateRoomChartDto = class {
      housekeepingStatus;
      maintenanceStatus;
      primaryGuestId;
      arrivalDate;
      departureDate;
      nightlyRate;
    };
    exports.UpdateRoomChartDto = UpdateRoomChartDto;
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsEnum)(client_1.RoomHousekeepingStatus),
      __metadata("design:type", String)
    ], UpdateRoomChartDto.prototype, "housekeepingStatus", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsEnum)(client_1.RoomMaintenanceStatus),
      __metadata("design:type", String)
    ], UpdateRoomChartDto.prototype, "maintenanceStatus", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsUUID)(),
      __metadata("design:type", String)
    ], UpdateRoomChartDto.prototype, "primaryGuestId", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsISO8601)(),
      __metadata("design:type", String)
    ], UpdateRoomChartDto.prototype, "arrivalDate", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsISO8601)(),
      __metadata("design:type", String)
    ], UpdateRoomChartDto.prototype, "departureDate", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsNumberString)(),
      __metadata("design:type", String)
    ], UpdateRoomChartDto.prototype, "nightlyRate", void 0);
  }
});

// apps/api/dist/modules/front-office/dto/update-room-type-rates.dto.js
var require_update_room_type_rates_dto = __commonJS({
  "apps/api/dist/modules/front-office/dto/update-room-type-rates.dto.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = exports && exports.__metadata || function(k, v) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.UpdateRoomTypeRatesDto = void 0;
    var class_validator_1 = __require("class-validator");
    var UpdateRoomTypeRatesDto = class {
      // TSh rate per night.
      baseRate;
      // USD rate per night; an empty string removes the USD rate.
      baseRateUsd;
    };
    exports.UpdateRoomTypeRatesDto = UpdateRoomTypeRatesDto;
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsNumberString)(),
      __metadata("design:type", String)
    ], UpdateRoomTypeRatesDto.prototype, "baseRate", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsString)(),
      (0, class_validator_1.Matches)(/^(\d{1,12}(\.\d{1,4})?)?$/, { message: "USD rate must be a positive amount with up to 4 decimals." }),
      __metadata("design:type", String)
    ], UpdateRoomTypeRatesDto.prototype, "baseRateUsd", void 0);
  }
});

// apps/api/dist/modules/front-office/reservation-availability.js
var require_reservation_availability = __commonJS({
  "apps/api/dist/modules/front-office/reservation-availability.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.blockingReservationStatuses = void 0;
    exports.dateRangesOverlap = dateRangesOverlap;
    exports.assertValidStayDates = assertValidStayDates;
    var client_1 = __require("@prisma/client");
    exports.blockingReservationStatuses = [
      client_1.ReservationStatus.TENTATIVE,
      client_1.ReservationStatus.CONFIRMED,
      client_1.ReservationStatus.CHECKED_IN
    ];
    function dateRangesOverlap(arrivalDate, departureDate, existingArrivalDate, existingDepartureDate) {
      return arrivalDate < existingDepartureDate && departureDate > existingArrivalDate;
    }
    function assertValidStayDates(arrivalDate, departureDate) {
      if (Number.isNaN(arrivalDate.getTime()) || Number.isNaN(departureDate.getTime())) {
        throw new Error("Arrival and departure dates must be valid dates.");
      }
      if (departureDate <= arrivalDate) {
        throw new Error("Departure date must be after arrival date.");
      }
    }
  }
});

// apps/api/dist/modules/front-office/front-office.service.js
var require_front_office_service = __commonJS({
  "apps/api/dist/modules/front-office/front-office.service.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = exports && exports.__metadata || function(k, v) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.FrontOfficeService = void 0;
    var common_1 = __require("@nestjs/common");
    var client_1 = __require("@prisma/client");
    var prisma_service_1 = require_prisma_service();
    var reservation_availability_1 = require_reservation_availability();
    var FrontOfficeService = class FrontOfficeService {
      prisma;
      constructor(prisma) {
        this.prisma = prisma;
      }
      listRoomTypes(user) {
        const propertyId = this.requireProperty(user);
        return this.prisma.roomType.findMany({
          where: { propertyId },
          orderBy: { code: "asc" }
        });
      }
      async createRoomType(user, dto) {
        const propertyId = this.requireProperty(user);
        const code = dto.code.trim().toUpperCase();
        const name = dto.name.trim();
        const baseRate = new client_1.Prisma.Decimal(dto.baseRate);
        const baseRateUsd = dto.baseRateUsd ? new client_1.Prisma.Decimal(dto.baseRateUsd) : null;
        const baseOccupancy = dto.baseOccupancy ?? 1;
        const maxOccupancy = dto.maxOccupancy ?? 2;
        if (!code || !name) {
          throw new common_1.BadRequestException("Room type code and name are required.");
        }
        if (baseRate.lt(0) || baseRateUsd?.lt(0)) {
          throw new common_1.BadRequestException("Base rate cannot be negative.");
        }
        if (maxOccupancy < baseOccupancy) {
          throw new common_1.BadRequestException("Maximum occupancy cannot be lower than base occupancy.");
        }
        const existingRoomType = await this.prisma.roomType.findFirst({
          where: {
            propertyId,
            code
          }
        });
        if (existingRoomType) {
          throw new common_1.ConflictException(`Room type ${code} already exists.`);
        }
        const roomType = await this.prisma.roomType.create({
          data: {
            propertyId,
            code,
            name,
            baseOccupancy,
            maxOccupancy,
            baseRate,
            baseRateUsd,
            active: dto.active ?? true
          }
        });
        await this.recordAudit(user, "create_room_type", "room_type", roomType.id, {
          code: roomType.code,
          name: roomType.name,
          baseRate: roomType.baseRate.toString(),
          baseRateUsd: roomType.baseRateUsd?.toString() ?? null
        });
        return roomType;
      }
      async updateRoomTypeRates(user, roomTypeId, dto) {
        const propertyId = this.requireProperty(user);
        const roomType = await this.prisma.roomType.findFirst({ where: { id: roomTypeId, propertyId } });
        if (!roomType) {
          throw new common_1.NotFoundException("Room type was not found.");
        }
        const baseRate = dto.baseRate !== void 0 ? new client_1.Prisma.Decimal(dto.baseRate) : void 0;
        const baseRateUsd = dto.baseRateUsd === void 0 ? void 0 : dto.baseRateUsd ? new client_1.Prisma.Decimal(dto.baseRateUsd) : null;
        if (baseRate?.lt(0) || baseRateUsd?.lt(0)) {
          throw new common_1.BadRequestException("Base rate cannot be negative.");
        }
        const updated = await this.prisma.roomType.update({
          where: { id: roomType.id },
          data: { baseRate, baseRateUsd }
        });
        await this.recordAudit(user, "update_room_type_rates", "room_type", updated.id, {
          code: updated.code,
          previousBaseRate: roomType.baseRate.toString(),
          previousBaseRateUsd: roomType.baseRateUsd?.toString() ?? null,
          baseRate: updated.baseRate.toString(),
          baseRateUsd: updated.baseRateUsd?.toString() ?? null
        });
        return updated;
      }
      listRooms(user) {
        const propertyId = this.requireProperty(user);
        return this.prisma.room.findMany({
          where: { propertyId },
          include: {
            floor: true,
            roomType: true
          },
          orderBy: { roomNumber: "asc" }
        });
      }
      async listRoomChart(user) {
        const propertyId = this.requireProperty(user);
        const rooms = await this.prisma.room.findMany({
          where: { propertyId, active: true },
          include: {
            floor: true,
            roomType: true,
            reservationRooms: {
              where: {
                status: {
                  in: [client_1.ReservationStatus.CONFIRMED, client_1.ReservationStatus.CHECKED_IN]
                },
                reservation: {
                  status: {
                    in: [client_1.ReservationStatus.CONFIRMED, client_1.ReservationStatus.CHECKED_IN]
                  }
                }
              },
              include: {
                reservation: {
                  include: {
                    primaryGuest: true,
                    folios: {
                      include: {
                        items: {
                          orderBy: { postedAt: "desc" }
                        },
                        posOrders: {
                          include: {
                            outlet: true
                          },
                          orderBy: { createdAt: "desc" },
                          take: 5
                        }
                      }
                    }
                  }
                }
              },
              orderBy: { createdAt: "desc" }
            }
          },
          orderBy: { roomNumber: "asc" }
        });
        return rooms.map((room) => {
          const assignedRoom = room.reservationRooms.find((reservationRoom) => reservationRoom.reservation.status === client_1.ReservationStatus.CHECKED_IN) ?? room.reservationRooms.find((reservationRoom) => reservationRoom.reservation.status === client_1.ReservationStatus.CONFIRMED) ?? null;
          const reservation = assignedRoom?.reservation ?? null;
          const folio = reservation?.folios.find((entry) => entry.status === client_1.FolioStatus.OPEN) ?? reservation?.folios[0] ?? null;
          const items = folio?.items ?? [];
          const posCharges = sumFolioItems(items, [client_1.FolioItemType.POS_CHARGE]);
          const roomCharges = sumFolioItems(items, [client_1.FolioItemType.ROOM_CHARGE, client_1.FolioItemType.OTHER]);
          const credits = sumFolioItems(items, [client_1.FolioItemType.PAYMENT, client_1.FolioItemType.DEPOSIT, client_1.FolioItemType.DISCOUNT, client_1.FolioItemType.REFUND]);
          return {
            id: room.id,
            roomNumber: room.roomNumber,
            occupancyStatus: room.occupancyStatus,
            housekeepingStatus: room.housekeepingStatus,
            maintenanceStatus: room.maintenanceStatus,
            active: room.active,
            floor: room.floor ? {
              id: room.floor.id,
              name: room.floor.name
            } : null,
            roomType: {
              id: room.roomType.id,
              code: room.roomType.code,
              name: room.roomType.name,
              baseRate: money(room.roomType.baseRate),
              baseRateUsd: room.roomType.baseRateUsd ? money(room.roomType.baseRateUsd) : null
            },
            currentStay: reservation ? {
              reservationId: reservation.id,
              reservationNumber: reservation.reservationNumber,
              status: reservation.status,
              arrivalDate: reservation.arrivalDate,
              departureDate: reservation.departureDate,
              guest: {
                id: reservation.primaryGuest.id,
                firstName: reservation.primaryGuest.firstName,
                lastName: reservation.primaryGuest.lastName,
                email: reservation.primaryGuest.email,
                phone: reservation.primaryGuest.phone
              },
              nightlyRate: assignedRoom ? money(assignedRoom.nightlyRate) : "0.00",
              mealPlan: reservation.mealPlan,
              companyName: reservation.companyName,
              prepaidAmount: money(reservation.depositPaid),
              currencyCode: assignedRoom?.currencyCode ?? "TZS",
              folio: folio ? {
                id: folio.id,
                folioNumber: folio.folioNumber,
                status: folio.status,
                balance: money(folio.balance),
                posCharges: money(posCharges),
                roomCharges: money(roomCharges),
                credits: money(credits),
                recentCharges: items.slice(0, 6).map((item) => ({
                  id: item.id,
                  itemType: item.itemType,
                  description: item.description,
                  totalAmount: money(item.totalAmount),
                  postedAt: item.postedAt
                })),
                recentPosOrders: folio.posOrders.map((order) => ({
                  id: order.id,
                  orderNumber: order.orderNumber,
                  outletName: order.outlet.name,
                  status: order.status,
                  grandTotal: money(order.grandTotal),
                  createdAt: order.createdAt
                }))
              } : null
            } : null
          };
        });
      }
      async createRoom(user, dto) {
        const propertyId = this.requireProperty(user);
        const roomNumber = dto.roomNumber.trim();
        if (!roomNumber) {
          throw new common_1.BadRequestException("Room number is required.");
        }
        const roomType = await this.prisma.roomType.findFirst({
          where: {
            id: dto.roomTypeId,
            propertyId
          }
        });
        if (!roomType) {
          throw new common_1.NotFoundException("Room type was not found.");
        }
        if (dto.floorId) {
          const floor = await this.prisma.floor.findFirst({
            where: {
              id: dto.floorId,
              propertyId
            }
          });
          if (!floor) {
            throw new common_1.NotFoundException("Floor was not found.");
          }
        }
        const existingRoom = await this.prisma.room.findFirst({
          where: {
            propertyId,
            roomNumber
          }
        });
        if (existingRoom) {
          throw new common_1.ConflictException(`Room ${roomNumber} already exists.`);
        }
        const room = await this.prisma.room.create({
          data: {
            propertyId,
            roomTypeId: dto.roomTypeId,
            floorId: dto.floorId,
            roomNumber,
            housekeepingStatus: client_1.RoomHousekeepingStatus.CLEAN,
            occupancyStatus: client_1.RoomOccupancyStatus.AVAILABLE,
            maintenanceStatus: client_1.RoomMaintenanceStatus.AVAILABLE
          },
          include: {
            roomType: true,
            floor: true
          }
        });
        await this.recordAudit(user, "create_room", "room", room.id, {
          roomNumber: room.roomNumber,
          roomType: room.roomType.code
        });
        return room;
      }
      async updateRoomChart(user, roomId, dto) {
        const propertyId = this.requireProperty(user);
        return this.prisma.$transaction(async (tx) => {
          const room = await tx.room.findFirst({
            where: {
              id: roomId,
              propertyId,
              active: true
            },
            include: {
              roomType: true
            }
          });
          if (!room) {
            throw new common_1.NotFoundException("Room was not found.");
          }
          const roomUpdates = {};
          if (dto.housekeepingStatus) {
            roomUpdates.housekeepingStatus = dto.housekeepingStatus;
          }
          if (dto.maintenanceStatus) {
            roomUpdates.maintenanceStatus = dto.maintenanceStatus;
          }
          const updatedRoom = Object.keys(roomUpdates).length ? await tx.room.update({
            where: { id: room.id },
            data: roomUpdates,
            include: {
              roomType: true
            }
          }) : room;
          const wantsStayUpdate = Boolean(dto.primaryGuestId || dto.arrivalDate || dto.departureDate || dto.nightlyRate !== void 0);
          let updatedReservation = null;
          if (wantsStayUpdate) {
            const activeRoom = await tx.reservationRoom.findFirst({
              where: {
                roomId: room.id,
                status: {
                  in: [client_1.ReservationStatus.CONFIRMED, client_1.ReservationStatus.CHECKED_IN]
                },
                reservation: {
                  propertyId,
                  status: {
                    in: [client_1.ReservationStatus.CONFIRMED, client_1.ReservationStatus.CHECKED_IN]
                  }
                }
              },
              include: {
                reservation: {
                  include: {
                    primaryGuest: true,
                    folios: true
                  }
                },
                roomType: true
              },
              orderBy: {
                createdAt: "desc"
              }
            });
            if (!activeRoom) {
              throw new common_1.ConflictException("This room has no active reservation to edit.");
            }
            const arrivalDate = dto.arrivalDate ? toDateOnly(dto.arrivalDate) : activeRoom.reservation.arrivalDate;
            const departureDate = dto.departureDate ? toDateOnly(dto.departureDate) : activeRoom.reservation.departureDate;
            try {
              (0, reservation_availability_1.assertValidStayDates)(arrivalDate, departureDate);
            } catch (error) {
              throw new common_1.BadRequestException(error.message);
            }
            await this.assertRoomAvailable(tx, room.id, arrivalDate, departureDate, activeRoom.reservation.id);
            const nightlyRate = dto.nightlyRate !== void 0 ? new client_1.Prisma.Decimal(dto.nightlyRate) : activeRoom.nightlyRate;
            if (nightlyRate.lt(0)) {
              throw new common_1.BadRequestException("Nightly rate cannot be negative.");
            }
            let guestId = activeRoom.reservation.primaryGuestId;
            if (dto.primaryGuestId) {
              const guest = await tx.guest.findFirst({
                where: {
                  id: dto.primaryGuestId,
                  organizationId: user.organizationId,
                  OR: [{ propertyId }, { propertyId: null }]
                }
              });
              if (!guest) {
                throw new common_1.NotFoundException("Guest was not found.");
              }
              guestId = guest.id;
            }
            updatedReservation = await tx.reservation.update({
              where: { id: activeRoom.reservation.id },
              data: {
                primaryGuestId: guestId,
                arrivalDate,
                departureDate
              }
            });
            await tx.reservationRoom.update({
              where: { id: activeRoom.id },
              data: {
                nightlyRate
              }
            });
            if (guestId !== activeRoom.reservation.primaryGuestId) {
              await tx.reservationGuest.updateMany({
                where: {
                  reservationId: activeRoom.reservation.id,
                  guestRole: "primary",
                  guestId: {
                    not: guestId
                  }
                },
                data: {
                  guestRole: "guest"
                }
              });
              await tx.reservationGuest.upsert({
                where: {
                  reservationId_guestId: {
                    reservationId: activeRoom.reservation.id,
                    guestId
                  }
                },
                update: {
                  guestRole: "primary",
                  reservationRoomId: activeRoom.id
                },
                create: {
                  reservationId: activeRoom.reservation.id,
                  guestId,
                  reservationRoomId: activeRoom.id,
                  guestRole: "primary"
                }
              });
              await tx.folio.updateMany({
                where: {
                  reservationId: activeRoom.reservation.id
                },
                data: {
                  guestId
                }
              });
            }
          }
          await tx.auditLog.create({
            data: {
              organizationId: user.organizationId,
              propertyId,
              userId: user.userId,
              module: "front_office",
              action: "update_room_chart",
              recordType: "room",
              recordId: room.id,
              previousValue: {
                roomNumber: room.roomNumber,
                housekeepingStatus: room.housekeepingStatus,
                maintenanceStatus: room.maintenanceStatus
              },
              newValue: {
                roomNumber: updatedRoom.roomNumber,
                housekeepingStatus: updatedRoom.housekeepingStatus,
                maintenanceStatus: updatedRoom.maintenanceStatus,
                reservationId: updatedReservation?.id
              }
            }
          });
          return {
            roomId: updatedRoom.id,
            roomNumber: updatedRoom.roomNumber,
            housekeepingStatus: updatedRoom.housekeepingStatus,
            maintenanceStatus: updatedRoom.maintenanceStatus,
            reservationId: updatedReservation?.id ?? null
          };
        });
      }
      async postRoomCharge(user, roomId, dto) {
        const propertyId = this.requireProperty(user);
        const unitPrice = new client_1.Prisma.Decimal(dto.amount);
        const quantity = new client_1.Prisma.Decimal(dto.quantity ?? "1");
        if (unitPrice.lte(0) || quantity.lte(0)) {
          throw new common_1.BadRequestException("Charge amount and quantity must be greater than zero.");
        }
        const description = dto.description.trim();
        if (!description) {
          throw new common_1.BadRequestException("Charge description is required.");
        }
        return this.prisma.$transaction(async (tx) => {
          const room = await tx.room.findFirst({
            where: {
              id: roomId,
              propertyId,
              active: true
            },
            include: {
              roomType: true
            }
          });
          if (!room) {
            throw new common_1.NotFoundException("Room was not found.");
          }
          const checkedInRoom = await tx.reservationRoom.findFirst({
            where: {
              roomId,
              status: client_1.ReservationStatus.CHECKED_IN,
              reservation: {
                propertyId,
                status: client_1.ReservationStatus.CHECKED_IN
              }
            },
            include: {
              reservation: {
                include: {
                  primaryGuest: true,
                  folios: true
                }
              }
            }
          });
          if (!checkedInRoom) {
            throw new common_1.ConflictException("This room has no checked-in guest to charge.");
          }
          const folio = checkedInRoom.reservation.folios.find((entry) => entry.status === client_1.FolioStatus.OPEN) ?? await tx.folio.create({
            data: {
              propertyId,
              reservationId: checkedInRoom.reservation.id,
              guestId: checkedInRoom.reservation.primaryGuestId,
              folioNumber: await this.nextFolioNumber(tx, propertyId, /* @__PURE__ */ new Date()),
              status: client_1.FolioStatus.OPEN
            }
          });
          const totalAmount = unitPrice.mul(quantity);
          const item = await tx.folioItem.create({
            data: {
              folioId: folio.id,
              itemType: client_1.FolioItemType.OTHER,
              sourceType: "FRONT_OFFICE",
              sourceId: checkedInRoom.id,
              description,
              quantity,
              unitPrice,
              totalAmount
            }
          });
          const updatedFolio = await tx.folio.update({
            where: { id: folio.id },
            data: {
              balance: {
                increment: totalAmount
              }
            }
          });
          await tx.auditLog.create({
            data: {
              organizationId: user.organizationId,
              propertyId,
              userId: user.userId,
              module: "front_office",
              action: "post_room_charge",
              recordType: "folio_item",
              recordId: item.id,
              newValue: {
                roomNumber: room.roomNumber,
                folioNumber: updatedFolio.folioNumber,
                description,
                totalAmount: totalAmount.toString()
              }
            }
          });
          return {
            roomId: room.id,
            roomNumber: room.roomNumber,
            reservationId: checkedInRoom.reservation.id,
            reservationNumber: checkedInRoom.reservation.reservationNumber,
            guest: checkedInRoom.reservation.primaryGuest,
            folio: {
              id: updatedFolio.id,
              folioNumber: updatedFolio.folioNumber,
              balance: money(updatedFolio.balance),
              status: updatedFolio.status
            },
            item: {
              id: item.id,
              description: item.description,
              totalAmount: money(item.totalAmount),
              postedAt: item.postedAt
            }
          };
        });
      }
      listGuests(user) {
        return this.prisma.guest.findMany({
          where: {
            organizationId: user.organizationId,
            OR: user.propertyId ? [{ propertyId: user.propertyId }, { propertyId: null }] : void 0
          },
          orderBy: [{ lastName: "asc" }, { firstName: "asc" }]
        });
      }
      async createGuest(user, dto) {
        const firstName = dto.firstName.trim();
        const lastName = dto.lastName.trim();
        const email = dto.email?.trim().toLowerCase() || void 0;
        const phone = dto.phone?.trim() || void 0;
        const documentNumber = dto.documentNumber?.trim() || void 0;
        if (!firstName || !lastName) {
          throw new common_1.BadRequestException("Guest first name and last name are required.");
        }
        if (email) {
          const existingGuest = await this.prisma.guest.findFirst({
            where: {
              organizationId: user.organizationId,
              email
            }
          });
          if (existingGuest) {
            throw new common_1.ConflictException(`Guest email ${email} is already registered.`);
          }
        }
        const guest = await this.prisma.guest.create({
          data: {
            organizationId: user.organizationId,
            propertyId: user.propertyId,
            firstName,
            lastName,
            email,
            phone,
            documentNumber
          }
        });
        await this.recordAudit(user, "create_guest", "guest", guest.id, {
          firstName: guest.firstName,
          lastName: guest.lastName,
          email: guest.email
        });
        return guest;
      }
      listReservations(user) {
        const propertyId = this.requireProperty(user);
        return this.prisma.reservation.findMany({
          where: { propertyId },
          include: {
            primaryGuest: true,
            reservationRooms: {
              include: {
                room: true,
                roomType: true
              }
            },
            folios: true
          },
          orderBy: [{ arrivalDate: "desc" }, { reservationNumber: "desc" }]
        });
      }
      async createReservation(user, dto) {
        const propertyId = this.requireProperty(user);
        const arrivalDate = toDateOnly(dto.arrivalDate);
        const departureDate = toDateOnly(dto.departureDate);
        try {
          (0, reservation_availability_1.assertValidStayDates)(arrivalDate, departureDate);
        } catch (error) {
          throw new common_1.BadRequestException(error.message);
        }
        return this.prisma.$transaction(async (tx) => {
          const guest = await tx.guest.findFirst({
            where: {
              id: dto.primaryGuestId,
              organizationId: user.organizationId
            }
          });
          if (!guest) {
            throw new common_1.NotFoundException("Primary guest was not found.");
          }
          const roomType = await tx.roomType.findFirst({
            where: {
              id: dto.roomTypeId,
              propertyId,
              active: true
            }
          });
          if (!roomType) {
            throw new common_1.NotFoundException("Room type was not found.");
          }
          if (dto.roomId) {
            const room = await tx.room.findFirst({
              where: {
                id: dto.roomId,
                propertyId,
                roomTypeId: dto.roomTypeId,
                active: true
              }
            });
            if (!room) {
              throw new common_1.NotFoundException("Room was not found.");
            }
            if (room.maintenanceStatus !== client_1.RoomMaintenanceStatus.AVAILABLE) {
              throw new common_1.ConflictException("Room is not available for sale.");
            }
            await this.assertRoomAvailable(tx, dto.roomId, arrivalDate, departureDate);
          }
          const reservationNumber = await this.nextReservationNumber(tx, propertyId, arrivalDate);
          const reservation = await tx.reservation.create({
            data: {
              propertyId,
              primaryGuestId: dto.primaryGuestId,
              reservationNumber,
              arrivalDate,
              departureDate,
              adults: dto.adults ?? 1,
              children: dto.children ?? 0,
              status: client_1.ReservationStatus.CONFIRMED,
              bookingSource: dto.bookingSource,
              notes: dto.notes,
              reservationRooms: {
                create: {
                  roomTypeId: dto.roomTypeId,
                  roomId: dto.roomId,
                  nightlyRate: new client_1.Prisma.Decimal(dto.nightlyRate),
                  currencyCode: dto.currencyCode ?? "TZS",
                  status: client_1.ReservationStatus.CONFIRMED
                }
              },
              reservationGuests: {
                create: {
                  guestId: dto.primaryGuestId,
                  guestRole: "primary"
                }
              }
            },
            include: {
              primaryGuest: true,
              reservationRooms: {
                include: {
                  room: true,
                  roomType: true
                }
              }
            }
          });
          if (dto.roomId) {
            await tx.room.update({
              where: { id: dto.roomId },
              data: {
                occupancyStatus: client_1.RoomOccupancyStatus.RESERVED
              }
            });
          }
          await tx.auditLog.create({
            data: {
              organizationId: user.organizationId,
              propertyId,
              userId: user.userId,
              module: "front_office",
              action: "create_reservation",
              recordType: "reservation",
              recordId: reservation.id,
              newValue: {
                reservationNumber: reservation.reservationNumber,
                arrivalDate: reservation.arrivalDate.toISOString(),
                departureDate: reservation.departureDate.toISOString(),
                roomId: dto.roomId,
                guestId: dto.primaryGuestId
              }
            }
          });
          return reservation;
        });
      }
      async checkIn(user, reservationId, dto = {}) {
        const propertyId = this.requireProperty(user);
        const companyName = dto.companyName?.trim() || void 0;
        const paymentReference = dto.paymentReference?.trim() || void 0;
        const prepaidText = dto.prepaidAmount?.trim();
        let prepaidAmount = new client_1.Prisma.Decimal(0);
        if (prepaidText) {
          try {
            prepaidAmount = new client_1.Prisma.Decimal(prepaidText);
          } catch {
            throw new common_1.BadRequestException("Enter the total amount already paid as a number.");
          }
          if (prepaidAmount.lt(0)) {
            throw new common_1.BadRequestException("Amount already paid cannot be negative.");
          }
        }
        const isPrepaid = prepaidAmount.gt(0);
        if (isPrepaid && !dto.mealPlan) {
          throw new common_1.BadRequestException("Choose what the booking paid for: Full board, Half board or Bed & breakfast.");
        }
        return this.prisma.$transaction(async (tx) => {
          const reservation = await tx.reservation.findFirst({
            where: {
              id: reservationId,
              propertyId
            },
            include: {
              reservationRooms: true,
              folios: true
            }
          });
          if (!reservation) {
            throw new common_1.NotFoundException("Reservation was not found.");
          }
          if (reservation.status !== client_1.ReservationStatus.CONFIRMED) {
            throw new common_1.ConflictException("Only confirmed reservations can be checked in.");
          }
          const assignedRoom = reservation.reservationRooms.find((reservationRoom) => reservationRoom.roomId);
          if (!assignedRoom?.roomId) {
            throw new common_1.BadRequestException("A room must be assigned before check-in.");
          }
          await this.assertRoomAvailable(tx, assignedRoom.roomId, reservation.arrivalDate, reservation.departureDate, reservation.id);
          const existingOpenFolio = reservation.folios.find((folio2) => folio2.status === client_1.FolioStatus.OPEN);
          const folio = existingOpenFolio ?? await tx.folio.create({
            data: {
              propertyId,
              reservationId: reservation.id,
              guestId: reservation.primaryGuestId,
              folioNumber: await this.nextFolioNumber(tx, propertyId, reservation.arrivalDate),
              status: client_1.FolioStatus.OPEN
            }
          });
          const nights = stayNights(reservation.arrivalDate, reservation.departureDate);
          const roomChargeTotal = reservation.reservationRooms.reduce((sum, reservationRoom) => sum.plus(reservationRoom.nightlyRate.mul(nights)), new client_1.Prisma.Decimal(0));
          if (roomChargeTotal.gt(0)) {
            await tx.folioItem.create({
              data: {
                folioId: folio.id,
                itemType: client_1.FolioItemType.ROOM_CHARGE,
                sourceType: "RESERVATION",
                sourceId: reservation.id,
                description: `Room charge for ${nights} night${nights === 1 ? "" : "s"}`,
                quantity: new client_1.Prisma.Decimal(nights),
                unitPrice: roomChargeTotal.div(nights),
                totalAmount: roomChargeTotal
              }
            });
            await tx.folio.update({
              where: { id: folio.id },
              data: {
                balance: {
                  increment: roomChargeTotal
                }
              }
            });
          }
          if (isPrepaid) {
            const currencyCode = reservation.reservationRooms[0]?.currencyCode ?? "TZS";
            const paidBy = companyName ?? "guest";
            await tx.folioItem.create({
              data: {
                folioId: folio.id,
                itemType: client_1.FolioItemType.DEPOSIT,
                sourceType: "PREPAID_BOOKING",
                sourceId: reservation.id,
                description: `Prepaid ${mealPlanLabel(dto.mealPlan)} by ${paidBy}${paymentReference ? ` (ref ${paymentReference})` : ""}`,
                quantity: new client_1.Prisma.Decimal(1),
                unitPrice: prepaidAmount,
                totalAmount: prepaidAmount
              }
            });
            await tx.folio.update({
              where: { id: folio.id },
              data: {
                balance: {
                  decrement: prepaidAmount
                }
              }
            });
            await tx.auditLog.create({
              data: {
                organizationId: user.organizationId,
                propertyId,
                userId: user.userId,
                module: "front_office",
                action: "record_prepaid_booking",
                recordType: "reservation",
                recordId: reservation.id,
                newValue: {
                  mealPlan: dto.mealPlan,
                  companyName,
                  paymentReference,
                  prepaidAmount: prepaidAmount.toString(),
                  currencyCode
                }
              }
            });
          }
          const updatedReservation = await tx.reservation.update({
            where: { id: reservation.id },
            data: {
              status: client_1.ReservationStatus.CHECKED_IN,
              checkedInAt: /* @__PURE__ */ new Date(),
              ...dto.mealPlan ? { mealPlan: dto.mealPlan } : {},
              ...companyName ? { companyName } : {},
              ...isPrepaid ? { depositPaid: { increment: prepaidAmount } } : {},
              reservationRooms: {
                updateMany: {
                  where: { reservationId: reservation.id },
                  data: { status: client_1.ReservationStatus.CHECKED_IN }
                }
              }
            },
            include: {
              folios: true,
              reservationRooms: {
                include: {
                  room: true,
                  roomType: true
                }
              }
            }
          });
          await tx.room.update({
            where: { id: assignedRoom.roomId },
            data: {
              occupancyStatus: client_1.RoomOccupancyStatus.OCCUPIED
            }
          });
          await tx.auditLog.create({
            data: {
              organizationId: user.organizationId,
              propertyId,
              userId: user.userId,
              module: "front_office",
              action: "check_in",
              recordType: "reservation",
              recordId: reservation.id,
              previousValue: {
                status: reservation.status
              },
              newValue: {
                status: client_1.ReservationStatus.CHECKED_IN,
                folioNumber: folio.folioNumber,
                roomChargeTotal: roomChargeTotal.toString()
              }
            }
          });
          return updatedReservation;
        });
      }
      async settleFolio(user, reservationId, dto) {
        const propertyId = this.requireProperty(user);
        const amount = new client_1.Prisma.Decimal(dto.amount);
        const paymentProvider = normalizeProvider(dto.paymentProvider);
        const externalReceiptNumber = dto.externalReceiptNumber?.trim() || void 0;
        if (amount.lte(0)) {
          throw new common_1.BadRequestException("Payment amount must be greater than zero.");
        }
        if (dto.paymentMethod === client_1.PaymentMethod.BANK_TRANSFER && !paymentProvider) {
          throw new common_1.BadRequestException("Choose PayPal, Selcom, or CRDB for bank payment.");
        }
        if (dto.paymentMethod === client_1.PaymentMethod.BANK_TRANSFER && paymentProvider && !isBankProvider(paymentProvider)) {
          throw new common_1.BadRequestException("Bank payment provider must be PayPal, Selcom, or CRDB.");
        }
        if (dto.paymentMethod === client_1.PaymentMethod.MOBILE_MONEY && !paymentProvider) {
          throw new common_1.BadRequestException("Choose M-Pesa or TigoPesa for mobile money payment.");
        }
        if (dto.paymentMethod === client_1.PaymentMethod.MOBILE_MONEY && paymentProvider && !isMobileProvider(paymentProvider)) {
          throw new common_1.BadRequestException("Mobile money provider must be M-Pesa or TigoPesa.");
        }
        if (dto.paymentMethod !== client_1.PaymentMethod.BANK_TRANSFER && dto.paymentMethod !== client_1.PaymentMethod.MOBILE_MONEY && paymentProvider) {
          throw new common_1.BadRequestException("Payment provider is only allowed for bank or mobile money payments.");
        }
        if (requiresReceiptId(dto.paymentMethod) && !externalReceiptNumber) {
          throw new common_1.BadRequestException("Receipt ID number is required for this payment.");
        }
        return this.prisma.$transaction(async (tx) => {
          const reservation = await tx.reservation.findFirst({
            where: {
              id: reservationId,
              propertyId
            },
            include: {
              primaryGuest: true,
              folios: true
            }
          });
          if (!reservation) {
            throw new common_1.NotFoundException("Reservation was not found.");
          }
          if (reservation.status !== client_1.ReservationStatus.CHECKED_IN) {
            throw new common_1.ConflictException("Only checked-in reservations can receive checkout payments.");
          }
          const openFolio = reservation.folios.find((folio) => folio.status === client_1.FolioStatus.OPEN);
          if (!openFolio) {
            throw new common_1.ConflictException("This reservation has no open guest folio to settle.");
          }
          if (amount.gt(openFolio.balance)) {
            throw new common_1.BadRequestException("Payment amount cannot exceed the folio balance.");
          }
          if (externalReceiptNumber) {
            const duplicatePayment = await tx.payment.findFirst({
              where: {
                propertyId,
                externalReceiptNumber,
                status: client_1.PaymentStatus.COMPLETED
              }
            });
            if (duplicatePayment) {
              throw new common_1.ConflictException("This receipt ID number has already been used.");
            }
          }
          const systemReceiptNumber = await this.nextReceiptNumber(tx, propertyId, /* @__PURE__ */ new Date());
          const payment = await tx.payment.create({
            data: {
              propertyId,
              sourceType: "FOLIO",
              sourceId: openFolio.id,
              paymentMethod: dto.paymentMethod,
              amount,
              currencyCode: "USD",
              systemReceiptNumber,
              externalReceiptNumber,
              externalReference: paymentProvider ? formatProvider(paymentProvider) : externalReceiptNumber,
              paymentMetadata: {
                provider: paymentProvider,
                reservationNumber: reservation.reservationNumber,
                folioNumber: openFolio.folioNumber,
                guestName: `${reservation.primaryGuest.firstName} ${reservation.primaryGuest.lastName}`
              }
            }
          });
          const item = await tx.folioItem.create({
            data: {
              folioId: openFolio.id,
              itemType: client_1.FolioItemType.PAYMENT,
              sourceType: "PAYMENT",
              sourceId: payment.id,
              description: `Payment - ${paymentLabel(dto.paymentMethod, paymentProvider)}`,
              quantity: new client_1.Prisma.Decimal(1),
              unitPrice: amount,
              totalAmount: amount
            }
          });
          const updatedFolio = await tx.folio.update({
            where: { id: openFolio.id },
            data: {
              balance: {
                decrement: amount
              }
            }
          });
          await tx.auditLog.create({
            data: {
              organizationId: user.organizationId,
              propertyId,
              userId: user.userId,
              module: "front_office",
              action: "settle_folio",
              recordType: "payment",
              recordId: payment.id,
              newValue: {
                reservationNumber: reservation.reservationNumber,
                folioNumber: updatedFolio.folioNumber,
                paymentMethod: payment.paymentMethod,
                paymentProvider,
                externalReceiptNumber,
                amount: amount.toString()
              }
            }
          });
          return {
            reservationId: reservation.id,
            reservationNumber: reservation.reservationNumber,
            guestName: `${reservation.primaryGuest.firstName} ${reservation.primaryGuest.lastName}`,
            payment: {
              id: payment.id,
              systemReceiptNumber: payment.systemReceiptNumber,
              externalReceiptNumber: payment.externalReceiptNumber,
              paymentMethod: payment.paymentMethod,
              paymentProvider,
              amount: money(payment.amount),
              createdAt: payment.createdAt
            },
            folio: {
              id: updatedFolio.id,
              folioNumber: updatedFolio.folioNumber,
              balance: money(updatedFolio.balance),
              status: updatedFolio.status
            },
            item: {
              id: item.id,
              description: item.description,
              totalAmount: money(item.totalAmount),
              postedAt: item.postedAt
            }
          };
        });
      }
      async extendStay(user, reservationId, dto) {
        const propertyId = this.requireProperty(user);
        const nights = dto.nights;
        let overrideRate;
        if (dto.nightlyRate !== void 0 && dto.nightlyRate.trim() !== "") {
          overrideRate = new client_1.Prisma.Decimal(dto.nightlyRate);
          if (overrideRate.lt(0)) {
            throw new common_1.BadRequestException("Nightly rate cannot be negative.");
          }
        }
        return this.prisma.$transaction(async (tx) => {
          const reservation = await tx.reservation.findFirst({
            where: {
              id: reservationId,
              propertyId
            },
            include: {
              reservationRooms: true,
              folios: true
            }
          });
          if (!reservation) {
            throw new common_1.NotFoundException("Reservation was not found.");
          }
          if (reservation.status !== client_1.ReservationStatus.CHECKED_IN) {
            throw new common_1.ConflictException("Only checked-in guests can extend their stay.");
          }
          const previousDeparture = reservation.departureDate;
          const newDeparture = new Date(previousDeparture.getTime() + nights * 24 * 60 * 60 * 1e3);
          for (const reservationRoom of reservation.reservationRooms) {
            if (reservationRoom.roomId) {
              await this.assertRoomAvailable(tx, reservationRoom.roomId, previousDeparture, newDeparture, reservation.id);
            }
          }
          const extensionTotal = reservation.reservationRooms.reduce((sum, reservationRoom) => sum.plus((overrideRate ?? reservationRoom.nightlyRate).mul(nights)), new client_1.Prisma.Decimal(0));
          const folio = reservation.folios.find((item) => item.status === client_1.FolioStatus.OPEN) ?? await tx.folio.create({
            data: {
              propertyId,
              reservationId: reservation.id,
              guestId: reservation.primaryGuestId,
              folioNumber: await this.nextFolioNumber(tx, propertyId, reservation.arrivalDate),
              status: client_1.FolioStatus.OPEN
            }
          });
          const updatedReservation = await tx.reservation.update({
            where: { id: reservation.id },
            data: { departureDate: newDeparture }
          });
          let updatedBalance = folio.balance;
          if (extensionTotal.gt(0)) {
            await tx.folioItem.create({
              data: {
                folioId: folio.id,
                itemType: client_1.FolioItemType.ROOM_CHARGE,
                sourceType: "STAY_EXTENSION",
                sourceId: reservation.id,
                description: `Stay extended by ${nights} night${nights === 1 ? "" : "s"} (to ${newDeparture.toISOString().slice(0, 10)})`,
                quantity: new client_1.Prisma.Decimal(nights),
                unitPrice: extensionTotal.div(nights),
                totalAmount: extensionTotal
              }
            });
            const updatedFolio = await tx.folio.update({
              where: { id: folio.id },
              data: {
                balance: {
                  increment: extensionTotal
                }
              }
            });
            updatedBalance = updatedFolio.balance;
          }
          await tx.auditLog.create({
            data: {
              organizationId: user.organizationId,
              propertyId,
              userId: user.userId,
              module: "front_office",
              action: "extend_stay",
              recordType: "reservation",
              recordId: reservation.id,
              previousValue: {
                departureDate: previousDeparture.toISOString().slice(0, 10)
              },
              newValue: {
                departureDate: newDeparture.toISOString().slice(0, 10),
                extraNights: nights,
                extensionCharge: money(extensionTotal),
                ...overrideRate ? { nightlyRate: money(overrideRate) } : {}
              }
            }
          });
          return {
            reservationId: updatedReservation.id,
            reservationNumber: updatedReservation.reservationNumber,
            departureDate: updatedReservation.departureDate,
            extraNights: nights,
            extensionCharge: money(extensionTotal),
            folioBalance: money(updatedBalance)
          };
        });
      }
      async checkOut(user, reservationId) {
        const propertyId = this.requireProperty(user);
        return this.prisma.$transaction(async (tx) => {
          const reservation = await tx.reservation.findFirst({
            where: {
              id: reservationId,
              propertyId
            },
            include: {
              reservationRooms: true,
              folios: true
            }
          });
          if (!reservation) {
            throw new common_1.NotFoundException("Reservation was not found.");
          }
          if (reservation.status !== client_1.ReservationStatus.CHECKED_IN) {
            throw new common_1.ConflictException("Only checked-in reservations can be checked out.");
          }
          const openFolio = reservation.folios.find((folio) => folio.status === client_1.FolioStatus.OPEN);
          if (openFolio && openFolio.balance.gt(0)) {
            throw new common_1.ConflictException(`Guest must pay the remaining balance of ${money(openFolio.balance)} before check-out.`);
          }
          const updatedReservation = await tx.reservation.update({
            where: { id: reservation.id },
            data: {
              status: client_1.ReservationStatus.CHECKED_OUT,
              checkedOutAt: /* @__PURE__ */ new Date(),
              reservationRooms: {
                updateMany: {
                  where: { reservationId: reservation.id },
                  data: { status: client_1.ReservationStatus.CHECKED_OUT }
                }
              },
              folios: {
                updateMany: {
                  where: {
                    reservationId: reservation.id,
                    status: client_1.FolioStatus.OPEN
                  },
                  data: {
                    status: client_1.FolioStatus.CLOSED,
                    closedAt: /* @__PURE__ */ new Date()
                  }
                }
              }
            },
            include: {
              folios: true,
              reservationRooms: true
            }
          });
          for (const reservationRoom of reservation.reservationRooms) {
            if (reservationRoom.roomId) {
              await tx.room.update({
                where: { id: reservationRoom.roomId },
                data: {
                  occupancyStatus: client_1.RoomOccupancyStatus.AVAILABLE,
                  housekeepingStatus: client_1.RoomHousekeepingStatus.DIRTY
                }
              });
            }
          }
          await tx.auditLog.create({
            data: {
              organizationId: user.organizationId,
              propertyId,
              userId: user.userId,
              module: "front_office",
              action: "check_out",
              recordType: "reservation",
              recordId: reservation.id,
              previousValue: {
                status: reservation.status
              },
              newValue: {
                status: client_1.ReservationStatus.CHECKED_OUT,
                ...openFolio && openFolio.balance.lt(0) ? { unusedPrepaidCredit: money(openFolio.balance.negated()) } : {}
              }
            }
          });
          return updatedReservation;
        });
      }
      async assertRoomAvailable(tx, roomId, arrivalDate, departureDate, excludeReservationId) {
        const conflict = await tx.reservationRoom.findFirst({
          where: {
            roomId,
            status: {
              in: reservation_availability_1.blockingReservationStatuses
            },
            reservationId: excludeReservationId ? {
              not: excludeReservationId
            } : void 0,
            reservation: {
              arrivalDate: {
                lt: departureDate
              },
              departureDate: {
                gt: arrivalDate
              },
              status: {
                in: reservation_availability_1.blockingReservationStatuses
              }
            }
          },
          include: {
            reservation: true
          }
        });
        if (conflict) {
          throw new common_1.ConflictException(`Room is already booked by ${conflict.reservation.reservationNumber}.`);
        }
      }
      async nextReservationNumber(tx, propertyId, date) {
        const year = date.getUTCFullYear();
        const count = await tx.reservation.count({
          where: {
            propertyId,
            reservationNumber: {
              startsWith: `RES-${year}-`
            }
          }
        });
        return `RES-${year}-${String(count + 1).padStart(5, "0")}`;
      }
      async nextFolioNumber(tx, propertyId, date) {
        const year = date.getUTCFullYear();
        const count = await tx.folio.count({
          where: {
            propertyId,
            folioNumber: {
              startsWith: `FOL-${year}-`
            }
          }
        });
        return `FOL-${year}-${String(count + 1).padStart(5, "0")}`;
      }
      async nextReceiptNumber(tx, propertyId, date) {
        const year = date.getUTCFullYear();
        const count = await tx.payment.count({
          where: {
            propertyId,
            systemReceiptNumber: {
              startsWith: `RCT-${year}-`
            }
          }
        });
        return `RCT-${year}-${String(count + 1).padStart(5, "0")}`;
      }
      async recordAudit(user, action, recordType, recordId, newValue) {
        await this.prisma.auditLog.create({
          data: {
            organizationId: user.organizationId,
            propertyId: user.propertyId,
            userId: user.userId,
            module: "front_office",
            action,
            recordType,
            recordId,
            newValue
          }
        });
      }
      requireProperty(user) {
        if (!user.propertyId) {
          throw new common_1.BadRequestException("A property context is required.");
        }
        return user.propertyId;
      }
    };
    exports.FrontOfficeService = FrontOfficeService;
    exports.FrontOfficeService = FrontOfficeService = __decorate([
      (0, common_1.Injectable)(),
      __metadata("design:paramtypes", [prisma_service_1.PrismaService])
    ], FrontOfficeService);
    function toDateOnly(value) {
      const datePart = value.slice(0, 10);
      return /* @__PURE__ */ new Date(`${datePart}T00:00:00.000Z`);
    }
    var bankPaymentProviders = ["PAYPAL", "SELCOM", "CRDB"];
    var mobilePaymentProviders = ["MPESA", "TIGOPESA"];
    function sumFolioItems(items, itemTypes) {
      return items.filter((item) => itemTypes.includes(item.itemType)).reduce((sum, item) => sum.plus(item.totalAmount), new client_1.Prisma.Decimal(0));
    }
    function stayNights(arrivalDate, departureDate) {
      const millisecondsPerDay = 24 * 60 * 60 * 1e3;
      return Math.max(1, Math.round((departureDate.getTime() - arrivalDate.getTime()) / millisecondsPerDay));
    }
    function money(value) {
      return value.toFixed(2);
    }
    function mealPlanLabel(plan) {
      if (plan === "FULL_BOARD")
        return "Full board";
      if (plan === "HALF_BOARD")
        return "Half board";
      return "Bed & breakfast";
    }
    function normalizeProvider(value) {
      return value?.trim().toUpperCase().replace(/[\s-]+/g, "");
    }
    function isBankProvider(provider) {
      return bankPaymentProviders.includes(provider);
    }
    function isMobileProvider(provider) {
      return mobilePaymentProviders.includes(provider);
    }
    function formatProvider(provider) {
      if (provider === "PAYPAL")
        return "PayPal";
      if (provider === "SELCOM")
        return "Selcom";
      if (provider === "MPESA")
        return "M-Pesa";
      if (provider === "TIGOPESA")
        return "TigoPesa";
      return "CRDB";
    }
    function requiresReceiptId(paymentMethod) {
      return paymentMethod === client_1.PaymentMethod.CARD || paymentMethod === client_1.PaymentMethod.CREDIT || paymentMethod === client_1.PaymentMethod.MOBILE_MONEY || paymentMethod === client_1.PaymentMethod.BANK_TRANSFER;
    }
    function paymentLabel(paymentMethod, provider) {
      if (provider)
        return `${formatProvider(provider)} ${paymentMethod.toLowerCase().replaceAll("_", " ")}`;
      return paymentMethod.toLowerCase().replaceAll("_", " ");
    }
  }
});

// apps/api/dist/modules/front-office/dto/create-day-expense.dto.js
var require_create_day_expense_dto = __commonJS({
  "apps/api/dist/modules/front-office/dto/create-day-expense.dto.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = exports && exports.__metadata || function(k, v) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.CreateDayExpenseDto = void 0;
    var class_validator_1 = __require("class-validator");
    var CreateDayExpenseDto = class {
      description;
      amount;
      currencyCode;
      paidBy;
      date;
    };
    exports.CreateDayExpenseDto = CreateDayExpenseDto;
    __decorate([
      (0, class_validator_1.IsString)(),
      (0, class_validator_1.MinLength)(2),
      (0, class_validator_1.MaxLength)(200),
      __metadata("design:type", String)
    ], CreateDayExpenseDto.prototype, "description", void 0);
    __decorate([
      (0, class_validator_1.IsNumberString)(),
      __metadata("design:type", String)
    ], CreateDayExpenseDto.prototype, "amount", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsIn)(["TZS", "USD"]),
      __metadata("design:type", String)
    ], CreateDayExpenseDto.prototype, "currencyCode", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsString)(),
      (0, class_validator_1.MaxLength)(80),
      __metadata("design:type", String)
    ], CreateDayExpenseDto.prototype, "paidBy", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.Matches)(/^\d{4}-\d{2}-\d{2}$/),
      __metadata("design:type", String)
    ], CreateDayExpenseDto.prototype, "date", void 0);
  }
});

// apps/api/dist/modules/front-office/front-office.controller.js
var require_front_office_controller = __commonJS({
  "apps/api/dist/modules/front-office/front-office.controller.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = exports && exports.__metadata || function(k, v) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var __param = exports && exports.__param || function(paramIndex, decorator) {
      return function(target, key) {
        decorator(target, key, paramIndex);
      };
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.FrontOfficeController = void 0;
    var common_1 = __require("@nestjs/common");
    var current_user_decorator_1 = require_current_user_decorator();
    var require_permissions_decorator_1 = require_require_permissions_decorator();
    var check_in_dto_1 = require_check_in_dto();
    var create_guest_dto_1 = require_create_guest_dto();
    var create_reservation_dto_1 = require_create_reservation_dto();
    var create_room_dto_1 = require_create_room_dto();
    var create_room_type_dto_1 = require_create_room_type_dto();
    var extend_stay_dto_1 = require_extend_stay_dto();
    var post_room_charge_dto_1 = require_post_room_charge_dto();
    var settle_folio_payment_dto_1 = require_settle_folio_payment_dto();
    var update_room_chart_dto_1 = require_update_room_chart_dto();
    var update_room_type_rates_dto_1 = require_update_room_type_rates_dto();
    var front_office_service_1 = require_front_office_service();
    var day_expenses_service_1 = require_day_expenses_service();
    var create_day_expense_dto_1 = require_create_day_expense_dto();
    var FrontOfficeController = class FrontOfficeController {
      frontOffice;
      dayExpenses;
      constructor(frontOffice, dayExpenses) {
        this.frontOffice = frontOffice;
        this.dayExpenses = dayExpenses;
      }
      listDayExpenses(user, date) {
        return this.dayExpenses.list(user, date);
      }
      createDayExpense(user, dto) {
        return this.dayExpenses.create(user, dto);
      }
      removeDayExpense(user, id) {
        return this.dayExpenses.void(user, id);
      }
      listRoomTypes(user) {
        return this.frontOffice.listRoomTypes(user);
      }
      createRoomType(user, dto) {
        return this.frontOffice.createRoomType(user, dto);
      }
      updateRoomTypeRates(user, roomTypeId, dto) {
        return this.frontOffice.updateRoomTypeRates(user, roomTypeId, dto);
      }
      listRoomChart(user) {
        return this.frontOffice.listRoomChart(user);
      }
      listRooms(user) {
        return this.frontOffice.listRooms(user);
      }
      createRoom(user, dto) {
        return this.frontOffice.createRoom(user, dto);
      }
      updateRoomChart(user, roomId, dto) {
        return this.frontOffice.updateRoomChart(user, roomId, dto);
      }
      postRoomCharge(user, roomId, dto) {
        return this.frontOffice.postRoomCharge(user, roomId, dto);
      }
      listGuests(user) {
        return this.frontOffice.listGuests(user);
      }
      createGuest(user, dto) {
        return this.frontOffice.createGuest(user, dto);
      }
      listReservations(user) {
        return this.frontOffice.listReservations(user);
      }
      createReservation(user, dto) {
        return this.frontOffice.createReservation(user, dto);
      }
      checkIn(user, reservationId, dto) {
        return this.frontOffice.checkIn(user, reservationId, dto ?? {});
      }
      extendStay(user, reservationId, dto) {
        return this.frontOffice.extendStay(user, reservationId, dto);
      }
      settleFolio(user, reservationId, dto) {
        return this.frontOffice.settleFolio(user, reservationId, dto);
      }
      checkOut(user, reservationId) {
        return this.frontOffice.checkOut(user, reservationId);
      }
    };
    exports.FrontOfficeController = FrontOfficeController;
    __decorate([
      (0, require_permissions_decorator_1.RequirePermissions)("front_office.view"),
      (0, common_1.Get)("expenses"),
      __param(0, (0, current_user_decorator_1.CurrentUser)()),
      __param(1, (0, common_1.Query)("date")),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", [Object, String]),
      __metadata("design:returntype", void 0)
    ], FrontOfficeController.prototype, "listDayExpenses", null);
    __decorate([
      (0, require_permissions_decorator_1.RequirePermissions)("front_office.view"),
      (0, common_1.Post)("expenses"),
      __param(0, (0, current_user_decorator_1.CurrentUser)()),
      __param(1, (0, common_1.Body)()),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", [Object, create_day_expense_dto_1.CreateDayExpenseDto]),
      __metadata("design:returntype", void 0)
    ], FrontOfficeController.prototype, "createDayExpense", null);
    __decorate([
      (0, require_permissions_decorator_1.RequirePermissions)("front_office.view"),
      (0, common_1.Delete)("expenses/:id"),
      __param(0, (0, current_user_decorator_1.CurrentUser)()),
      __param(1, (0, common_1.Param)("id", new common_1.ParseUUIDPipe())),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", [Object, String]),
      __metadata("design:returntype", void 0)
    ], FrontOfficeController.prototype, "removeDayExpense", null);
    __decorate([
      (0, require_permissions_decorator_1.RequirePermissions)("front_office.view"),
      (0, common_1.Get)("room-types"),
      __param(0, (0, current_user_decorator_1.CurrentUser)()),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", [Object]),
      __metadata("design:returntype", void 0)
    ], FrontOfficeController.prototype, "listRoomTypes", null);
    __decorate([
      (0, require_permissions_decorator_1.RequirePermissions)("front_office.rooms.manage"),
      (0, common_1.Post)("room-types"),
      __param(0, (0, current_user_decorator_1.CurrentUser)()),
      __param(1, (0, common_1.Body)()),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", [Object, create_room_type_dto_1.CreateRoomTypeDto]),
      __metadata("design:returntype", void 0)
    ], FrontOfficeController.prototype, "createRoomType", null);
    __decorate([
      (0, require_permissions_decorator_1.RequirePermissions)("front_office.rooms.manage"),
      (0, common_1.Patch)("room-types/:roomTypeId/rates"),
      __param(0, (0, current_user_decorator_1.CurrentUser)()),
      __param(1, (0, common_1.Param)("roomTypeId")),
      __param(2, (0, common_1.Body)()),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", [Object, String, update_room_type_rates_dto_1.UpdateRoomTypeRatesDto]),
      __metadata("design:returntype", void 0)
    ], FrontOfficeController.prototype, "updateRoomTypeRates", null);
    __decorate([
      (0, require_permissions_decorator_1.RequirePermissions)("front_office.view"),
      (0, common_1.Get)("room-chart"),
      __param(0, (0, current_user_decorator_1.CurrentUser)()),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", [Object]),
      __metadata("design:returntype", void 0)
    ], FrontOfficeController.prototype, "listRoomChart", null);
    __decorate([
      (0, require_permissions_decorator_1.RequirePermissions)("front_office.view"),
      (0, common_1.Get)("rooms"),
      __param(0, (0, current_user_decorator_1.CurrentUser)()),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", [Object]),
      __metadata("design:returntype", void 0)
    ], FrontOfficeController.prototype, "listRooms", null);
    __decorate([
      (0, require_permissions_decorator_1.RequirePermissions)("front_office.rooms.manage"),
      (0, common_1.Post)("rooms"),
      __param(0, (0, current_user_decorator_1.CurrentUser)()),
      __param(1, (0, common_1.Body)()),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", [Object, create_room_dto_1.CreateRoomDto]),
      __metadata("design:returntype", void 0)
    ], FrontOfficeController.prototype, "createRoom", null);
    __decorate([
      (0, require_permissions_decorator_1.RequirePermissions)("front_office.rooms.manage"),
      (0, common_1.Patch)("rooms/:roomId/chart"),
      __param(0, (0, current_user_decorator_1.CurrentUser)()),
      __param(1, (0, common_1.Param)("roomId")),
      __param(2, (0, common_1.Body)()),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", [Object, String, update_room_chart_dto_1.UpdateRoomChartDto]),
      __metadata("design:returntype", void 0)
    ], FrontOfficeController.prototype, "updateRoomChart", null);
    __decorate([
      (0, require_permissions_decorator_1.RequirePermissions)("front_office.reservations.check_in"),
      (0, common_1.Post)("rooms/:roomId/charges"),
      __param(0, (0, current_user_decorator_1.CurrentUser)()),
      __param(1, (0, common_1.Param)("roomId")),
      __param(2, (0, common_1.Body)()),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", [Object, String, post_room_charge_dto_1.PostRoomChargeDto]),
      __metadata("design:returntype", void 0)
    ], FrontOfficeController.prototype, "postRoomCharge", null);
    __decorate([
      (0, require_permissions_decorator_1.RequirePermissions)("front_office.view"),
      (0, common_1.Get)("guests"),
      __param(0, (0, current_user_decorator_1.CurrentUser)()),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", [Object]),
      __metadata("design:returntype", void 0)
    ], FrontOfficeController.prototype, "listGuests", null);
    __decorate([
      (0, require_permissions_decorator_1.RequirePermissions)("front_office.guests.manage"),
      (0, common_1.Post)("guests"),
      __param(0, (0, current_user_decorator_1.CurrentUser)()),
      __param(1, (0, common_1.Body)()),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", [Object, create_guest_dto_1.CreateGuestDto]),
      __metadata("design:returntype", void 0)
    ], FrontOfficeController.prototype, "createGuest", null);
    __decorate([
      (0, require_permissions_decorator_1.RequirePermissions)("front_office.view"),
      (0, common_1.Get)("reservations"),
      __param(0, (0, current_user_decorator_1.CurrentUser)()),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", [Object]),
      __metadata("design:returntype", void 0)
    ], FrontOfficeController.prototype, "listReservations", null);
    __decorate([
      (0, require_permissions_decorator_1.RequirePermissions)("front_office.reservations.create"),
      (0, common_1.Post)("reservations"),
      __param(0, (0, current_user_decorator_1.CurrentUser)()),
      __param(1, (0, common_1.Body)()),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", [Object, create_reservation_dto_1.CreateReservationDto]),
      __metadata("design:returntype", void 0)
    ], FrontOfficeController.prototype, "createReservation", null);
    __decorate([
      (0, require_permissions_decorator_1.RequirePermissions)("front_office.reservations.check_in"),
      (0, common_1.Post)("reservations/:reservationId/check-in"),
      __param(0, (0, current_user_decorator_1.CurrentUser)()),
      __param(1, (0, common_1.Param)("reservationId")),
      __param(2, (0, common_1.Body)()),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", [Object, String, check_in_dto_1.CheckInDto]),
      __metadata("design:returntype", void 0)
    ], FrontOfficeController.prototype, "checkIn", null);
    __decorate([
      (0, require_permissions_decorator_1.RequirePermissions)("front_office.reservations.check_in"),
      (0, common_1.Post)("reservations/:reservationId/extend"),
      __param(0, (0, current_user_decorator_1.CurrentUser)()),
      __param(1, (0, common_1.Param)("reservationId")),
      __param(2, (0, common_1.Body)()),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", [Object, String, extend_stay_dto_1.ExtendStayDto]),
      __metadata("design:returntype", void 0)
    ], FrontOfficeController.prototype, "extendStay", null);
    __decorate([
      (0, require_permissions_decorator_1.RequirePermissions)("front_office.reservations.check_out"),
      (0, common_1.Post)("reservations/:reservationId/settle"),
      __param(0, (0, current_user_decorator_1.CurrentUser)()),
      __param(1, (0, common_1.Param)("reservationId")),
      __param(2, (0, common_1.Body)()),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", [Object, String, settle_folio_payment_dto_1.SettleFolioPaymentDto]),
      __metadata("design:returntype", void 0)
    ], FrontOfficeController.prototype, "settleFolio", null);
    __decorate([
      (0, require_permissions_decorator_1.RequirePermissions)("front_office.reservations.check_out"),
      (0, common_1.Post)("reservations/:reservationId/check-out"),
      __param(0, (0, current_user_decorator_1.CurrentUser)()),
      __param(1, (0, common_1.Param)("reservationId")),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", [Object, String]),
      __metadata("design:returntype", void 0)
    ], FrontOfficeController.prototype, "checkOut", null);
    exports.FrontOfficeController = FrontOfficeController = __decorate([
      (0, common_1.Controller)("front-office"),
      __metadata("design:paramtypes", [
        front_office_service_1.FrontOfficeService,
        day_expenses_service_1.DayExpensesService
      ])
    ], FrontOfficeController);
  }
});

// apps/api/dist/modules/front-office/front-office.module.js
var require_front_office_module = __commonJS({
  "apps/api/dist/modules/front-office/front-office.module.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.FrontOfficeModule = void 0;
    var common_1 = __require("@nestjs/common");
    var front_office_controller_1 = require_front_office_controller();
    var front_office_service_1 = require_front_office_service();
    var day_expenses_service_1 = require_day_expenses_service();
    var FrontOfficeModule = class FrontOfficeModule {
    };
    exports.FrontOfficeModule = FrontOfficeModule;
    exports.FrontOfficeModule = FrontOfficeModule = __decorate([
      (0, common_1.Module)({
        controllers: [front_office_controller_1.FrontOfficeController],
        providers: [front_office_service_1.FrontOfficeService, day_expenses_service_1.DayExpensesService],
        exports: [front_office_service_1.FrontOfficeService, day_expenses_service_1.DayExpensesService]
      })
    ], FrontOfficeModule);
  }
});

// apps/api/dist/modules/inventory/dto/adjust-inventory.dto.js
var require_adjust_inventory_dto = __commonJS({
  "apps/api/dist/modules/inventory/dto/adjust-inventory.dto.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = exports && exports.__metadata || function(k, v) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.AdjustInventoryDto = void 0;
    var class_validator_1 = __require("class-validator");
    var AdjustInventoryDto = class {
      itemId;
      locationId;
      direction;
      quantity;
      // Required: why the balance is being corrected (breakage, count difference, found stock...).
      reason;
    };
    exports.AdjustInventoryDto = AdjustInventoryDto;
    __decorate([
      (0, class_validator_1.IsUUID)(),
      __metadata("design:type", String)
    ], AdjustInventoryDto.prototype, "itemId", void 0);
    __decorate([
      (0, class_validator_1.IsUUID)(),
      __metadata("design:type", String)
    ], AdjustInventoryDto.prototype, "locationId", void 0);
    __decorate([
      (0, class_validator_1.IsIn)(["INCREASE", "DECREASE"]),
      __metadata("design:type", String)
    ], AdjustInventoryDto.prototype, "direction", void 0);
    __decorate([
      (0, class_validator_1.IsNumberString)(),
      __metadata("design:type", String)
    ], AdjustInventoryDto.prototype, "quantity", void 0);
    __decorate([
      (0, class_validator_1.IsString)(),
      (0, class_validator_1.IsNotEmpty)(),
      (0, class_validator_1.MinLength)(3),
      (0, class_validator_1.MaxLength)(300),
      __metadata("design:type", String)
    ], AdjustInventoryDto.prototype, "reason", void 0);
  }
});

// apps/api/dist/modules/inventory/dto/create-inventory-item.dto.js
var require_create_inventory_item_dto = __commonJS({
  "apps/api/dist/modules/inventory/dto/create-inventory-item.dto.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = exports && exports.__metadata || function(k, v) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.CreateInventoryItemDto = void 0;
    var class_validator_1 = __require("class-validator");
    var CreateInventoryItemDto = class {
      sku;
      name;
      unitOfMeasure;
      reorderLevel;
    };
    exports.CreateInventoryItemDto = CreateInventoryItemDto;
    __decorate([
      (0, class_validator_1.IsString)(),
      (0, class_validator_1.IsNotEmpty)(),
      (0, class_validator_1.MaxLength)(40),
      __metadata("design:type", String)
    ], CreateInventoryItemDto.prototype, "sku", void 0);
    __decorate([
      (0, class_validator_1.IsString)(),
      (0, class_validator_1.IsNotEmpty)(),
      (0, class_validator_1.MaxLength)(160),
      __metadata("design:type", String)
    ], CreateInventoryItemDto.prototype, "name", void 0);
    __decorate([
      (0, class_validator_1.IsString)(),
      (0, class_validator_1.IsNotEmpty)(),
      (0, class_validator_1.MaxLength)(20),
      __metadata("design:type", String)
    ], CreateInventoryItemDto.prototype, "unitOfMeasure", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsNumberString)(),
      __metadata("design:type", String)
    ], CreateInventoryItemDto.prototype, "reorderLevel", void 0);
  }
});

// apps/api/dist/modules/inventory/dto/inventory-history-query.dto.js
var require_inventory_history_query_dto = __commonJS({
  "apps/api/dist/modules/inventory/dto/inventory-history-query.dto.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = exports && exports.__metadata || function(k, v) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.InventoryHistoryQueryDto = void 0;
    var class_validator_1 = __require("class-validator");
    var InventoryHistoryQueryDto = class {
      page;
      pageSize;
      itemId;
      locationId;
      userId;
      type;
      from;
      to;
    };
    exports.InventoryHistoryQueryDto = InventoryHistoryQueryDto;
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.Matches)(/^\d{1,6}$/),
      __metadata("design:type", String)
    ], InventoryHistoryQueryDto.prototype, "page", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.Matches)(/^\d{1,3}$/),
      __metadata("design:type", String)
    ], InventoryHistoryQueryDto.prototype, "pageSize", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsUUID)(),
      __metadata("design:type", String)
    ], InventoryHistoryQueryDto.prototype, "itemId", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsUUID)(),
      __metadata("design:type", String)
    ], InventoryHistoryQueryDto.prototype, "locationId", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsUUID)(),
      __metadata("design:type", String)
    ], InventoryHistoryQueryDto.prototype, "userId", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsIn)(["RECEIPT", "ISSUE", "TRANSFER", "ADJUSTMENT", "COUNT_VARIANCE"]),
      __metadata("design:type", String)
    ], InventoryHistoryQueryDto.prototype, "type", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsString)(),
      (0, class_validator_1.MaxLength)(40),
      __metadata("design:type", String)
    ], InventoryHistoryQueryDto.prototype, "from", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsString)(),
      (0, class_validator_1.MaxLength)(40),
      __metadata("design:type", String)
    ], InventoryHistoryQueryDto.prototype, "to", void 0);
  }
});

// apps/api/dist/modules/inventory/dto/post-inventory-movement.dto.js
var require_post_inventory_movement_dto = __commonJS({
  "apps/api/dist/modules/inventory/dto/post-inventory-movement.dto.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = exports && exports.__metadata || function(k, v) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.PostInventoryMovementDto = void 0;
    var class_validator_1 = __require("class-validator");
    var PostInventoryMovementDto = class {
      itemId;
      sourceLocationId;
      quantity;
      movementType;
      targetLocationId;
      destination;
      reason;
    };
    exports.PostInventoryMovementDto = PostInventoryMovementDto;
    __decorate([
      (0, class_validator_1.IsUUID)(),
      __metadata("design:type", String)
    ], PostInventoryMovementDto.prototype, "itemId", void 0);
    __decorate([
      (0, class_validator_1.IsUUID)(),
      __metadata("design:type", String)
    ], PostInventoryMovementDto.prototype, "sourceLocationId", void 0);
    __decorate([
      (0, class_validator_1.IsNumberString)(),
      __metadata("design:type", String)
    ], PostInventoryMovementDto.prototype, "quantity", void 0);
    __decorate([
      (0, class_validator_1.IsIn)(["ISSUE", "TRANSFER"]),
      __metadata("design:type", String)
    ], PostInventoryMovementDto.prototype, "movementType", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsUUID)(),
      __metadata("design:type", String)
    ], PostInventoryMovementDto.prototype, "targetLocationId", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsString)(),
      (0, class_validator_1.MaxLength)(120),
      __metadata("design:type", String)
    ], PostInventoryMovementDto.prototype, "destination", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsString)(),
      (0, class_validator_1.MaxLength)(300),
      __metadata("design:type", String)
    ], PostInventoryMovementDto.prototype, "reason", void 0);
  }
});

// apps/api/dist/modules/inventory/dto/record-daily-usage.dto.js
var require_record_daily_usage_dto = __commonJS({
  "apps/api/dist/modules/inventory/dto/record-daily-usage.dto.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = exports && exports.__metadata || function(k, v) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.RecordDailyUsageDto = void 0;
    var class_validator_1 = __require("class-validator");
    var RecordDailyUsageDto = class {
      itemId;
      locationId;
      quantity;
      businessDate;
      purpose;
      notes;
    };
    exports.RecordDailyUsageDto = RecordDailyUsageDto;
    __decorate([
      (0, class_validator_1.IsUUID)(),
      __metadata("design:type", String)
    ], RecordDailyUsageDto.prototype, "itemId", void 0);
    __decorate([
      (0, class_validator_1.IsUUID)(),
      __metadata("design:type", String)
    ], RecordDailyUsageDto.prototype, "locationId", void 0);
    __decorate([
      (0, class_validator_1.IsNumberString)(),
      __metadata("design:type", String)
    ], RecordDailyUsageDto.prototype, "quantity", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsISO8601)(),
      __metadata("design:type", String)
    ], RecordDailyUsageDto.prototype, "businessDate", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsString)(),
      (0, class_validator_1.MaxLength)(120),
      __metadata("design:type", String)
    ], RecordDailyUsageDto.prototype, "purpose", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsString)(),
      (0, class_validator_1.MaxLength)(500),
      __metadata("design:type", String)
    ], RecordDailyUsageDto.prototype, "notes", void 0);
  }
});

// apps/api/dist/modules/inventory/dto/receive-inventory.dto.js
var require_receive_inventory_dto = __commonJS({
  "apps/api/dist/modules/inventory/dto/receive-inventory.dto.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = exports && exports.__metadata || function(k, v) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.ReceiveInventoryDto = void 0;
    var class_validator_1 = __require("class-validator");
    var ReceiveInventoryDto = class {
      itemId;
      locationId;
      quantity;
      unitCost;
      supplierDoc;
      reason;
    };
    exports.ReceiveInventoryDto = ReceiveInventoryDto;
    __decorate([
      (0, class_validator_1.IsUUID)(),
      __metadata("design:type", String)
    ], ReceiveInventoryDto.prototype, "itemId", void 0);
    __decorate([
      (0, class_validator_1.IsUUID)(),
      __metadata("design:type", String)
    ], ReceiveInventoryDto.prototype, "locationId", void 0);
    __decorate([
      (0, class_validator_1.IsNumberString)(),
      __metadata("design:type", String)
    ], ReceiveInventoryDto.prototype, "quantity", void 0);
    __decorate([
      (0, class_validator_1.IsNumberString)(),
      __metadata("design:type", String)
    ], ReceiveInventoryDto.prototype, "unitCost", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsString)(),
      (0, class_validator_1.IsNotEmpty)(),
      (0, class_validator_1.MaxLength)(80),
      __metadata("design:type", String)
    ], ReceiveInventoryDto.prototype, "supplierDoc", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsString)(),
      (0, class_validator_1.MaxLength)(300),
      __metadata("design:type", String)
    ], ReceiveInventoryDto.prototype, "reason", void 0);
  }
});

// apps/api/dist/modules/inventory/dto/update-inventory-item.dto.js
var require_update_inventory_item_dto = __commonJS({
  "apps/api/dist/modules/inventory/dto/update-inventory-item.dto.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = exports && exports.__metadata || function(k, v) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.UpdateInventoryItemDto = void 0;
    var class_validator_1 = __require("class-validator");
    var UpdateInventoryItemDto = class {
      name;
      unitOfMeasure;
      reorderLevel;
      reason;
    };
    exports.UpdateInventoryItemDto = UpdateInventoryItemDto;
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsString)(),
      (0, class_validator_1.IsNotEmpty)(),
      (0, class_validator_1.MaxLength)(160),
      __metadata("design:type", String)
    ], UpdateInventoryItemDto.prototype, "name", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsString)(),
      (0, class_validator_1.IsNotEmpty)(),
      (0, class_validator_1.MaxLength)(20),
      __metadata("design:type", String)
    ], UpdateInventoryItemDto.prototype, "unitOfMeasure", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsNumberString)(),
      __metadata("design:type", String)
    ], UpdateInventoryItemDto.prototype, "reorderLevel", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsString)(),
      (0, class_validator_1.MaxLength)(300),
      __metadata("design:type", String)
    ], UpdateInventoryItemDto.prototype, "reason", void 0);
  }
});

// apps/api/dist/modules/inventory/stock-ledger.js
var require_stock_ledger = __commonJS({
  "apps/api/dist/modules/inventory/stock-ledger.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.stockActor = stockActor;
    exports.recordStockMovementAudit = recordStockMovementAudit;
    exports.lockBalance = lockBalance;
    var audit_service_1 = require_audit_service();
    function stockActor(user) {
      return { userId: user.userId, name: user.fullName, organizationId: user.organizationId };
    }
    function recordStockMovementAudit(tx, actor, input) {
      const { movement, item, from, to } = input;
      const quantity = movement.quantity.toFixed(2);
      const where = from && to ? `${from.name} to ${to.name}` : (from ?? to)?.name ?? "";
      const reason = movement.reason ? ` Reason: ${movement.reason}.` : "";
      const source = movement.sourceType && !movement.reason?.includes(movement.sourceType) ? ` (${movement.sourceType})` : "";
      return tx.auditLog.create({
        data: (0, audit_service_1.auditData)({
          organizationId: actor.organizationId,
          propertyId: input.propertyId,
          userId: actor.userId,
          actorName: actor.name,
          module: "inventory",
          action: input.action,
          recordType: "inventory_movement",
          recordId: movement.id,
          itemId: item.id,
          itemName: item.name,
          summary: `${quantity} ${item.unitOfMeasure} ${item.name} - ${where}${source}.${reason}`.trim(),
          newValue: {
            movementType: movement.movementType,
            itemId: item.id,
            itemName: item.name,
            sku: item.sku,
            unit: item.unitOfMeasure,
            quantity: movement.quantity.toString(),
            unitCost: movement.unitCost.toString(),
            totalCost: movement.totalCost.toString(),
            sourceType: movement.sourceType,
            sourceId: movement.sourceId,
            reason: movement.reason,
            fromLocation: from ? {
              id: from.id,
              name: from.name,
              quantityBefore: movement.fromQuantityBefore?.toString() ?? null,
              quantityAfter: movement.fromQuantityAfter?.toString() ?? null
            } : null,
            toLocation: to ? {
              id: to.id,
              name: to.name,
              quantityBefore: movement.toQuantityBefore?.toString() ?? null,
              quantityAfter: movement.toQuantityAfter?.toString() ?? null
            } : null
          }
        })
      });
    }
    async function lockBalance(tx, itemId, locationId) {
      await tx.$executeRaw`SELECT 1 FROM inventory_balances WHERE item_id = ${itemId}::uuid AND location_id = ${locationId}::uuid FOR UPDATE`;
    }
  }
});

// apps/api/dist/modules/inventory/stock-receipt.js
var require_stock_receipt = __commonJS({
  "apps/api/dist/modules/inventory/stock-receipt.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.applyStockReceipt = applyStockReceipt;
    var client_1 = __require("@prisma/client");
    var stock_ledger_1 = require_stock_ledger();
    async function applyStockReceipt(tx, input) {
      const { itemId, locationId, quantity, unitCost } = input;
      await (0, stock_ledger_1.lockBalance)(tx, itemId, locationId);
      const existingBalance = await tx.inventoryBalance.findUnique({
        where: { itemId_locationId: { itemId, locationId } }
      });
      const currentQuantity = existingBalance?.quantityOnHand ?? new client_1.Prisma.Decimal(0);
      const currentValue = currentQuantity.mul(existingBalance?.averageCost ?? 0);
      const receiptValue = quantity.mul(unitCost);
      const nextQuantity = currentQuantity.plus(quantity);
      const averageCost = nextQuantity.gt(0) ? currentValue.plus(receiptValue).div(nextQuantity) : unitCost;
      const balance = await tx.inventoryBalance.upsert({
        where: { itemId_locationId: { itemId, locationId } },
        update: {
          quantityOnHand: nextQuantity,
          averageCost
        },
        create: {
          itemId,
          locationId,
          quantityOnHand: quantity,
          averageCost: unitCost
        },
        include: {
          item: true,
          location: true
        }
      });
      const movement = await tx.inventoryMovement.create({
        data: {
          propertyId: input.propertyId,
          itemId,
          toLocationId: locationId,
          journalEntryId: input.journalEntryId ?? null,
          movementType: client_1.InventoryMovementType.RECEIPT,
          status: client_1.InventoryMovementStatus.POSTED,
          sourceType: input.sourceType,
          sourceId: input.sourceId ?? null,
          quantity,
          unitCost,
          totalCost: receiptValue,
          businessDate: input.businessDate,
          postedAt: /* @__PURE__ */ new Date(),
          performedByUserId: input.actor.userId,
          performedByName: input.actor.name,
          reason: input.reason?.trim() || null,
          toQuantityBefore: currentQuantity,
          toQuantityAfter: balance.quantityOnHand
        },
        include: {
          item: true,
          fromLocation: true,
          toLocation: true
        }
      });
      await (0, stock_ledger_1.recordStockMovementAudit)(tx, input.actor, {
        action: input.auditAction ?? "stock_receipt",
        propertyId: input.propertyId,
        movement,
        item: balance.item,
        to: balance.location
      });
      return { balance, movement, receiptValue };
    }
  }
});

// apps/api/dist/modules/inventory/inventory.service.js
var require_inventory_service = __commonJS({
  "apps/api/dist/modules/inventory/inventory.service.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = exports && exports.__metadata || function(k, v) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.InventoryService = void 0;
    var common_1 = __require("@nestjs/common");
    var shared_1 = __require("@hms/shared");
    var client_1 = __require("@prisma/client");
    var prisma_service_1 = require_prisma_service();
    var audit_service_1 = require_audit_service();
    var stock_ledger_1 = require_stock_ledger();
    var stock_receipt_1 = require_stock_receipt();
    var InventoryService = class InventoryService {
      prisma;
      constructor(prisma) {
        this.prisma = prisma;
      }
      async getWorkspace(user) {
        const propertyId = this.requireProperty(user);
        await this.ensureDefaultLocations(propertyId);
        const allLocations = await this.prisma.inventoryLocation.findMany({
          where: { propertyId, active: true },
          orderBy: { name: "asc" }
        });
        const locations = allLocations.filter((location) => (0, shared_1.canUseStore)(user.permissions, location.code));
        const locationIds = locations.map((location) => location.id);
        const [items, balances, movements] = await Promise.all([
          this.prisma.inventoryItem.findMany({
            where: { propertyId, active: true },
            orderBy: { name: "asc" }
          }),
          this.prisma.inventoryBalance.findMany({
            where: {
              item: {
                propertyId,
                active: true
              },
              locationId: { in: locationIds }
            },
            include: {
              item: true,
              location: true
            },
            orderBy: {
              updatedAt: "desc"
            }
          }),
          this.prisma.inventoryMovement.findMany({
            where: {
              propertyId,
              OR: [{ fromLocationId: { in: locationIds } }, { toLocationId: { in: locationIds } }]
            },
            include: {
              item: true,
              fromLocation: true,
              toLocation: true
            },
            orderBy: { createdAt: "desc" },
            take: 20
          })
        ]);
        return {
          items: items.map(mapItem),
          locations: locations.map(mapLocation),
          // Stock can be sent to any store (e.g. Main Store to Bar), but only taken from your own.
          transferTargets: allLocations.map(mapLocation),
          stock: balances.map(mapBalance),
          movements: movements.map(mapMovement)
        };
      }
      async createItem(user, dto) {
        const propertyId = this.requireProperty(user);
        const sku = dto.sku.trim().toUpperCase();
        const name = dto.name.trim();
        const unitOfMeasure = dto.unitOfMeasure.trim().toUpperCase();
        const reorderLevel = new client_1.Prisma.Decimal(dto.reorderLevel || "0");
        if (!sku || !name || !unitOfMeasure) {
          throw new common_1.BadRequestException("SKU, material name, and unit are required.");
        }
        if (reorderLevel.lt(0)) {
          throw new common_1.BadRequestException("Reorder level cannot be negative.");
        }
        const existing = await this.prisma.inventoryItem.findFirst({
          where: { propertyId, sku }
        });
        if (existing) {
          throw new common_1.ConflictException(`Material SKU ${sku} already exists.`);
        }
        const item = await this.prisma.$transaction(async (tx) => {
          const created = await tx.inventoryItem.create({
            data: {
              propertyId,
              sku,
              name,
              unitOfMeasure,
              reorderLevel
            }
          });
          await tx.auditLog.create({
            data: (0, audit_service_1.auditData)({
              organizationId: user.organizationId,
              propertyId,
              userId: user.userId,
              actorName: user.fullName,
              module: "inventory",
              action: "item_created",
              recordType: "inventory_item",
              recordId: created.id,
              itemId: created.id,
              itemName: created.name,
              summary: `Created ${created.name} (${created.sku}), unit ${created.unitOfMeasure}, reorder level ${created.reorderLevel.toFixed(2)}.`,
              newValue: itemSnapshot(created)
            })
          });
          return created;
        });
        return mapItem(item);
      }
      // Edits an item's name, unit or reorder level. The SKU is fixed because POS sales are matched to it.
      async updateItem(user, itemId, dto) {
        const propertyId = this.requireProperty(user);
        return this.prisma.$transaction(async (tx) => {
          const before = await tx.inventoryItem.findFirst({ where: { id: itemId, propertyId } });
          if (!before) {
            throw new common_1.NotFoundException("Material was not found.");
          }
          const data = {};
          if (dto.name !== void 0) {
            const name = dto.name.trim();
            if (!name)
              throw new common_1.BadRequestException("Item name cannot be empty.");
            data.name = name;
          }
          if (dto.unitOfMeasure !== void 0) {
            const unit = dto.unitOfMeasure.trim().toUpperCase();
            if (!unit)
              throw new common_1.BadRequestException("Unit cannot be empty.");
            data.unitOfMeasure = unit;
          }
          if (dto.reorderLevel !== void 0) {
            const reorderLevel = new client_1.Prisma.Decimal(dto.reorderLevel || "0");
            if (reorderLevel.lt(0))
              throw new common_1.BadRequestException("Reorder level cannot be negative.");
            data.reorderLevel = reorderLevel;
          }
          const after = await tx.inventoryItem.update({ where: { id: before.id }, data });
          const changes = describeItemChanges(before, after);
          if (changes.length === 0) {
            return mapItem(after);
          }
          await tx.auditLog.create({
            data: (0, audit_service_1.auditData)({
              organizationId: user.organizationId,
              propertyId,
              userId: user.userId,
              actorName: user.fullName,
              module: "inventory",
              action: "item_updated",
              recordType: "inventory_item",
              recordId: after.id,
              itemId: after.id,
              itemName: after.name,
              summary: `${changes.join("; ")}.${dto.reason?.trim() ? ` Reason: ${dto.reason.trim()}.` : ""}`,
              previousValue: itemSnapshot(before),
              newValue: { ...itemSnapshot(after), reason: dto.reason?.trim() || null }
            })
          });
          return mapItem(after);
        });
      }
      async receiveStock(user, dto) {
        const propertyId = this.requireProperty(user);
        const quantity = new client_1.Prisma.Decimal(dto.quantity);
        const unitCost = new client_1.Prisma.Decimal(dto.unitCost);
        if (quantity.lte(0) || unitCost.lt(0)) {
          throw new common_1.BadRequestException("Receipt quantity must be greater than zero and cost cannot be negative.");
        }
        const supplierDoc = dto.supplierDoc?.trim();
        return this.prisma.$transaction(async (tx) => {
          const { item, location } = await this.getItemAndLocation(tx, propertyId, dto.itemId, dto.locationId);
          assertStoreAccess(user, location);
          const { balance, movement } = await (0, stock_receipt_1.applyStockReceipt)(tx, {
            propertyId,
            itemId: item.id,
            locationId: location.id,
            quantity,
            unitCost,
            businessDate: todayDateOnly(),
            sourceType: supplierDoc ? "SUPPLIER_DOC" : "MANUAL_RECEIPT",
            actor: (0, stock_ledger_1.stockActor)(user),
            reason: supplierDoc ? `Supplier document ${supplierDoc}` : dto.reason?.trim() || null
          });
          return {
            item: mapItem(item),
            balance: mapBalance(balance),
            movement: mapMovement(movement)
          };
        });
      }
      async postMovement(user, dto) {
        const propertyId = this.requireProperty(user);
        const quantity = new client_1.Prisma.Decimal(dto.quantity);
        const isTransfer = dto.movementType === "TRANSFER";
        const destination = dto.destination?.trim() || null;
        const reason = dto.reason?.trim() || (isTransfer ? null : destination);
        if (quantity.lte(0)) {
          throw new common_1.BadRequestException("Movement quantity must be greater than zero.");
        }
        return this.prisma.$transaction(async (tx) => {
          const source = await tx.inventoryLocation.findFirst({
            where: { id: dto.sourceLocationId, propertyId, active: true }
          });
          if (!source) {
            throw new common_1.NotFoundException("Source location was not found.");
          }
          assertStoreAccess(user, source);
          const item = await tx.inventoryItem.findFirst({
            where: { id: dto.itemId, propertyId, active: true }
          });
          if (!item) {
            throw new common_1.NotFoundException("Material was not found.");
          }
          let target = null;
          if (isTransfer) {
            if (!dto.targetLocationId) {
              throw new common_1.BadRequestException("Choose the target location for a transfer.");
            }
            target = await tx.inventoryLocation.findFirst({
              where: { id: dto.targetLocationId, propertyId, active: true }
            });
            if (!target) {
              throw new common_1.NotFoundException("Target location was not found.");
            }
            if (target.id === source.id) {
              throw new common_1.BadRequestException("Transfer target must be different from the source location.");
            }
          }
          await (0, stock_ledger_1.lockBalance)(tx, item.id, source.id);
          if (target)
            await (0, stock_ledger_1.lockBalance)(tx, item.id, target.id);
          const sourceBalance = await tx.inventoryBalance.findUnique({
            where: {
              itemId_locationId: {
                itemId: item.id,
                locationId: source.id
              }
            }
          });
          if (!sourceBalance || sourceBalance.quantityOnHand.lt(quantity)) {
            throw new common_1.ConflictException(`Only ${sourceBalance?.quantityOnHand?.toFixed(2) ?? "0.00"} ${item.unitOfMeasure} available in ${source.name}.`);
          }
          const unitCost = sourceBalance.averageCost;
          const totalCost = quantity.mul(unitCost);
          const updatedSource = await tx.inventoryBalance.update({
            where: {
              itemId_locationId: {
                itemId: item.id,
                locationId: source.id
              }
            },
            data: {
              quantityOnHand: sourceBalance.quantityOnHand.minus(quantity)
            }
          });
          let targetBalance = null;
          let targetBefore = null;
          if (target) {
            const existingTarget = await tx.inventoryBalance.findUnique({
              where: { itemId_locationId: { itemId: item.id, locationId: target.id } }
            });
            targetBefore = existingTarget?.quantityOnHand ?? new client_1.Prisma.Decimal(0);
            targetBalance = await tx.inventoryBalance.upsert({
              where: {
                itemId_locationId: {
                  itemId: item.id,
                  locationId: target.id
                }
              },
              update: {
                quantityOnHand: {
                  increment: quantity
                },
                averageCost: unitCost
              },
              create: {
                itemId: item.id,
                locationId: target.id,
                quantityOnHand: quantity,
                averageCost: unitCost
              },
              include: {
                item: true,
                location: true
              }
            });
          }
          const movement = await tx.inventoryMovement.create({
            data: {
              propertyId,
              itemId: item.id,
              fromLocationId: source.id,
              toLocationId: target?.id,
              movementType: isTransfer ? client_1.InventoryMovementType.TRANSFER : client_1.InventoryMovementType.ISSUE,
              status: client_1.InventoryMovementStatus.POSTED,
              sourceType: destination || "MANUAL_MOVEMENT",
              quantity,
              unitCost,
              totalCost,
              businessDate: todayDateOnly(),
              postedAt: /* @__PURE__ */ new Date(),
              performedByUserId: user.userId,
              performedByName: user.fullName,
              reason,
              fromQuantityBefore: sourceBalance.quantityOnHand,
              fromQuantityAfter: updatedSource.quantityOnHand,
              toQuantityBefore: targetBefore,
              toQuantityAfter: targetBalance?.quantityOnHand ?? null
            },
            include: {
              item: true,
              fromLocation: true,
              toLocation: true
            }
          });
          await (0, stock_ledger_1.recordStockMovementAudit)(tx, (0, stock_ledger_1.stockActor)(user), {
            action: isTransfer ? "stock_transfer" : "stock_issue",
            propertyId,
            movement,
            item,
            from: source,
            to: target
          });
          return {
            movement: mapMovement(movement),
            targetBalance: targetBalance ? mapBalance(targetBalance) : null
          };
        });
      }
      // Manual correction of a store balance (breakage, count difference, found stock). A reason is required.
      async adjustStock(user, dto) {
        const propertyId = this.requireProperty(user);
        const quantity = new client_1.Prisma.Decimal(dto.quantity);
        const reason = dto.reason?.trim() ?? "";
        const increase = dto.direction === "INCREASE";
        if (quantity.lte(0)) {
          throw new common_1.BadRequestException("Adjustment quantity must be greater than zero.");
        }
        if (reason.length < 3) {
          throw new common_1.BadRequestException("Give a reason for this stock adjustment.");
        }
        return this.prisma.$transaction(async (tx) => {
          const { item, location } = await this.getItemAndLocation(tx, propertyId, dto.itemId, dto.locationId);
          assertStoreAccess(user, location);
          await (0, stock_ledger_1.lockBalance)(tx, item.id, location.id);
          const existing = await tx.inventoryBalance.findUnique({
            where: { itemId_locationId: { itemId: item.id, locationId: location.id } }
          });
          const before = existing?.quantityOnHand ?? new client_1.Prisma.Decimal(0);
          if (!increase && before.lt(quantity)) {
            throw new common_1.ConflictException(`Only ${before.toFixed(2)} ${item.unitOfMeasure} recorded in ${location.name}.`);
          }
          const unitCost = existing?.averageCost ?? new client_1.Prisma.Decimal(0);
          const after = increase ? before.plus(quantity) : before.minus(quantity);
          const balance = await tx.inventoryBalance.upsert({
            where: { itemId_locationId: { itemId: item.id, locationId: location.id } },
            update: { quantityOnHand: after },
            create: { itemId: item.id, locationId: location.id, quantityOnHand: after, averageCost: unitCost },
            include: { item: true, location: true }
          });
          const movement = await tx.inventoryMovement.create({
            data: {
              propertyId,
              itemId: item.id,
              fromLocationId: increase ? null : location.id,
              toLocationId: increase ? location.id : null,
              movementType: client_1.InventoryMovementType.ADJUSTMENT,
              status: client_1.InventoryMovementStatus.POSTED,
              sourceType: increase ? "MANUAL_ADJUSTMENT_IN" : "MANUAL_ADJUSTMENT_OUT",
              quantity,
              unitCost,
              totalCost: quantity.mul(unitCost),
              businessDate: todayDateOnly(),
              postedAt: /* @__PURE__ */ new Date(),
              performedByUserId: user.userId,
              performedByName: user.fullName,
              reason,
              fromQuantityBefore: increase ? null : before,
              fromQuantityAfter: increase ? null : balance.quantityOnHand,
              toQuantityBefore: increase ? before : null,
              toQuantityAfter: increase ? balance.quantityOnHand : null
            },
            include: { item: true, fromLocation: true, toLocation: true }
          });
          await (0, stock_ledger_1.recordStockMovementAudit)(tx, (0, stock_ledger_1.stockActor)(user), {
            action: "stock_adjustment",
            propertyId,
            movement,
            item,
            from: increase ? null : location,
            to: increase ? location : null
          });
          return {
            balance: mapBalance(balance),
            movement: mapMovement(movement)
          };
        });
      }
      // Full stock history for the stores this user can open, newest first, with filters and pages.
      async listHistory(user, query) {
        const propertyId = this.requireProperty(user);
        const page = Math.max(1, Number.parseInt(query.page ?? "1", 10) || 1);
        const pageSize = Math.min(100, Math.max(1, Number.parseInt(query.pageSize ?? "25", 10) || 25));
        const allLocations = await this.prisma.inventoryLocation.findMany({ where: { propertyId } });
        const locationIds = allLocations.filter((location) => (0, shared_1.canUseStore)(user.permissions, location.code)).map((location) => location.id);
        if (query.locationId && !locationIds.includes(query.locationId)) {
          throw new common_1.ForbiddenException("You do not have access to that store.");
        }
        const scopedLocations = query.locationId ? [query.locationId] : locationIds;
        const and = [
          { propertyId },
          { OR: [{ fromLocationId: { in: scopedLocations } }, { toLocationId: { in: scopedLocations } }] }
        ];
        if (query.itemId)
          and.push({ itemId: query.itemId });
        if (query.type)
          and.push({ movementType: query.type });
        if (query.userId)
          and.push({ performedByUserId: query.userId });
        const from = (0, audit_service_1.parseDateBoundary)(query.from, "start");
        const to = (0, audit_service_1.parseDateBoundary)(query.to, "end");
        if (from || to)
          and.push({ createdAt: { ...from ? { gte: from } : {}, ...to ? { lt: to } : {} } });
        const where = { AND: and };
        const [total, movements, performers] = await Promise.all([
          this.prisma.inventoryMovement.count({ where }),
          this.prisma.inventoryMovement.findMany({
            where,
            include: { item: true, fromLocation: true, toLocation: true },
            orderBy: [{ createdAt: "desc" }, { id: "desc" }],
            skip: (page - 1) * pageSize,
            take: pageSize
          }),
          this.prisma.inventoryMovement.groupBy({
            by: ["performedByUserId", "performedByName"],
            where: { propertyId, performedByUserId: { not: null } },
            orderBy: { performedByName: "asc" }
          })
        ]);
        const staff = /* @__PURE__ */ new Map();
        for (const entry of performers) {
          if (entry.performedByUserId && !staff.has(entry.performedByUserId)) {
            staff.set(entry.performedByUserId, entry.performedByName ?? "Unnamed staff");
          }
        }
        return {
          page,
          pageSize,
          total,
          totalPages: Math.max(1, Math.ceil(total / pageSize)),
          staff: [...staff.entries()].map(([id, name]) => ({ id, name })),
          movements: movements.map(mapMovement)
        };
      }
      async listDailyUsage(user, date) {
        const propertyId = this.requireProperty(user);
        const businessDate = parseBusinessDate(date);
        const locations = await this.prisma.inventoryLocation.findMany({
          where: { propertyId, active: true }
        });
        const locationIds = locations.filter((location) => (0, shared_1.canUseStore)(user.permissions, location.code) && (0, shared_1.canRecordUsageAt)(location.code)).map((location) => location.id);
        const records = await this.prisma.dailyUsageRecord.findMany({
          where: { propertyId, businessDate, locationId: { in: locationIds } },
          include: {
            item: true,
            location: true
          },
          orderBy: { createdAt: "desc" }
        });
        return {
          businessDate: businessDate.toISOString().slice(0, 10),
          records: records.map(mapUsageRecord)
        };
      }
      // Usage notes are a log only: they never touch inventory balances or movements.
      async recordDailyUsage(user, dto) {
        const propertyId = this.requireProperty(user);
        const quantity = new client_1.Prisma.Decimal(dto.quantity);
        if (quantity.lte(0)) {
          throw new common_1.BadRequestException("Used quantity must be greater than zero.");
        }
        const { item, location } = await this.getItemAndLocation(this.prisma, propertyId, dto.itemId, dto.locationId);
        assertStoreAccess(user, location);
        if (!(0, shared_1.canRecordUsageAt)(location.code)) {
          throw new common_1.BadRequestException(`Goods used are recorded in the Bar or Restaurant outlet, not in ${location.name}.`);
        }
        const balance = await this.prisma.inventoryBalance.findUnique({
          where: {
            itemId_locationId: {
              itemId: item.id,
              locationId: location.id
            }
          }
        });
        const unitCost = balance?.averageCost ?? new client_1.Prisma.Decimal(0);
        const record = await this.prisma.dailyUsageRecord.create({
          data: {
            propertyId,
            itemId: item.id,
            locationId: location.id,
            businessDate: parseBusinessDate(dto.businessDate),
            quantity,
            unitCost,
            totalCost: quantity.mul(unitCost),
            purpose: dto.purpose?.trim() || null,
            notes: dto.notes?.trim() || null,
            recordedByUserId: user.userId,
            recordedByName: user.fullName
          },
          include: {
            item: true,
            location: true
          }
        });
        return mapUsageRecord(record);
      }
      async getItemAndLocation(tx, propertyId, itemId, locationId) {
        const [item, location] = await Promise.all([
          tx.inventoryItem.findFirst({
            where: { id: itemId, propertyId, active: true }
          }),
          tx.inventoryLocation.findFirst({
            where: { id: locationId, propertyId, active: true }
          })
        ]);
        if (!item) {
          throw new common_1.NotFoundException("Material was not found.");
        }
        if (!location) {
          throw new common_1.NotFoundException("Inventory location was not found.");
        }
        return { item, location };
      }
      async ensureDefaultLocations(propertyId) {
        const locationTypes = { MAIN: "STORE", BAR: "BAR", KITCHEN: "KITCHEN" };
        for (const location of shared_1.storeAccess.map((store) => [store.locationCode, store.label, locationTypes[store.locationCode]])) {
          await this.prisma.inventoryLocation.upsert({
            where: {
              propertyId_code: {
                propertyId,
                code: location[0]
              }
            },
            update: {
              name: location[1],
              locationType: location[2],
              active: true
            },
            create: {
              propertyId,
              code: location[0],
              name: location[1],
              locationType: location[2]
            }
          });
        }
      }
      requireProperty(user) {
        if (!user.propertyId) {
          throw new common_1.BadRequestException("A property context is required.");
        }
        return user.propertyId;
      }
    };
    exports.InventoryService = InventoryService;
    exports.InventoryService = InventoryService = __decorate([
      (0, common_1.Injectable)(),
      __metadata("design:paramtypes", [prisma_service_1.PrismaService])
    ], InventoryService);
    function assertStoreAccess(user, location) {
      if (!(0, shared_1.canUseStore)(user.permissions, location.code)) {
        throw new common_1.ForbiddenException(`You do not have access to ${location.name}.`);
      }
    }
    function mapItem(item) {
      return {
        id: item.id,
        sku: item.sku,
        name: item.name,
        category: materialCategory(item.sku),
        unit: item.unitOfMeasure,
        reorderLevel: Number(item.reorderLevel)
      };
    }
    function mapLocation(location) {
      return {
        id: location.id,
        name: location.name,
        type: location.locationType,
        code: location.code,
        usageAllowed: (0, shared_1.canRecordUsageAt)(location.code)
      };
    }
    function mapBalance(balance) {
      return {
        itemId: balance.itemId,
        locationId: balance.locationId,
        quantity: Number(balance.quantityOnHand),
        averageCost: Number(balance.averageCost),
        reorderLevel: Number(balance.item.reorderLevel)
      };
    }
    function mapMovement(movement) {
      const isTransfer = movement.movementType === client_1.InventoryMovementType.TRANSFER;
      const isReceipt = movement.movementType === client_1.InventoryMovementType.RECEIPT;
      const isAdjustment = movement.movementType === client_1.InventoryMovementType.ADJUSTMENT;
      const locationName = isReceipt ? movement.toLocation?.name ?? "Receiving" : isTransfer ? `${movement.fromLocation?.name ?? "Source"} to ${movement.toLocation?.name ?? "Target"}` : isAdjustment ? movement.toLocation?.name ?? movement.fromLocation?.name ?? "Adjustment" : movement.fromLocation?.name ?? "Issue";
      const decimal = (value) => value === null ? null : Number(value);
      return {
        id: movement.id,
        type: movement.movementType,
        action: movementActionLabel(movement),
        reference: `${movement.movementType.slice(0, 3)}-${movement.createdAt.getUTCFullYear()}-${movement.id.slice(0, 8)}`,
        itemId: movement.item.id ?? null,
        itemName: movement.item.name,
        sku: movement.item.sku ?? null,
        unit: movement.item.unitOfMeasure ?? null,
        locationName,
        quantity: Number(movement.quantity),
        value: Number(movement.totalCost),
        // null = older movement posted before staff tracking ("Not recorded").
        staffName: movement.performedByName,
        staffUserId: movement.performedByUserId,
        reason: movement.reason,
        source: movement.sourceType,
        createdAt: movement.createdAt.toISOString(),
        from: movement.fromLocation ? {
          name: movement.fromLocation.name,
          quantityBefore: decimal(movement.fromQuantityBefore),
          quantityAfter: decimal(movement.fromQuantityAfter)
        } : null,
        to: movement.toLocation ? {
          name: movement.toLocation.name,
          quantityBefore: decimal(movement.toQuantityBefore),
          quantityAfter: decimal(movement.toQuantityAfter)
        } : null,
        posting: isReceipt ? "Dr Inventory, Cr Supplier accrual" : isTransfer ? "No P&L impact, stock moved between locations" : isAdjustment ? "Stock count correction" : "Dr Cost of sales/expense, Cr Inventory"
      };
    }
    function movementActionLabel(movement) {
      const source = movement.sourceType ?? "";
      switch (movement.movementType) {
        case client_1.InventoryMovementType.RECEIPT:
          return source === "PURCHASE_ORDER" ? "Received (purchase order)" : "Received";
        case client_1.InventoryMovementType.TRANSFER:
          return "Transferred";
        case client_1.InventoryMovementType.ISSUE:
          return source.startsWith("Bar sale") ? "Sold (POS deduction)" : "Issued";
        case client_1.InventoryMovementType.ADJUSTMENT:
          if (source.startsWith("Bar order"))
            return "Returned (POS edit/void)";
          return movement.toLocation ? "Adjusted up" : "Adjusted down";
        default:
          return "Count variance";
      }
    }
    function itemSnapshot(item) {
      return {
        sku: item.sku,
        name: item.name,
        unitOfMeasure: item.unitOfMeasure,
        reorderLevel: item.reorderLevel.toString(),
        active: item.active
      };
    }
    function describeItemChanges(before, after) {
      const changes = [];
      if (before.name !== after.name)
        changes.push(`Name "${before.name}" to "${after.name}"`);
      if (before.unitOfMeasure !== after.unitOfMeasure)
        changes.push(`Unit ${before.unitOfMeasure} to ${after.unitOfMeasure}`);
      if (!before.reorderLevel.eq(after.reorderLevel)) {
        changes.push(`Reorder level ${before.reorderLevel.toFixed(2)} to ${after.reorderLevel.toFixed(2)}`);
      }
      return changes;
    }
    function mapUsageRecord(record) {
      return {
        id: record.id,
        businessDate: record.businessDate.toISOString().slice(0, 10),
        itemId: record.item.id,
        itemName: record.item.name,
        unit: record.item.unitOfMeasure,
        locationId: record.location.id,
        locationName: record.location.name,
        locationType: record.location.locationType,
        quantity: Number(record.quantity),
        value: Number(record.totalCost),
        purpose: record.purpose,
        notes: record.notes,
        recordedBy: record.recordedByName,
        recordedAt: record.createdAt.toISOString()
      };
    }
    function parseBusinessDate(value) {
      if (!value) {
        return todayDateOnly();
      }
      const match = /^(\d{4})-(\d{2})-(\d{2})/.exec(value);
      if (!match) {
        throw new common_1.BadRequestException("Business date must be in YYYY-MM-DD format.");
      }
      return new Date(Date.UTC(Number(match[1]), Number(match[2]) - 1, Number(match[3])));
    }
    function materialCategory(sku) {
      if (sku.startsWith("FOOD"))
        return "Food";
      if (sku.startsWith("BAR") || sku.startsWith("BEV"))
        return "Beverage";
      if (sku.startsWith("HK"))
        return "Housekeeping";
      return "Materials";
    }
    function todayDateOnly() {
      const now = /* @__PURE__ */ new Date();
      return new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()));
    }
  }
});

// apps/api/dist/modules/inventory/inventory.controller.js
var require_inventory_controller = __commonJS({
  "apps/api/dist/modules/inventory/inventory.controller.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = exports && exports.__metadata || function(k, v) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var __param = exports && exports.__param || function(paramIndex, decorator) {
      return function(target, key) {
        decorator(target, key, paramIndex);
      };
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.InventoryController = void 0;
    var common_1 = __require("@nestjs/common");
    var current_user_decorator_1 = require_current_user_decorator();
    var require_permissions_decorator_1 = require_require_permissions_decorator();
    var adjust_inventory_dto_1 = require_adjust_inventory_dto();
    var create_inventory_item_dto_1 = require_create_inventory_item_dto();
    var inventory_history_query_dto_1 = require_inventory_history_query_dto();
    var post_inventory_movement_dto_1 = require_post_inventory_movement_dto();
    var record_daily_usage_dto_1 = require_record_daily_usage_dto();
    var receive_inventory_dto_1 = require_receive_inventory_dto();
    var update_inventory_item_dto_1 = require_update_inventory_item_dto();
    var inventory_service_1 = require_inventory_service();
    var InventoryController = class InventoryController {
      inventory;
      constructor(inventory) {
        this.inventory = inventory;
      }
      workspace(user) {
        return this.inventory.getWorkspace(user);
      }
      createItem(user, dto) {
        return this.inventory.createItem(user, dto);
      }
      updateItem(user, itemId, dto) {
        return this.inventory.updateItem(user, itemId, dto);
      }
      receiveStock(user, dto) {
        return this.inventory.receiveStock(user, dto);
      }
      postMovement(user, dto) {
        return this.inventory.postMovement(user, dto);
      }
      adjustStock(user, dto) {
        return this.inventory.adjustStock(user, dto);
      }
      history(user, query) {
        return this.inventory.listHistory(user, query);
      }
      dailyUsage(user, date) {
        return this.inventory.listDailyUsage(user, date);
      }
      recordDailyUsage(user, dto) {
        return this.inventory.recordDailyUsage(user, dto);
      }
    };
    exports.InventoryController = InventoryController;
    __decorate([
      (0, require_permissions_decorator_1.RequirePermissions)("inventory.view"),
      (0, common_1.Get)(),
      __param(0, (0, current_user_decorator_1.CurrentUser)()),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", [Object]),
      __metadata("design:returntype", void 0)
    ], InventoryController.prototype, "workspace", null);
    __decorate([
      (0, require_permissions_decorator_1.RequirePermissions)("inventory.view"),
      (0, common_1.Post)("items"),
      __param(0, (0, current_user_decorator_1.CurrentUser)()),
      __param(1, (0, common_1.Body)()),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", [Object, create_inventory_item_dto_1.CreateInventoryItemDto]),
      __metadata("design:returntype", void 0)
    ], InventoryController.prototype, "createItem", null);
    __decorate([
      (0, require_permissions_decorator_1.RequirePermissions)("inventory.view"),
      (0, common_1.Patch)("items/:itemId"),
      __param(0, (0, current_user_decorator_1.CurrentUser)()),
      __param(1, (0, common_1.Param)("itemId", new common_1.ParseUUIDPipe())),
      __param(2, (0, common_1.Body)()),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", [Object, String, update_inventory_item_dto_1.UpdateInventoryItemDto]),
      __metadata("design:returntype", void 0)
    ], InventoryController.prototype, "updateItem", null);
    __decorate([
      (0, require_permissions_decorator_1.RequirePermissions)("inventory.view"),
      (0, common_1.Post)("receipts"),
      __param(0, (0, current_user_decorator_1.CurrentUser)()),
      __param(1, (0, common_1.Body)()),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", [Object, receive_inventory_dto_1.ReceiveInventoryDto]),
      __metadata("design:returntype", void 0)
    ], InventoryController.prototype, "receiveStock", null);
    __decorate([
      (0, require_permissions_decorator_1.RequirePermissions)("inventory.view"),
      (0, common_1.Post)("movements"),
      __param(0, (0, current_user_decorator_1.CurrentUser)()),
      __param(1, (0, common_1.Body)()),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", [Object, post_inventory_movement_dto_1.PostInventoryMovementDto]),
      __metadata("design:returntype", void 0)
    ], InventoryController.prototype, "postMovement", null);
    __decorate([
      (0, require_permissions_decorator_1.RequirePermissions)("inventory.view"),
      (0, common_1.Post)("adjustments"),
      __param(0, (0, current_user_decorator_1.CurrentUser)()),
      __param(1, (0, common_1.Body)()),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", [Object, adjust_inventory_dto_1.AdjustInventoryDto]),
      __metadata("design:returntype", void 0)
    ], InventoryController.prototype, "adjustStock", null);
    __decorate([
      (0, require_permissions_decorator_1.RequirePermissions)("inventory.view"),
      (0, common_1.Get)("history"),
      __param(0, (0, current_user_decorator_1.CurrentUser)()),
      __param(1, (0, common_1.Query)()),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", [Object, inventory_history_query_dto_1.InventoryHistoryQueryDto]),
      __metadata("design:returntype", void 0)
    ], InventoryController.prototype, "history", null);
    __decorate([
      (0, require_permissions_decorator_1.RequirePermissions)("inventory.view"),
      (0, common_1.Get)("daily-usage"),
      __param(0, (0, current_user_decorator_1.CurrentUser)()),
      __param(1, (0, common_1.Query)("date")),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", [Object, String]),
      __metadata("design:returntype", void 0)
    ], InventoryController.prototype, "dailyUsage", null);
    __decorate([
      (0, require_permissions_decorator_1.RequirePermissions)("inventory.view"),
      (0, common_1.Post)("daily-usage"),
      __param(0, (0, current_user_decorator_1.CurrentUser)()),
      __param(1, (0, common_1.Body)()),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", [Object, record_daily_usage_dto_1.RecordDailyUsageDto]),
      __metadata("design:returntype", void 0)
    ], InventoryController.prototype, "recordDailyUsage", null);
    exports.InventoryController = InventoryController = __decorate([
      (0, common_1.Controller)("inventory"),
      __metadata("design:paramtypes", [inventory_service_1.InventoryService])
    ], InventoryController);
  }
});

// apps/api/dist/modules/inventory/inventory.module.js
var require_inventory_module = __commonJS({
  "apps/api/dist/modules/inventory/inventory.module.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.InventoryModule = void 0;
    var common_1 = __require("@nestjs/common");
    var inventory_controller_1 = require_inventory_controller();
    var inventory_service_1 = require_inventory_service();
    var InventoryModule = class InventoryModule {
    };
    exports.InventoryModule = InventoryModule;
    exports.InventoryModule = InventoryModule = __decorate([
      (0, common_1.Module)({
        controllers: [inventory_controller_1.InventoryController],
        providers: [inventory_service_1.InventoryService]
      })
    ], InventoryModule);
  }
});

// apps/api/dist/common/auth/require-any-permissions.decorator.js
var require_require_any_permissions_decorator = __commonJS({
  "apps/api/dist/common/auth/require-any-permissions.decorator.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.RequireAnyPermissions = exports.ANY_PERMISSIONS_KEY = void 0;
    var common_1 = __require("@nestjs/common");
    exports.ANY_PERMISSIONS_KEY = "anyPermissions";
    var RequireAnyPermissions = (...permissions) => (0, common_1.SetMetadata)(exports.ANY_PERMISSIONS_KEY, permissions);
    exports.RequireAnyPermissions = RequireAnyPermissions;
  }
});

// apps/api/dist/modules/pos/pos-charge-description.js
var require_pos_charge_description = __commonJS({
  "apps/api/dist/modules/pos/pos-charge-description.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.posChargeDescription = posChargeDescription;
    function posChargeDescription(orderNumber, items, voided = false) {
      const purchases = items.map((item) => {
        const variant = item.productVariant.name.trim();
        const name = item.productVariant.product.name;
        const label = variant && variant.toLowerCase() !== "regular" ? `${name} (${variant})` : name;
        return `${item.quantity.toString()} x ${label}`;
      });
      const prefix = voided ? "Void: " : "";
      return purchases.length ? `${prefix}${purchases.join("; ")} - Order ${orderNumber}` : `${prefix}POS order ${orderNumber}`;
    }
  }
});

// apps/api/dist/modules/invoices/invoices.service.js
var require_invoices_service = __commonJS({
  "apps/api/dist/modules/invoices/invoices.service.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = exports && exports.__metadata || function(k, v) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.InvoicesService = void 0;
    var common_1 = __require("@nestjs/common");
    var client_1 = __require("@prisma/client");
    var prisma_service_1 = require_prisma_service();
    var pos_charge_description_1 = require_pos_charge_description();
    var InvoicesService = class InvoicesService {
      prisma;
      constructor(prisma) {
        this.prisma = prisma;
      }
      async searchReservations(user, query) {
        const propertyId = this.requireProperty(user);
        const search = query.trim();
        if (search.length < 2) {
          throw new common_1.BadRequestException("Enter at least 2 characters to search invoices.");
        }
        const reservations = await this.prisma.reservation.findMany({
          where: {
            propertyId,
            OR: [
              { reservationNumber: { contains: search, mode: "insensitive" } },
              { primaryGuest: { firstName: { contains: search, mode: "insensitive" } } },
              { primaryGuest: { lastName: { contains: search, mode: "insensitive" } } },
              { primaryGuest: { email: { contains: search, mode: "insensitive" } } },
              { primaryGuest: { phone: { contains: search, mode: "insensitive" } } },
              { primaryGuest: { documentNumber: { contains: search, mode: "insensitive" } } }
            ]
          },
          include: {
            primaryGuest: true,
            reservationRooms: {
              include: {
                room: true,
                roomType: true
              }
            },
            folios: {
              include: {
                items: {
                  orderBy: { postedAt: "asc" }
                }
              },
              orderBy: { openedAt: "asc" }
            }
          },
          orderBy: [{ arrivalDate: "desc" }, { reservationNumber: "desc" }],
          take: 20
        });
        const legacyOrderIds = [...new Set(reservations.flatMap((reservation) => reservation.folios.flatMap((folio) => folio.items.filter((item) => item.itemType === client_1.FolioItemType.POS_CHARGE && item.sourceId && (item.sourceType === "POS_ORDER" || item.sourceType === "POS_ORDER_VOID") && /^(Void )?POS order /i.test(item.description)).map((item) => item.sourceId))))];
        const legacyOrders = legacyOrderIds.length ? await this.prisma.posOrder.findMany({
          where: { propertyId, id: { in: legacyOrderIds } },
          include: { items: { include: { productVariant: { include: { product: true } } } } }
        }) : [];
        const legacyOrderMap = new Map(legacyOrders.map((order) => [order.id, order]));
        return reservations.map((reservation) => {
          const assignedRoom = reservation.reservationRooms[0] ?? null;
          const folioItems = reservation.folios.flatMap((folio) => folio.items.map((item) => ({
            id: item.id,
            folioId: folio.id,
            folioNumber: folio.folioNumber,
            itemType: item.itemType,
            sourceType: item.sourceType,
            description: item.sourceId && legacyOrderMap.has(item.sourceId) && item.itemType === client_1.FolioItemType.POS_CHARGE && (item.sourceType === "POS_ORDER" || item.sourceType === "POS_ORDER_VOID") && /^(Void )?POS order /i.test(item.description) ? (0, pos_charge_description_1.posChargeDescription)(legacyOrderMap.get(item.sourceId).orderNumber, legacyOrderMap.get(item.sourceId).items, item.sourceType === "POS_ORDER_VOID") : item.description,
            quantity: money(item.quantity),
            unitPrice: money(item.unitPrice),
            totalAmount: money(item.totalAmount),
            postedAt: item.postedAt
          })));
          return {
            id: reservation.id,
            reservationNumber: reservation.reservationNumber,
            status: reservation.status,
            arrivalDate: reservation.arrivalDate,
            departureDate: reservation.departureDate,
            guest: {
              id: reservation.primaryGuest.id,
              firstName: reservation.primaryGuest.firstName,
              lastName: reservation.primaryGuest.lastName,
              email: reservation.primaryGuest.email,
              phone: reservation.primaryGuest.phone,
              documentNumber: reservation.primaryGuest.documentNumber
            },
            room: assignedRoom ? {
              id: assignedRoom.room?.id ?? null,
              roomNumber: assignedRoom.room?.roomNumber ?? null,
              roomType: assignedRoom.roomType.name,
              nightlyRate: money(assignedRoom.nightlyRate)
            } : null,
            projectedRoomCharge: assignedRoom ? {
              id: `projected-${assignedRoom.id}`,
              itemType: client_1.FolioItemType.ROOM_CHARGE,
              description: `Room charge for ${stayNights(reservation.arrivalDate, reservation.departureDate)} night${stayNights(reservation.arrivalDate, reservation.departureDate) === 1 ? "" : "s"}`,
              quantity: String(stayNights(reservation.arrivalDate, reservation.departureDate)),
              unitPrice: money(assignedRoom.nightlyRate),
              totalAmount: money(assignedRoom.nightlyRate.mul(stayNights(reservation.arrivalDate, reservation.departureDate))),
              postedAt: reservation.arrivalDate
            } : null,
            folios: reservation.folios.map((folio) => ({
              id: folio.id,
              folioNumber: folio.folioNumber,
              status: folio.status,
              balance: money(folio.balance),
              openedAt: folio.openedAt,
              closedAt: folio.closedAt
            })),
            items: folioItems
          };
        });
      }
      requireProperty(user) {
        if (!user.propertyId) {
          throw new common_1.BadRequestException("A property context is required.");
        }
        return user.propertyId;
      }
    };
    exports.InvoicesService = InvoicesService;
    exports.InvoicesService = InvoicesService = __decorate([
      (0, common_1.Injectable)(),
      __metadata("design:paramtypes", [prisma_service_1.PrismaService])
    ], InvoicesService);
    function stayNights(arrivalDate, departureDate) {
      const millisecondsPerDay = 24 * 60 * 60 * 1e3;
      return Math.max(1, Math.round((departureDate.getTime() - arrivalDate.getTime()) / millisecondsPerDay));
    }
    function money(value) {
      return value.toFixed(2);
    }
  }
});

// apps/api/dist/modules/invoices/invoices.controller.js
var require_invoices_controller = __commonJS({
  "apps/api/dist/modules/invoices/invoices.controller.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = exports && exports.__metadata || function(k, v) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var __param = exports && exports.__param || function(paramIndex, decorator) {
      return function(target, key) {
        decorator(target, key, paramIndex);
      };
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.InvoicesController = void 0;
    var common_1 = __require("@nestjs/common");
    var require_any_permissions_decorator_1 = require_require_any_permissions_decorator();
    var current_user_decorator_1 = require_current_user_decorator();
    var invoices_service_1 = require_invoices_service();
    var InvoicesController = class InvoicesController {
      invoices;
      constructor(invoices) {
        this.invoices = invoices;
      }
      searchReservations(user, query) {
        return this.invoices.searchReservations(user, query ?? "");
      }
    };
    exports.InvoicesController = InvoicesController;
    __decorate([
      (0, require_any_permissions_decorator_1.RequireAnyPermissions)("front_office.view", "accounting.view", "users.view"),
      (0, common_1.Get)("reservations"),
      __param(0, (0, current_user_decorator_1.CurrentUser)()),
      __param(1, (0, common_1.Query)("query")),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", [Object, String]),
      __metadata("design:returntype", void 0)
    ], InvoicesController.prototype, "searchReservations", null);
    exports.InvoicesController = InvoicesController = __decorate([
      (0, common_1.Controller)("invoices"),
      __metadata("design:paramtypes", [invoices_service_1.InvoicesService])
    ], InvoicesController);
  }
});

// apps/api/dist/modules/invoices/invoices.module.js
var require_invoices_module = __commonJS({
  "apps/api/dist/modules/invoices/invoices.module.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.InvoicesModule = void 0;
    var common_1 = __require("@nestjs/common");
    var invoices_controller_1 = require_invoices_controller();
    var invoices_service_1 = require_invoices_service();
    var InvoicesModule = class InvoicesModule {
    };
    exports.InvoicesModule = InvoicesModule;
    exports.InvoicesModule = InvoicesModule = __decorate([
      (0, common_1.Module)({
        controllers: [invoices_controller_1.InvoicesController],
        providers: [invoices_service_1.InvoicesService]
      })
    ], InvoicesModule);
  }
});

// apps/api/dist/modules/organizations/organizations.service.js
var require_organizations_service = __commonJS({
  "apps/api/dist/modules/organizations/organizations.service.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = exports && exports.__metadata || function(k, v) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.OrganizationsService = void 0;
    var common_1 = __require("@nestjs/common");
    var prisma_service_1 = require_prisma_service();
    var OrganizationsService = class OrganizationsService {
      prisma;
      constructor(prisma) {
        this.prisma = prisma;
      }
      async getCurrent(organizationId) {
        const organization = await this.prisma.organization.findUnique({
          where: { id: organizationId },
          include: {
            properties: {
              orderBy: { name: "asc" }
            }
          }
        });
        if (!organization) {
          throw new common_1.NotFoundException("Organization was not found.");
        }
        return organization;
      }
    };
    exports.OrganizationsService = OrganizationsService;
    exports.OrganizationsService = OrganizationsService = __decorate([
      (0, common_1.Injectable)(),
      __metadata("design:paramtypes", [prisma_service_1.PrismaService])
    ], OrganizationsService);
  }
});

// apps/api/dist/modules/organizations/organizations.controller.js
var require_organizations_controller = __commonJS({
  "apps/api/dist/modules/organizations/organizations.controller.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = exports && exports.__metadata || function(k, v) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var __param = exports && exports.__param || function(paramIndex, decorator) {
      return function(target, key) {
        decorator(target, key, paramIndex);
      };
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.OrganizationsController = void 0;
    var common_1 = __require("@nestjs/common");
    var current_user_decorator_1 = require_current_user_decorator();
    var require_permissions_decorator_1 = require_require_permissions_decorator();
    var organizations_service_1 = require_organizations_service();
    var OrganizationsController = class OrganizationsController {
      organizations;
      constructor(organizations) {
        this.organizations = organizations;
      }
      getCurrent(user) {
        return this.organizations.getCurrent(user.organizationId);
      }
    };
    exports.OrganizationsController = OrganizationsController;
    __decorate([
      (0, require_permissions_decorator_1.RequirePermissions)("properties.view"),
      (0, common_1.Get)("current"),
      __param(0, (0, current_user_decorator_1.CurrentUser)()),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", [Object]),
      __metadata("design:returntype", void 0)
    ], OrganizationsController.prototype, "getCurrent", null);
    exports.OrganizationsController = OrganizationsController = __decorate([
      (0, common_1.Controller)("organizations"),
      __metadata("design:paramtypes", [organizations_service_1.OrganizationsService])
    ], OrganizationsController);
  }
});

// apps/api/dist/modules/organizations/organizations.module.js
var require_organizations_module = __commonJS({
  "apps/api/dist/modules/organizations/organizations.module.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.OrganizationsModule = void 0;
    var common_1 = __require("@nestjs/common");
    var organizations_controller_1 = require_organizations_controller();
    var organizations_service_1 = require_organizations_service();
    var OrganizationsModule = class OrganizationsModule {
    };
    exports.OrganizationsModule = OrganizationsModule;
    exports.OrganizationsModule = OrganizationsModule = __decorate([
      (0, common_1.Module)({
        controllers: [organizations_controller_1.OrganizationsController],
        providers: [organizations_service_1.OrganizationsService]
      })
    ], OrganizationsModule);
  }
});

// apps/api/dist/modules/persistence/dto/record-transition.dto.js
var require_record_transition_dto = __commonJS({
  "apps/api/dist/modules/persistence/dto/record-transition.dto.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = exports && exports.__metadata || function(k, v) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.RecordTransitionDto = exports.persistenceStages = void 0;
    var class_validator_1 = __require("class-validator");
    exports.persistenceStages = ["PREVIEW", "SCHEMA_READY", "API_READY", "DB_READY", "BLOCKED"];
    var RecordTransitionDto = class {
      moduleId;
      targetStage;
      note;
    };
    exports.RecordTransitionDto = RecordTransitionDto;
    __decorate([
      (0, class_validator_1.IsString)(),
      __metadata("design:type", String)
    ], RecordTransitionDto.prototype, "moduleId", void 0);
    __decorate([
      (0, class_validator_1.IsIn)(exports.persistenceStages),
      __metadata("design:type", String)
    ], RecordTransitionDto.prototype, "targetStage", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsString)(),
      __metadata("design:type", String)
    ], RecordTransitionDto.prototype, "note", void 0);
  }
});

// apps/api/dist/modules/persistence/persistence.service.js
var require_persistence_service = __commonJS({
  "apps/api/dist/modules/persistence/persistence.service.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = exports && exports.__metadata || function(k, v) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.PersistenceService = void 0;
    var common_1 = __require("@nestjs/common");
    var prisma_service_1 = require_prisma_service();
    var areas = [
      {
        id: "front-office",
        name: "Front Office",
        datastore: "Guests, reservations, folios, room status",
        apiSurface: "/front-office/*",
        stage: "DB_READY",
        requiredChecks: ["schema", "validation", "audit", "permissions", "save-and-reload tests"]
      },
      {
        id: "pos",
        name: "POS Cashier",
        datastore: "Outlets, orders, order items, payments",
        apiSurface: "/pos/*",
        stage: "DB_READY",
        requiredChecks: ["payment receipt policy", "idempotency", "journal posting", "audit", "tests"]
      },
      {
        id: "inventory",
        name: "Inventory Control",
        datastore: "Items, locations, stock balances, stock movements",
        apiSurface: "/inventory/*",
        stage: "SCHEMA_READY",
        requiredChecks: ["schema", "movement service", "weighted average cost", "audit", "tests"]
      },
      {
        id: "purchasing",
        name: "Purchasing and AP",
        datastore: "Suppliers, purchase orders, goods received, supplier invoices",
        apiSurface: "/purchasing/*",
        stage: "SCHEMA_READY",
        requiredChecks: ["schema", "approval workflow", "invoice matching", "AP posting", "tests"]
      },
      {
        id: "finance",
        name: "Finance Close",
        datastore: "Accounts, periods, journals, journal lines",
        apiSurface: "/accounting/*",
        stage: "DB_READY",
        requiredChecks: ["balanced journals", "period lock", "close guard", "audit", "tests"]
      },
      {
        id: "reports",
        name: "Management Reports",
        datastore: "Report snapshots and export queue",
        apiSurface: "/reports/*",
        stage: "SCHEMA_READY",
        requiredChecks: ["query views", "export queue", "permission guard", "audit", "tests"]
      },
      {
        id: "admin",
        name: "Administration",
        datastore: "Users, roles, permissions, settings, audit",
        apiSurface: "/users, /iam, /properties, /audit",
        stage: "API_READY",
        requiredChecks: ["role APIs", "settings APIs", "audit search", "MFA policy", "tests"]
      },
      {
        id: "offline-sync",
        name: "Offline POS Sync",
        datastore: "Terminals, devices, sync queue, conflict ledger",
        apiSurface: "/sync/*",
        stage: "SCHEMA_READY",
        requiredChecks: ["schema", "idempotency ledger", "retry route", "conflict resolution", "tests"]
      }
    ];
    var PersistenceService = class PersistenceService {
      prisma;
      constructor(prisma) {
        this.prisma = prisma;
      }
      getStatus() {
        return {
          phase: "Phase 10 Backend Persistence",
          generatedAt: (/* @__PURE__ */ new Date()).toISOString(),
          checklist: [
            "Add or confirm database models and migrations for each workflow.",
            "Create API endpoints with validation and permission checks.",
            "Persist create/update actions and reload saved data.",
            "Record audit events for sensitive transitions.",
            "Add save-and-reload tests before marking a module production ready."
          ],
          areas
        };
      }
      async recordTransition(user, dto) {
        const area = areas.find((entry) => entry.id === dto.moduleId);
        if (!area) {
          throw new common_1.NotFoundException(`Persistence area ${dto.moduleId} was not found.`);
        }
        const transition = await this.prisma.persistenceTransition.create({
          data: {
            organizationId: user.organizationId,
            propertyId: user.propertyId,
            userId: user.userId,
            moduleId: area.id,
            moduleName: area.name,
            previousStage: area.stage,
            targetStage: dto.targetStage,
            note: dto.note,
            requiredChecks: area.requiredChecks
          }
        });
        return {
          id: transition.id,
          phase: "Phase 10 Backend Persistence",
          moduleId: area.id,
          moduleName: area.name,
          previousStage: area.stage,
          targetStage: dto.targetStage,
          note: transition.note,
          requiredChecks: area.requiredChecks,
          actor: {
            userId: user.userId,
            email: user.email,
            organizationId: user.organizationId,
            propertyId: user.propertyId ?? null
          },
          createdAt: transition.createdAt.toISOString()
        };
      }
    };
    exports.PersistenceService = PersistenceService;
    exports.PersistenceService = PersistenceService = __decorate([
      (0, common_1.Injectable)(),
      __metadata("design:paramtypes", [prisma_service_1.PrismaService])
    ], PersistenceService);
  }
});

// apps/api/dist/modules/persistence/persistence.controller.js
var require_persistence_controller = __commonJS({
  "apps/api/dist/modules/persistence/persistence.controller.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = exports && exports.__metadata || function(k, v) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var __param = exports && exports.__param || function(paramIndex, decorator) {
      return function(target, key) {
        decorator(target, key, paramIndex);
      };
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.PersistenceController = void 0;
    var common_1 = __require("@nestjs/common");
    var current_user_decorator_1 = require_current_user_decorator();
    var require_permissions_decorator_1 = require_require_permissions_decorator();
    var record_transition_dto_1 = require_record_transition_dto();
    var persistence_service_1 = require_persistence_service();
    var PersistenceController = class PersistenceController {
      persistence;
      constructor(persistence) {
        this.persistence = persistence;
      }
      getStatus() {
        return this.persistence.getStatus();
      }
      recordTransition(user, dto) {
        return this.persistence.recordTransition(user, dto);
      }
    };
    exports.PersistenceController = PersistenceController;
    __decorate([
      (0, require_permissions_decorator_1.RequirePermissions)("settings.view"),
      (0, common_1.Get)("status"),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", []),
      __metadata("design:returntype", void 0)
    ], PersistenceController.prototype, "getStatus", null);
    __decorate([
      (0, require_permissions_decorator_1.RequirePermissions)("settings.manage"),
      (0, common_1.Post)("transitions"),
      __param(0, (0, current_user_decorator_1.CurrentUser)()),
      __param(1, (0, common_1.Body)()),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", [Object, record_transition_dto_1.RecordTransitionDto]),
      __metadata("design:returntype", void 0)
    ], PersistenceController.prototype, "recordTransition", null);
    exports.PersistenceController = PersistenceController = __decorate([
      (0, common_1.Controller)("persistence"),
      __metadata("design:paramtypes", [persistence_service_1.PersistenceService])
    ], PersistenceController);
  }
});

// apps/api/dist/modules/persistence/persistence.module.js
var require_persistence_module = __commonJS({
  "apps/api/dist/modules/persistence/persistence.module.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.PersistenceModule = void 0;
    var common_1 = __require("@nestjs/common");
    var persistence_controller_1 = require_persistence_controller();
    var persistence_service_1 = require_persistence_service();
    var PersistenceModule = class PersistenceModule {
    };
    exports.PersistenceModule = PersistenceModule;
    exports.PersistenceModule = PersistenceModule = __decorate([
      (0, common_1.Module)({
        controllers: [persistence_controller_1.PersistenceController],
        providers: [persistence_service_1.PersistenceService],
        exports: [persistence_service_1.PersistenceService]
      })
    ], PersistenceModule);
  }
});

// apps/api/dist/modules/pos/dto/menu.dto.js
var require_menu_dto = __commonJS({
  "apps/api/dist/modules/pos/dto/menu.dto.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = exports && exports.__metadata || function(k, v) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.CreateDiningTableDto = exports.UpdatePosProductDto = exports.CreatePosProductDto = exports.CreateProductCategoryDto = void 0;
    var class_transformer_1 = __require("class-transformer");
    var class_validator_1 = __require("class-validator");
    var DECIMAL = /^\d{1,12}(\.\d{1,4})?$/;
    var OPTIONAL_DECIMAL = /^(\d{1,12}(\.\d{1,4})?)?$/;
    var TAX_RATE = /^(0(\.\d{1,4})?|1(\.0{1,4})?)$/;
    var CreateProductCategoryDto = class {
      name;
      parentId;
    };
    exports.CreateProductCategoryDto = CreateProductCategoryDto;
    __decorate([
      (0, class_validator_1.IsString)(),
      (0, class_validator_1.IsNotEmpty)(),
      (0, class_validator_1.MaxLength)(80),
      __metadata("design:type", String)
    ], CreateProductCategoryDto.prototype, "name", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsUUID)(),
      __metadata("design:type", String)
    ], CreateProductCategoryDto.prototype, "parentId", void 0);
    var CreatePosProductDto = class {
      name;
      sku;
      categoryId;
      price;
      // Optional USD price; leave empty when the item is only sold in TSh.
      priceUsd;
      taxRate;
      outletIds;
      stockTracked;
      // Weekdays the item is served (0 = Sunday ... 6 = Saturday); empty = every day.
      menuDays;
    };
    exports.CreatePosProductDto = CreatePosProductDto;
    __decorate([
      (0, class_validator_1.IsString)(),
      (0, class_validator_1.IsNotEmpty)(),
      (0, class_validator_1.MaxLength)(120),
      __metadata("design:type", String)
    ], CreatePosProductDto.prototype, "name", void 0);
    __decorate([
      (0, class_validator_1.IsString)(),
      (0, class_validator_1.IsNotEmpty)(),
      (0, class_validator_1.MaxLength)(40),
      (0, class_validator_1.Matches)(/^[A-Za-z0-9._-]+$/, { message: "SKU may only contain letters, numbers, dots, dashes and underscores." }),
      __metadata("design:type", String)
    ], CreatePosProductDto.prototype, "sku", void 0);
    __decorate([
      (0, class_validator_1.IsUUID)(),
      __metadata("design:type", String)
    ], CreatePosProductDto.prototype, "categoryId", void 0);
    __decorate([
      (0, class_validator_1.IsString)(),
      (0, class_validator_1.Matches)(DECIMAL, { message: "Price must be a positive amount with up to 4 decimals." }),
      __metadata("design:type", String)
    ], CreatePosProductDto.prototype, "price", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsString)(),
      (0, class_validator_1.Matches)(DECIMAL, { message: "USD price must be a positive amount with up to 4 decimals." }),
      __metadata("design:type", String)
    ], CreatePosProductDto.prototype, "priceUsd", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsString)(),
      (0, class_validator_1.Matches)(TAX_RATE, { message: "Tax rate must be a fraction between 0 and 1 (0.16 = 16%)." }),
      __metadata("design:type", String)
    ], CreatePosProductDto.prototype, "taxRate", void 0);
    __decorate([
      (0, class_validator_1.IsArray)(),
      (0, class_validator_1.ArrayUnique)(),
      (0, class_validator_1.IsUUID)("all", { each: true }),
      __metadata("design:type", Array)
    ], CreatePosProductDto.prototype, "outletIds", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsBoolean)(),
      __metadata("design:type", Boolean)
    ], CreatePosProductDto.prototype, "stockTracked", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsArray)(),
      (0, class_validator_1.ArrayUnique)(),
      (0, class_validator_1.ArrayMaxSize)(7),
      (0, class_validator_1.IsInt)({ each: true }),
      (0, class_validator_1.Min)(0, { each: true }),
      (0, class_validator_1.Max)(6, { each: true }),
      __metadata("design:type", Array)
    ], CreatePosProductDto.prototype, "menuDays", void 0);
    var UpdatePosProductDto = class {
      name;
      categoryId;
      price;
      // Empty string clears the USD price so the item can no longer be sold in USD.
      priceUsd;
      taxRate;
      // Availability at every outlet the product is sold at (e.g. "86" an item).
      available;
      // Active=false retires the product from all menus without deleting order history.
      active;
      // When provided, replaces the set of outlets the product is sold at.
      outletIds;
      // Weekdays the item is served (0 = Sunday ... 6 = Saturday); empty = every day.
      menuDays;
    };
    exports.UpdatePosProductDto = UpdatePosProductDto;
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsString)(),
      (0, class_validator_1.IsNotEmpty)(),
      (0, class_validator_1.MaxLength)(120),
      __metadata("design:type", String)
    ], UpdatePosProductDto.prototype, "name", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsUUID)(),
      __metadata("design:type", String)
    ], UpdatePosProductDto.prototype, "categoryId", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsString)(),
      (0, class_validator_1.Matches)(DECIMAL, { message: "Price must be a positive amount with up to 4 decimals." }),
      __metadata("design:type", String)
    ], UpdatePosProductDto.prototype, "price", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsString)(),
      (0, class_validator_1.Matches)(OPTIONAL_DECIMAL, { message: "USD price must be a positive amount with up to 4 decimals." }),
      __metadata("design:type", String)
    ], UpdatePosProductDto.prototype, "priceUsd", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsString)(),
      (0, class_validator_1.Matches)(TAX_RATE, { message: "Tax rate must be a fraction between 0 and 1 (0.16 = 16%)." }),
      __metadata("design:type", String)
    ], UpdatePosProductDto.prototype, "taxRate", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsBoolean)(),
      __metadata("design:type", Boolean)
    ], UpdatePosProductDto.prototype, "available", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsBoolean)(),
      __metadata("design:type", Boolean)
    ], UpdatePosProductDto.prototype, "active", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsArray)(),
      (0, class_validator_1.ArrayUnique)(),
      (0, class_validator_1.IsUUID)("all", { each: true }),
      __metadata("design:type", Array)
    ], UpdatePosProductDto.prototype, "outletIds", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsArray)(),
      (0, class_validator_1.ArrayUnique)(),
      (0, class_validator_1.ArrayMaxSize)(7),
      (0, class_validator_1.IsInt)({ each: true }),
      (0, class_validator_1.Min)(0, { each: true }),
      (0, class_validator_1.Max)(6, { each: true }),
      __metadata("design:type", Array)
    ], UpdatePosProductDto.prototype, "menuDays", void 0);
    var CreateDiningTableDto = class {
      tableNumber;
      section;
      seats;
    };
    exports.CreateDiningTableDto = CreateDiningTableDto;
    __decorate([
      (0, class_validator_1.IsString)(),
      (0, class_validator_1.IsNotEmpty)(),
      (0, class_validator_1.MaxLength)(20),
      __metadata("design:type", String)
    ], CreateDiningTableDto.prototype, "tableNumber", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsString)(),
      (0, class_validator_1.MaxLength)(60),
      __metadata("design:type", String)
    ], CreateDiningTableDto.prototype, "section", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_transformer_1.Type)(() => Number),
      (0, class_validator_1.IsInt)(),
      (0, class_validator_1.Min)(1),
      (0, class_validator_1.Max)(50),
      __metadata("design:type", Number)
    ], CreateDiningTableDto.prototype, "seats", void 0);
  }
});

// apps/api/dist/modules/pos/pos-menu.service.js
var require_pos_menu_service = __commonJS({
  "apps/api/dist/modules/pos/pos-menu.service.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = exports && exports.__metadata || function(k, v) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.PosMenuService = void 0;
    var common_1 = __require("@nestjs/common");
    var shared_1 = __require("@hms/shared");
    var client_1 = __require("@prisma/client");
    var prisma_service_1 = require_prisma_service();
    var DEFAULT_VARIANT_NAME = "Standard";
    var PosMenuService = class PosMenuService {
      prisma;
      constructor(prisma) {
        this.prisma = prisma;
      }
      async getMenu(user) {
        const propertyId = requireProperty(user);
        const [outlets, categories, products] = await Promise.all([
          this.accessibleOutlets(user, propertyId),
          this.prisma.productCategory.findMany({
            where: { propertyId },
            include: { _count: { select: { products: true } } },
            orderBy: { name: "asc" }
          }),
          this.prisma.product.findMany({
            where: { propertyId },
            include: {
              category: true,
              variants: {
                include: { outletProducts: { include: { outlet: true } } },
                orderBy: { createdAt: "asc" }
              }
            },
            orderBy: [{ active: "desc" }, { name: "asc" }]
          })
        ]);
        const outletIds = new Set(outlets.map((outlet) => outlet.id));
        return {
          outlets,
          categories: categories.map((category) => ({
            id: category.id,
            name: category.name,
            parentId: category.parentId,
            active: category.active,
            productCount: category._count.products
          })),
          products: products.map((product) => ({
            id: product.id,
            name: product.name,
            sku: product.sku,
            active: product.active,
            stockTracked: product.stockTracked,
            productType: product.productType,
            menuDays: product.menuDays,
            category: { id: product.category.id, name: product.category.name },
            variants: product.variants.map((variant) => ({
              id: variant.id,
              name: variant.name,
              sku: variant.sku,
              active: variant.active,
              basePrice: variant.basePrice.toFixed(2),
              outlets: variant.outletProducts.filter((entry) => outletIds.has(entry.outletId)).map((entry) => ({
                outletId: entry.outletId,
                outletName: entry.outlet.name,
                outletType: entry.outlet.outletType,
                price: entry.price.toFixed(2),
                priceUsd: entry.priceUsd ? entry.priceUsd.toFixed(2) : null,
                taxRate: entry.taxRate.toFixed(4),
                available: entry.available
              })).sort((a, b) => a.outletName.localeCompare(b.outletName))
            }))
          }))
        };
      }
      async createCategory(user, dto) {
        const propertyId = requireProperty(user);
        const name = dto.name.trim();
        if (dto.parentId) {
          const parent = await this.prisma.productCategory.findFirst({ where: { id: dto.parentId, propertyId } });
          if (!parent)
            throw new common_1.NotFoundException("Parent category was not found.");
        }
        const existing = await this.prisma.productCategory.findFirst({
          where: { propertyId, name: { equals: name, mode: "insensitive" } }
        });
        if (existing)
          throw new common_1.ConflictException(`A category named "${existing.name}" already exists.`);
        return this.prisma.$transaction(async (tx) => {
          const category = await tx.productCategory.create({
            data: { propertyId, name, parentId: dto.parentId }
          });
          await audit(tx, user, propertyId, "create_category", "product_category", category.id, void 0, {
            name: category.name,
            parentId: category.parentId
          });
          return category;
        });
      }
      async createProduct(user, dto) {
        const propertyId = requireProperty(user);
        const sku = dto.sku.trim().toUpperCase();
        const price = new client_1.Prisma.Decimal(dto.price);
        const priceUsd = dto.priceUsd ? new client_1.Prisma.Decimal(dto.priceUsd) : null;
        const taxRate = new client_1.Prisma.Decimal(dto.taxRate ?? "0");
        const category = await this.prisma.productCategory.findFirst({ where: { id: dto.categoryId, propertyId } });
        if (!category)
          throw new common_1.NotFoundException("Product category was not found.");
        const outlets = await this.resolveOutlets(user, propertyId, dto.outletIds);
        const duplicate = await this.prisma.product.findFirst({ where: { propertyId, sku } });
        if (duplicate)
          throw new common_1.ConflictException(`SKU ${sku} is already used by ${duplicate.name}.`);
        const productId = await this.prisma.$transaction(async (tx) => {
          const product = await tx.product.create({
            data: {
              propertyId,
              categoryId: category.id,
              name: dto.name.trim(),
              sku,
              stockTracked: dto.stockTracked ?? false,
              menuDays: (0, shared_1.normalizeMenuDays)(dto.menuDays),
              productType: dto.stockTracked ? client_1.ProductType.STOCKED : client_1.ProductType.NON_STOCKED,
              variants: {
                create: {
                  name: DEFAULT_VARIANT_NAME,
                  sku,
                  basePrice: price,
                  outletProducts: {
                    create: outlets.map((outlet) => ({ outletId: outlet.id, price, priceUsd, taxRate, available: true }))
                  }
                }
              }
            }
          });
          await audit(tx, user, propertyId, "create_product", "product", product.id, void 0, {
            name: product.name,
            sku: product.sku,
            categoryId: category.id,
            price: price.toFixed(2),
            priceUsd: priceUsd?.toFixed(2) ?? null,
            taxRate: taxRate.toFixed(4),
            menuDays: (0, shared_1.normalizeMenuDays)(dto.menuDays),
            outlets: outlets.map((outlet) => outlet.name)
          });
          return product.id;
        });
        return this.loadProduct(user, productId);
      }
      async updateProduct(user, productId, dto) {
        const propertyId = requireProperty(user);
        const product = await this.prisma.product.findFirst({
          where: { id: productId, propertyId },
          include: {
            variants: {
              include: { outletProducts: { include: { outlet: true } } },
              orderBy: { createdAt: "asc" }
            }
          }
        });
        if (!product)
          throw new common_1.NotFoundException("Product was not found.");
        const variant = product.variants.find((entry) => entry.active) ?? product.variants[0];
        if (!variant)
          throw new common_1.BadRequestException("This product has no variant to price.");
        if (dto.categoryId) {
          const category = await this.prisma.productCategory.findFirst({ where: { id: dto.categoryId, propertyId } });
          if (!category)
            throw new common_1.NotFoundException("Product category was not found.");
        }
        const accessible = await this.accessibleOutlets(user, propertyId);
        const accessibleIds = new Set(accessible.map((outlet) => outlet.id));
        const targetOutlets = dto.outletIds ? await this.resolveOutlets(user, propertyId, dto.outletIds) : null;
        const price = dto.price !== void 0 ? new client_1.Prisma.Decimal(dto.price) : void 0;
        const priceUsd = dto.priceUsd === void 0 ? void 0 : dto.priceUsd ? new client_1.Prisma.Decimal(dto.priceUsd) : null;
        const taxRate = dto.taxRate !== void 0 ? new client_1.Prisma.Decimal(dto.taxRate) : void 0;
        const currentScoped = variant.outletProducts.filter((entry) => accessibleIds.has(entry.outletId));
        const fallbackTaxRate = currentScoped[0]?.taxRate ?? variant.outletProducts[0]?.taxRate ?? new client_1.Prisma.Decimal(0);
        const previousValue = {
          name: product.name,
          categoryId: product.categoryId,
          active: product.active,
          menuDays: product.menuDays,
          price: variant.basePrice.toFixed(2),
          outlets: currentScoped.map((entry) => ({
            outlet: entry.outlet.name,
            price: entry.price.toFixed(2),
            priceUsd: entry.priceUsd?.toFixed(2) ?? null,
            taxRate: entry.taxRate.toFixed(4),
            available: entry.available
          }))
        };
        await this.prisma.$transaction(async (tx) => {
          await tx.product.update({
            where: { id: product.id },
            data: {
              name: dto.name?.trim(),
              categoryId: dto.categoryId,
              active: dto.active,
              menuDays: dto.menuDays ? (0, shared_1.normalizeMenuDays)(dto.menuDays) : void 0
            }
          });
          if (price) {
            await tx.productVariant.update({ where: { id: variant.id }, data: { basePrice: price } });
          }
          if (targetOutlets) {
            const targetIds = new Set(targetOutlets.map((outlet) => outlet.id));
            const removed = currentScoped.filter((entry) => !targetIds.has(entry.outletId)).map((entry) => entry.outletId);
            if (removed.length > 0) {
              await tx.outletProduct.deleteMany({
                where: { productVariantId: variant.id, outletId: { in: removed } }
              });
            }
            const existingIds = new Set(variant.outletProducts.map((entry) => entry.outletId));
            const added = targetOutlets.filter((outlet) => !existingIds.has(outlet.id));
            if (added.length > 0) {
              await tx.outletProduct.createMany({
                data: added.map((outlet) => ({
                  outletId: outlet.id,
                  productVariantId: variant.id,
                  price: price ?? variant.basePrice,
                  priceUsd: priceUsd !== void 0 ? priceUsd : currentScoped[0]?.priceUsd ?? variant.outletProducts[0]?.priceUsd ?? null,
                  taxRate: taxRate ?? fallbackTaxRate,
                  available: dto.available ?? true
                }))
              });
            }
          }
          const scopedIds = targetOutlets ? targetOutlets.map((outlet) => outlet.id) : currentScoped.map((entry) => entry.outletId);
          if (scopedIds.length > 0 && (price || priceUsd !== void 0 || taxRate || dto.available !== void 0)) {
            await tx.outletProduct.updateMany({
              where: { productVariantId: variant.id, outletId: { in: scopedIds } },
              data: { price, priceUsd, taxRate, available: dto.available }
            });
          }
          if (dto.active === false) {
            await tx.outletProduct.updateMany({
              where: { productVariant: { productId: product.id } },
              data: { available: false }
            });
          }
          await audit(tx, user, propertyId, "update_product", "product", product.id, previousValue, {
            name: dto.name,
            categoryId: dto.categoryId,
            active: dto.active,
            menuDays: dto.menuDays ? (0, shared_1.normalizeMenuDays)(dto.menuDays) : void 0,
            price: price?.toFixed(2),
            priceUsd: priceUsd === void 0 ? void 0 : priceUsd?.toFixed(2) ?? null,
            taxRate: taxRate?.toFixed(4),
            available: dto.available,
            outlets: targetOutlets?.map((outlet) => outlet.name)
          });
        });
        return this.loadProduct(user, product.id);
      }
      async listTables(user, outletId) {
        const propertyId = requireProperty(user);
        const outlet = await this.findAccessibleOutlet(user, propertyId, outletId);
        return this.prisma.diningTable.findMany({
          where: { outletId: outlet.id },
          orderBy: { tableNumber: "asc" }
        });
      }
      async createTable(user, outletId, dto) {
        const propertyId = requireProperty(user);
        const outlet = await this.findAccessibleOutlet(user, propertyId, outletId);
        const tableNumber = dto.tableNumber.trim();
        const existing = await this.prisma.diningTable.findUnique({
          where: { outletId_tableNumber: { outletId: outlet.id, tableNumber } }
        });
        if (existing)
          throw new common_1.ConflictException(`Table ${tableNumber} already exists at ${outlet.name}.`);
        return this.prisma.$transaction(async (tx) => {
          const table = await tx.diningTable.create({
            data: {
              outletId: outlet.id,
              tableNumber,
              section: dto.section?.trim() || null,
              seats: dto.seats ?? 2
            }
          });
          await audit(tx, user, propertyId, "create_table", "dining_table", table.id, void 0, {
            outlet: outlet.name,
            tableNumber: table.tableNumber,
            section: table.section,
            seats: table.seats
          });
          return table;
        });
      }
      async listTerminals(user) {
        const propertyId = requireProperty(user);
        const outlets = await this.accessibleOutlets(user, propertyId);
        const terminals = await this.prisma.posTerminal.findMany({
          where: { outletId: { in: outlets.map((outlet) => outlet.id) } },
          include: { outlet: { select: { id: true, name: true, outletType: true } } },
          orderBy: [{ outlet: { name: "asc" } }, { name: "asc" }]
        });
        return terminals.map((terminal) => ({
          id: terminal.id,
          name: terminal.name,
          deviceIdentifier: terminal.deviceIdentifier,
          syncStatus: terminal.syncStatus,
          lastSeenAt: terminal.lastSeenAt,
          outlet: terminal.outlet
        }));
      }
      async loadProduct(user, productId) {
        const menu = await this.getMenu(user);
        const product = menu.products.find((entry) => entry.id === productId);
        if (!product)
          throw new common_1.NotFoundException("Product was not found.");
        return product;
      }
      accessibleOutlets(user, propertyId) {
        return this.prisma.posOutlet.findMany({
          where: { propertyId, active: true, outletType: { in: allowedOutletTypes(user) } },
          select: { id: true, name: true, outletType: true },
          orderBy: { name: "asc" }
        });
      }
      async findAccessibleOutlet(user, propertyId, outletId) {
        const outlet = await this.prisma.posOutlet.findFirst({ where: { id: outletId, propertyId } });
        if (!outlet)
          throw new common_1.NotFoundException("POS outlet was not found.");
        if (!(0, shared_1.canUseOutlet)(user.permissions, outlet.outletType)) {
          throw new common_1.ForbiddenException(`You do not have access to the ${outlet.name} outlet.`);
        }
        return outlet;
      }
      async resolveOutlets(user, propertyId, outletIds) {
        if (outletIds.length === 0)
          return [];
        const outlets = await this.prisma.posOutlet.findMany({
          where: { id: { in: outletIds }, propertyId, active: true },
          select: { id: true, name: true, outletType: true }
        });
        if (outlets.length !== new Set(outletIds).size) {
          throw new common_1.NotFoundException("One or more outlets were not found or are inactive.");
        }
        const denied = outlets.find((outlet) => !(0, shared_1.canUseOutlet)(user.permissions, outlet.outletType));
        if (denied)
          throw new common_1.ForbiddenException(`You do not have access to the ${denied.name} outlet.`);
        return outlets;
      }
    };
    exports.PosMenuService = PosMenuService;
    exports.PosMenuService = PosMenuService = __decorate([
      (0, common_1.Injectable)(),
      __metadata("design:paramtypes", [prisma_service_1.PrismaService])
    ], PosMenuService);
    function requireProperty(user) {
      if (!user.propertyId) {
        throw new common_1.BadRequestException("A property context is required.");
      }
      return user.propertyId;
    }
    function allowedOutletTypes(user) {
      return Object.values(client_1.PosOutletType).filter((outletType) => (0, shared_1.canUseOutlet)(user.permissions, outletType));
    }
    function audit(tx, user, propertyId, action, recordType, recordId, previousValue, newValue) {
      return tx.auditLog.create({
        data: {
          organizationId: user.organizationId,
          propertyId,
          userId: user.userId,
          module: "pos",
          action,
          recordType,
          recordId,
          previousValue: previousValue ? JSON.parse(JSON.stringify(previousValue)) : void 0,
          newValue: JSON.parse(JSON.stringify(newValue))
        }
      });
    }
  }
});

// apps/api/dist/modules/pos/pos-menu.controller.js
var require_pos_menu_controller = __commonJS({
  "apps/api/dist/modules/pos/pos-menu.controller.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = exports && exports.__metadata || function(k, v) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var __param = exports && exports.__param || function(paramIndex, decorator) {
      return function(target, key) {
        decorator(target, key, paramIndex);
      };
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.PosMenuController = void 0;
    var common_1 = __require("@nestjs/common");
    var current_user_decorator_1 = require_current_user_decorator();
    var require_permissions_decorator_1 = require_require_permissions_decorator();
    var menu_dto_1 = require_menu_dto();
    var pos_menu_service_1 = require_pos_menu_service();
    var PosMenuController = class PosMenuController {
      menu;
      constructor(menu) {
        this.menu = menu;
      }
      getMenu(user) {
        return this.menu.getMenu(user);
      }
      createCategory(user, dto) {
        return this.menu.createCategory(user, dto);
      }
      createProduct(user, dto) {
        return this.menu.createProduct(user, dto);
      }
      updateProduct(user, productId, dto) {
        return this.menu.updateProduct(user, productId, dto);
      }
      listTables(user, outletId) {
        return this.menu.listTables(user, outletId);
      }
      createTable(user, outletId, dto) {
        return this.menu.createTable(user, outletId, dto);
      }
      listTerminals(user) {
        return this.menu.listTerminals(user);
      }
    };
    exports.PosMenuController = PosMenuController;
    __decorate([
      (0, require_permissions_decorator_1.RequirePermissions)("pos.products.manage"),
      (0, common_1.Get)("menu"),
      __param(0, (0, current_user_decorator_1.CurrentUser)()),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", [Object]),
      __metadata("design:returntype", void 0)
    ], PosMenuController.prototype, "getMenu", null);
    __decorate([
      (0, require_permissions_decorator_1.RequirePermissions)("pos.products.manage"),
      (0, common_1.Post)("categories"),
      __param(0, (0, current_user_decorator_1.CurrentUser)()),
      __param(1, (0, common_1.Body)()),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", [Object, menu_dto_1.CreateProductCategoryDto]),
      __metadata("design:returntype", void 0)
    ], PosMenuController.prototype, "createCategory", null);
    __decorate([
      (0, require_permissions_decorator_1.RequirePermissions)("pos.products.manage"),
      (0, common_1.Post)("products"),
      __param(0, (0, current_user_decorator_1.CurrentUser)()),
      __param(1, (0, common_1.Body)()),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", [Object, menu_dto_1.CreatePosProductDto]),
      __metadata("design:returntype", void 0)
    ], PosMenuController.prototype, "createProduct", null);
    __decorate([
      (0, require_permissions_decorator_1.RequirePermissions)("pos.products.manage"),
      (0, common_1.Patch)("products/:productId"),
      __param(0, (0, current_user_decorator_1.CurrentUser)()),
      __param(1, (0, common_1.Param)("productId", common_1.ParseUUIDPipe)),
      __param(2, (0, common_1.Body)()),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", [Object, String, menu_dto_1.UpdatePosProductDto]),
      __metadata("design:returntype", void 0)
    ], PosMenuController.prototype, "updateProduct", null);
    __decorate([
      (0, require_permissions_decorator_1.RequirePermissions)("pos.outlets.manage"),
      (0, common_1.Get)("outlets/:outletId/tables"),
      __param(0, (0, current_user_decorator_1.CurrentUser)()),
      __param(1, (0, common_1.Param)("outletId", common_1.ParseUUIDPipe)),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", [Object, String]),
      __metadata("design:returntype", void 0)
    ], PosMenuController.prototype, "listTables", null);
    __decorate([
      (0, require_permissions_decorator_1.RequirePermissions)("pos.outlets.manage"),
      (0, common_1.Post)("outlets/:outletId/tables"),
      __param(0, (0, current_user_decorator_1.CurrentUser)()),
      __param(1, (0, common_1.Param)("outletId", common_1.ParseUUIDPipe)),
      __param(2, (0, common_1.Body)()),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", [Object, String, menu_dto_1.CreateDiningTableDto]),
      __metadata("design:returntype", void 0)
    ], PosMenuController.prototype, "createTable", null);
    __decorate([
      (0, require_permissions_decorator_1.RequirePermissions)("pos.view"),
      (0, common_1.Get)("terminals"),
      __param(0, (0, current_user_decorator_1.CurrentUser)()),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", [Object]),
      __metadata("design:returntype", void 0)
    ], PosMenuController.prototype, "listTerminals", null);
    exports.PosMenuController = PosMenuController = __decorate([
      (0, common_1.Controller)("pos"),
      __metadata("design:paramtypes", [pos_menu_service_1.PosMenuService])
    ], PosMenuController);
  }
});

// apps/api/dist/modules/pos/dto/create-pos-order.dto.js
var require_create_pos_order_dto = __commonJS({
  "apps/api/dist/modules/pos/dto/create-pos-order.dto.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = exports && exports.__metadata || function(k, v) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.CreatePosOrderDto = void 0;
    var class_transformer_1 = __require("class-transformer");
    var class_validator_1 = __require("class-validator");
    var CreatePosOrderItemDto = class {
      productVariantId;
      quantity;
    };
    __decorate([
      (0, class_validator_1.IsUUID)(),
      __metadata("design:type", String)
    ], CreatePosOrderItemDto.prototype, "productVariantId", void 0);
    __decorate([
      (0, class_validator_1.IsString)(),
      __metadata("design:type", String)
    ], CreatePosOrderItemDto.prototype, "quantity", void 0);
    var CreatePosOrderDto = class {
      outletId;
      terminalId;
      shiftId;
      tableId;
      folioId;
      serviceType;
      // Sale currency; prices come from the outlet's TSh or USD price list. Defaults to TZS.
      currencyCode;
      idempotencyKey;
      items;
    };
    exports.CreatePosOrderDto = CreatePosOrderDto;
    __decorate([
      (0, class_validator_1.IsUUID)(),
      __metadata("design:type", String)
    ], CreatePosOrderDto.prototype, "outletId", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsUUID)(),
      __metadata("design:type", String)
    ], CreatePosOrderDto.prototype, "terminalId", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsUUID)(),
      __metadata("design:type", String)
    ], CreatePosOrderDto.prototype, "shiftId", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsUUID)(),
      __metadata("design:type", String)
    ], CreatePosOrderDto.prototype, "tableId", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsUUID)(),
      __metadata("design:type", String)
    ], CreatePosOrderDto.prototype, "folioId", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsString)(),
      __metadata("design:type", String)
    ], CreatePosOrderDto.prototype, "serviceType", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsIn)(["TZS", "USD"]),
      __metadata("design:type", String)
    ], CreatePosOrderDto.prototype, "currencyCode", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsString)(),
      __metadata("design:type", String)
    ], CreatePosOrderDto.prototype, "idempotencyKey", void 0);
    __decorate([
      (0, class_validator_1.IsArray)(),
      (0, class_validator_1.ArrayMinSize)(1),
      (0, class_validator_1.ValidateNested)({ each: true }),
      (0, class_transformer_1.Type)(() => CreatePosOrderItemDto),
      __metadata("design:type", Array)
    ], CreatePosOrderDto.prototype, "items", void 0);
  }
});

// apps/api/dist/modules/pos/dto/pay-pos-order.dto.js
var require_pay_pos_order_dto = __commonJS({
  "apps/api/dist/modules/pos/dto/pay-pos-order.dto.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = exports && exports.__metadata || function(k, v) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.PayPosOrderDto = void 0;
    var client_1 = __require("@prisma/client");
    var class_validator_1 = __require("class-validator");
    var PayPosOrderDto = class {
      paymentMethod;
      amount;
      externalReceiptNumber;
      authorizationCode;
      externalReference;
      idempotencyKey;
    };
    exports.PayPosOrderDto = PayPosOrderDto;
    __decorate([
      (0, class_validator_1.IsEnum)(client_1.PaymentMethod),
      __metadata("design:type", String)
    ], PayPosOrderDto.prototype, "paymentMethod", void 0);
    __decorate([
      (0, class_validator_1.IsString)(),
      __metadata("design:type", String)
    ], PayPosOrderDto.prototype, "amount", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsString)(),
      __metadata("design:type", String)
    ], PayPosOrderDto.prototype, "externalReceiptNumber", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsString)(),
      __metadata("design:type", String)
    ], PayPosOrderDto.prototype, "authorizationCode", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsString)(),
      __metadata("design:type", String)
    ], PayPosOrderDto.prototype, "externalReference", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsString)(),
      __metadata("design:type", String)
    ], PayPosOrderDto.prototype, "idempotencyKey", void 0);
  }
});

// apps/api/dist/modules/pos/dto/update-pos-order.dto.js
var require_update_pos_order_dto = __commonJS({
  "apps/api/dist/modules/pos/dto/update-pos-order.dto.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = exports && exports.__metadata || function(k, v) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.UpdatePosOrderDto = void 0;
    var class_transformer_1 = __require("class-transformer");
    var class_validator_1 = __require("class-validator");
    var UpdatePosOrderItemDto = class {
      productVariantId;
      quantity;
    };
    __decorate([
      (0, class_validator_1.IsUUID)(),
      __metadata("design:type", String)
    ], UpdatePosOrderItemDto.prototype, "productVariantId", void 0);
    __decorate([
      (0, class_validator_1.IsString)(),
      __metadata("design:type", String)
    ], UpdatePosOrderItemDto.prototype, "quantity", void 0);
    var UpdatePosOrderDto = class {
      items;
    };
    exports.UpdatePosOrderDto = UpdatePosOrderDto;
    __decorate([
      (0, class_validator_1.IsArray)(),
      (0, class_validator_1.ArrayMinSize)(1),
      (0, class_validator_1.ValidateNested)({ each: true }),
      (0, class_transformer_1.Type)(() => UpdatePosOrderItemDto),
      __metadata("design:type", Array)
    ], UpdatePosOrderDto.prototype, "items", void 0);
  }
});

// apps/api/dist/modules/pos/dto/void-pos-order.dto.js
var require_void_pos_order_dto = __commonJS({
  "apps/api/dist/modules/pos/dto/void-pos-order.dto.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = exports && exports.__metadata || function(k, v) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.VoidPosOrderDto = void 0;
    var class_validator_1 = __require("class-validator");
    var VoidPosOrderDto = class {
      reason;
    };
    exports.VoidPosOrderDto = VoidPosOrderDto;
    __decorate([
      (0, class_validator_1.IsString)(),
      (0, class_validator_1.MinLength)(3),
      (0, class_validator_1.MaxLength)(240),
      __metadata("design:type", String)
    ], VoidPosOrderDto.prototype, "reason", void 0);
  }
});

// apps/api/dist/modules/pos/pos-payment-policy.js
var require_pos_payment_policy = __commonJS({
  "apps/api/dist/modules/pos/pos-payment-policy.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.referenceRequiredPaymentMethods = void 0;
    exports.paymentRequiresExternalReference = paymentRequiresExternalReference;
    exports.assertPaymentReferencePolicy = assertPaymentReferencePolicy;
    var client_1 = __require("@prisma/client");
    exports.referenceRequiredPaymentMethods = [
      client_1.PaymentMethod.CARD,
      client_1.PaymentMethod.CREDIT,
      client_1.PaymentMethod.MOBILE_MONEY,
      client_1.PaymentMethod.BANK_TRANSFER
    ];
    function paymentRequiresExternalReference(paymentMethod) {
      return exports.referenceRequiredPaymentMethods.includes(paymentMethod);
    }
    function assertPaymentReferencePolicy(input) {
      if (!paymentRequiresExternalReference(input.paymentMethod)) {
        return;
      }
      const hasReference = Boolean(input.externalReceiptNumber?.trim()) || Boolean(input.authorizationCode?.trim()) || Boolean(input.externalReference?.trim());
      if (!hasReference) {
        throw new Error(`${input.paymentMethod} payments require a receipt ID, authorization code, or external reference.`);
      }
    }
  }
});

// apps/api/dist/modules/pos/pos-totals.js
var require_pos_totals = __commonJS({
  "apps/api/dist/modules/pos/pos-totals.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.calculatePosOrderTotals = calculatePosOrderTotals;
    var client_1 = __require("@prisma/client");
    function calculatePosOrderTotals(lines) {
      if (lines.length === 0) {
        throw new Error("A POS order must contain at least one item.");
      }
      let subtotal = new client_1.Prisma.Decimal(0);
      let discountTotal = new client_1.Prisma.Decimal(0);
      let taxTotal = new client_1.Prisma.Decimal(0);
      let grandTotal = new client_1.Prisma.Decimal(0);
      const itemTotals = lines.map((line) => {
        const quantity = money(line.quantity, "quantity");
        const unitPrice = money(line.unitPrice, "unitPrice");
        const discount = money(line.discountAmount ?? "0", "discountAmount");
        const taxRate = money(line.taxRate ?? "0", "taxRate");
        if (quantity.lte(0)) {
          throw new Error("Item quantity must be greater than zero.");
        }
        if (unitPrice.lt(0) || discount.lt(0) || taxRate.lt(0)) {
          throw new Error("POS order amounts cannot be negative.");
        }
        const lineSubtotal = quantity.mul(unitPrice);
        if (discount.gt(lineSubtotal)) {
          throw new Error("Discount cannot exceed the line subtotal.");
        }
        const taxableAmount = lineSubtotal.minus(discount);
        const taxAmount = taxableAmount.mul(taxRate);
        const totalAmount = taxableAmount.plus(taxAmount);
        subtotal = subtotal.plus(lineSubtotal);
        discountTotal = discountTotal.plus(discount);
        taxTotal = taxTotal.plus(taxAmount);
        grandTotal = grandTotal.plus(totalAmount);
        return {
          quantity,
          unitPrice,
          discountAmount: discount,
          taxAmount,
          totalAmount
        };
      });
      return {
        itemTotals,
        subtotal,
        discountTotal,
        taxTotal,
        grandTotal
      };
    }
    function money(value, field) {
      if (typeof value === "number" && !Number.isInteger(value)) {
        throw new Error(`${field} must be sent as a decimal string, not a floating point number.`);
      }
      return new client_1.Prisma.Decimal(value);
    }
  }
});

// apps/api/dist/modules/pos/pos.service.js
var require_pos_service = __commonJS({
  "apps/api/dist/modules/pos/pos.service.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = exports && exports.__metadata || function(k, v) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.PosService = void 0;
    var common_1 = __require("@nestjs/common");
    var shared_1 = __require("@hms/shared");
    var client_1 = __require("@prisma/client");
    var audit_service_1 = require_audit_service();
    var stock_ledger_1 = require_stock_ledger();
    var prisma_service_1 = require_prisma_service();
    var pos_payment_policy_1 = require_pos_payment_policy();
    var pos_totals_1 = require_pos_totals();
    var pos_charge_description_1 = require_pos_charge_description();
    var BAR_RESTOCK_THRESHOLD = 3;
    var PosService = class PosService {
      prisma;
      constructor(prisma) {
        this.prisma = prisma;
      }
      listOutlets(user) {
        const propertyId = this.requireProperty(user);
        return this.prisma.posOutlet.findMany({
          where: { propertyId, active: true, outletType: { in: allowedOutletTypes(user) } },
          include: {
            terminals: true,
            tables: {
              orderBy: { tableNumber: "asc" }
            }
          },
          orderBy: { name: "asc" }
        });
      }
      async listCatalog(user, outletId) {
        const propertyId = this.requireProperty(user);
        const entries = await this.prisma.outletProduct.findMany({
          where: {
            outletId,
            available: true,
            productVariant: { active: true, product: { active: true } },
            outlet: {
              propertyId,
              outletType: { in: allowedOutletTypes(user) }
            }
          },
          include: {
            productVariant: {
              include: {
                product: {
                  include: {
                    category: true
                  }
                }
              }
            }
          },
          orderBy: {
            productVariant: {
              product: {
                name: "asc"
              }
            }
          }
        });
        const outlet = await this.prisma.posOutlet.findFirst({ where: { id: outletId, propertyId } });
        if (outlet?.outletType !== client_1.PosOutletType.BAR) {
          return entries;
        }
        return this.hideOutOfStockBarItems(propertyId, entries);
      }
      // Bar menu items linked to a stock item (same matching as deductBarStock) are hidden while
      // the Bar Store holds none of it. Items without a stock item (e.g. cocktails) always show.
      async hideOutOfStockBarItems(propertyId, entries) {
        const [items, balances] = await Promise.all([
          this.prisma.inventoryItem.findMany({ where: { propertyId, active: true } }),
          this.prisma.inventoryBalance.findMany({
            where: { item: { propertyId }, location: { propertyId, code: "BAR", active: true } }
          })
        ]);
        const bySku = new Map(items.map((item) => [item.sku.toUpperCase(), item]));
        const byName = new Map(items.map((item) => [item.name.trim().toLowerCase(), item]));
        const quantityByItem = new Map(balances.map((balance) => [balance.itemId, balance.quantityOnHand]));
        return entries.filter((entry) => {
          const variant = entry.productVariant;
          const item = bySku.get(variant.sku.toUpperCase()) ?? bySku.get(variant.product.sku.toUpperCase()) ?? byName.get(variant.product.name.trim().toLowerCase());
          if (!item)
            return true;
          const quantity = quantityByItem.get(item.id);
          return quantity !== void 0 && quantity.gt(0);
        });
      }
      listOrders(user) {
        const propertyId = this.requireProperty(user);
        return this.prisma.posOrder.findMany({
          where: { propertyId, outlet: { outletType: { in: allowedOutletTypes(user) } } },
          include: {
            items: {
              include: {
                productVariant: {
                  include: {
                    product: true
                  }
                }
              }
            },
            outlet: true,
            payments: true,
            table: true
          },
          orderBy: { createdAt: "desc" },
          take: 50
        });
      }
      async listPrepNotifications(user, stationFilter) {
        const propertyId = this.requireProperty(user);
        const normalizedFilter = stationFilter?.trim().toLowerCase();
        const orders = await this.prisma.posOrder.findMany({
          where: { propertyId, outlet: { outletType: { in: allowedOutletTypes(user) } } },
          include: {
            items: {
              include: {
                productVariant: {
                  include: {
                    product: {
                      include: {
                        category: true
                      }
                    }
                  }
                }
              }
            },
            outlet: true,
            table: true,
            terminal: true
          },
          orderBy: { createdAt: "desc" },
          take: 60
        });
        const tickets = orders.flatMap((order) => {
          const stationLines = /* @__PURE__ */ new Map();
          for (const item of order.items) {
            const category = item.productVariant.product.category.name;
            const station = prepStationFor(category, order.outlet.outletType);
            const current = stationLines.get(station) ?? [];
            current.push({
              name: item.productVariant.product.name,
              quantity: item.quantity.toFixed(2),
              category
            });
            stationLines.set(station, current);
          }
          return Array.from(stationLines.entries()).map(([station, lines], index) => ({
            id: `${order.id}-${station.toLowerCase().replace(/[^a-z0-9]+/g, "-")}`,
            ticketNumber: `${order.orderNumber}-${String(index + 1).padStart(2, "0")}`,
            orderId: order.id,
            orderNumber: order.orderNumber,
            orderStatus: order.status,
            station,
            outletName: order.outlet.name,
            outletType: order.outlet.outletType,
            terminalName: order.terminal?.name ?? order.terminal?.deviceIdentifier ?? "POS terminal",
            tableNumber: order.table?.tableNumber ?? null,
            serviceType: order.serviceType,
            createdAt: order.createdAt,
            lines
          }));
        });
        const filteredTickets = normalizedFilter ? tickets.filter((ticket) => ticket.station.toLowerCase().includes(normalizedFilter)) : tickets;
        return {
          generatedAt: /* @__PURE__ */ new Date(),
          tickets: filteredTickets,
          totals: {
            restaurant: tickets.filter((ticket) => ticket.station === "Restaurant Kitchen").length,
            bar: tickets.filter((ticket) => ticket.station === "Bar Printer").length,
            service: tickets.filter((ticket) => ticket.station === "Service Desk").length
          }
        };
      }
      async listChargeableRooms(user) {
        const propertyId = this.requireProperty(user);
        const assignedRooms = await this.prisma.reservationRoom.findMany({
          where: {
            roomId: { not: null },
            status: client_1.ReservationStatus.CHECKED_IN,
            room: {
              propertyId,
              active: true,
              occupancyStatus: client_1.RoomOccupancyStatus.OCCUPIED
            },
            reservation: {
              propertyId,
              status: client_1.ReservationStatus.CHECKED_IN
            }
          },
          include: {
            room: {
              include: {
                roomType: true
              }
            },
            reservation: {
              include: {
                primaryGuest: true,
                folios: {
                  where: {
                    status: client_1.FolioStatus.OPEN
                  },
                  orderBy: {
                    openedAt: "desc"
                  },
                  take: 1
                }
              }
            }
          }
        });
        return assignedRooms.map((assignedRoom) => {
          const room = assignedRoom.room;
          const folio = assignedRoom.reservation.folios[0];
          if (!room || !folio)
            return null;
          return {
            roomId: room.id,
            roomNumber: room.roomNumber,
            roomType: room.roomType.name,
            reservationId: assignedRoom.reservation.id,
            reservationNumber: assignedRoom.reservation.reservationNumber,
            guest: {
              id: assignedRoom.reservation.primaryGuest.id,
              firstName: assignedRoom.reservation.primaryGuest.firstName,
              lastName: assignedRoom.reservation.primaryGuest.lastName
            },
            folio: {
              id: folio.id,
              folioNumber: folio.folioNumber,
              balance: money(folio.balance),
              currencyCode: assignedRoom.currencyCode
            }
          };
        }).filter((room) => Boolean(room)).sort((a, b) => a.roomNumber.localeCompare(b.roomNumber, void 0, { numeric: true }));
      }
      async listBarLowStock(user) {
        const propertyId = this.requireProperty(user);
        if (!(0, shared_1.canUseOutlet)(user.permissions, client_1.PosOutletType.BAR)) {
          return { threshold: BAR_RESTOCK_THRESHOLD, items: [] };
        }
        const balances = await this.prisma.inventoryBalance.findMany({
          where: {
            quantityOnHand: { lt: BAR_RESTOCK_THRESHOLD },
            item: { propertyId, active: true },
            location: { propertyId, code: "BAR", active: true }
          },
          include: { item: true },
          orderBy: { quantityOnHand: "asc" }
        });
        return {
          threshold: BAR_RESTOCK_THRESHOLD,
          items: balances.map((balance) => ({
            itemId: balance.itemId,
            sku: balance.item.sku,
            name: balance.item.name,
            unit: balance.item.unitOfMeasure,
            quantity: Number(balance.quantityOnHand)
          }))
        };
      }
      async createOrder(user, dto) {
        const propertyId = this.requireProperty(user);
        const currencyCode = dto.currencyCode ?? "TZS";
        return this.prisma.$transaction(async (tx) => {
          const outlet = await tx.posOutlet.findFirst({
            where: {
              id: dto.outletId,
              propertyId,
              active: true
            }
          });
          if (!outlet) {
            throw new common_1.NotFoundException("POS outlet was not found.");
          }
          assertOutletAccess(user, outlet);
          if (dto.idempotencyKey) {
            const existingOrder = await tx.posOrder.findFirst({
              where: {
                propertyId,
                idempotencyKey: dto.idempotencyKey
              },
              include: {
                items: {
                  include: {
                    productVariant: {
                      include: {
                        product: true
                      }
                    }
                  }
                },
                outlet: true,
                payments: true,
                table: true
              }
            });
            if (existingOrder) {
              return existingOrder;
            }
          }
          if (dto.tableId) {
            const table = await tx.diningTable.findFirst({
              where: {
                id: dto.tableId,
                outletId: outlet.id
              }
            });
            if (!table) {
              throw new common_1.NotFoundException("Dining table was not found.");
            }
          }
          if (dto.folioId) {
            const folio = await tx.folio.findFirst({
              where: {
                id: dto.folioId,
                propertyId,
                status: client_1.FolioStatus.OPEN,
                reservation: {
                  status: client_1.ReservationStatus.CHECKED_IN,
                  reservationRooms: {
                    some: {
                      roomId: { not: null },
                      status: client_1.ReservationStatus.CHECKED_IN
                    }
                  }
                }
              }
            });
            if (!folio) {
              throw new common_1.BadRequestException("Choose an occupied room with an open folio before charging to room.");
            }
            const stay = await tx.reservationRoom.findFirst({
              where: { reservationId: folio.reservationId, status: client_1.ReservationStatus.CHECKED_IN }
            });
            if (stay && stay.currencyCode !== currencyCode) {
              const label = currencyLabel(stay.currencyCode);
              throw new common_1.BadRequestException(`This room's folio is in ${label}. Sell in ${label} to charge it to the room.`);
            }
          }
          const variants = dto.items.map((item) => item.productVariantId);
          const outletProducts = await tx.outletProduct.findMany({
            where: {
              outletId: outlet.id,
              productVariantId: { in: variants },
              available: true,
              productVariant: { active: true, product: { active: true } }
            },
            include: {
              productVariant: {
                include: {
                  product: true
                }
              }
            }
          });
          const catalogByVariant = new Map(outletProducts.map((item) => [item.productVariantId, item]));
          const missingItem = dto.items.find((item) => !catalogByVariant.has(item.productVariantId));
          if (missingItem) {
            throw new common_1.BadRequestException("One or more products are not available in this outlet.");
          }
          const unitPriceFor = (catalogItem) => {
            if (currencyCode === "TZS")
              return catalogItem.price;
            if (!catalogItem.priceUsd) {
              throw new common_1.BadRequestException(`${catalogItem.productVariant.product.name} has no USD price. Add one in Menu management or sell in TSh.`);
            }
            return catalogItem.priceUsd;
          };
          const totals = (0, pos_totals_1.calculatePosOrderTotals)(dto.items.map((item) => {
            const catalogItem = catalogByVariant.get(item.productVariantId);
            if (!catalogItem) {
              throw new common_1.BadRequestException("Product is not available in this outlet.");
            }
            return {
              quantity: item.quantity,
              unitPrice: unitPriceFor(catalogItem).toString(),
              taxRate: catalogItem.taxRate.toString()
            };
          }));
          const orderNumber = await this.nextOrderNumber(tx, propertyId, /* @__PURE__ */ new Date());
          const order = await tx.posOrder.create({
            data: {
              propertyId,
              outletId: outlet.id,
              terminalId: dto.terminalId,
              shiftId: dto.shiftId,
              tableId: dto.tableId,
              folioId: dto.folioId,
              orderNumber,
              serviceType: dto.serviceType ? client_1.PosServiceType[dto.serviceType] : client_1.PosServiceType.DINE_IN,
              currencyCode,
              subtotal: totals.subtotal,
              discountTotal: totals.discountTotal,
              taxTotal: totals.taxTotal,
              grandTotal: totals.grandTotal,
              idempotencyKey: dto.idempotencyKey,
              // The seller is always the logged-in user; it never changes on later edits or payments.
              createdByUserId: user.userId,
              createdByName: user.fullName,
              items: {
                create: dto.items.map((item, index) => {
                  const catalogItem = catalogByVariant.get(item.productVariantId);
                  const itemTotal = totals.itemTotals[index];
                  if (!catalogItem) {
                    throw new common_1.BadRequestException("Product is not available in this outlet.");
                  }
                  return {
                    productVariantId: item.productVariantId,
                    quantity: itemTotal.quantity,
                    unitPrice: unitPriceFor(catalogItem),
                    discountAmount: itemTotal.discountAmount,
                    taxAmount: itemTotal.taxAmount,
                    totalAmount: itemTotal.totalAmount
                  };
                })
              }
            },
            include: {
              items: {
                include: {
                  productVariant: {
                    include: {
                      product: true
                    }
                  }
                }
              },
              outlet: true,
              table: true
            }
          });
          if (dto.tableId) {
            await tx.diningTable.update({
              where: { id: dto.tableId },
              data: { status: "ORDER_OPEN" }
            });
          }
          if (outlet.outletType === client_1.PosOutletType.BAR) {
            await this.deductBarStock(tx, propertyId, order, (0, stock_ledger_1.stockActor)(user));
          }
          await tx.auditLog.create({
            data: (0, audit_service_1.auditData)({
              organizationId: user.organizationId,
              propertyId,
              userId: user.userId,
              actorName: user.fullName,
              module: "pos",
              action: "create_order",
              recordType: "pos_order",
              recordId: order.id,
              summary: `Sold ${order.orderNumber} at ${order.outlet.name}: ${itemSummary(order.items)} - ${order.currencyCode} ${order.grandTotal.toFixed(2)}.`,
              newValue: {
                orderNumber: order.orderNumber,
                outletId: order.outletId,
                grandTotal: order.grandTotal.toString(),
                currencyCode: order.currencyCode
              }
            })
          });
          return order;
        });
      }
      async payOrder(user, orderId, dto) {
        const propertyId = this.requireProperty(user);
        try {
          (0, pos_payment_policy_1.assertPaymentReferencePolicy)(dto);
        } catch (error) {
          throw new common_1.BadRequestException(error.message);
        }
        return this.prisma.$transaction(async (tx) => {
          if (dto.idempotencyKey) {
            const existingPayment = await tx.payment.findFirst({
              where: {
                propertyId,
                idempotencyKey: dto.idempotencyKey
              },
              include: {
                order: {
                  include: {
                    items: {
                      include: {
                        productVariant: {
                          include: {
                            product: true
                          }
                        }
                      }
                    },
                    outlet: true,
                    payments: true,
                    table: true
                  }
                }
              }
            });
            if (existingPayment?.order) {
              return existingPayment.order;
            }
          }
          const order = await tx.posOrder.findFirst({
            where: {
              id: orderId,
              propertyId
            },
            include: {
              outlet: true,
              payments: true,
              items: { include: { productVariant: { include: { product: true } } } }
            }
          });
          if (!order) {
            throw new common_1.NotFoundException("POS order was not found.");
          }
          assertOutletAccess(user, order.outlet);
          if (order.status !== client_1.PosOrderStatus.OPEN && order.status !== client_1.PosOrderStatus.HELD) {
            throw new common_1.ConflictException("Only open POS orders can receive payment.");
          }
          if (dto.paymentMethod === client_1.PaymentMethod.ROOM_CHARGE && !order.folioId) {
            throw new common_1.BadRequestException("Room charge payments require a linked guest folio.");
          }
          if (dto.externalReceiptNumber) {
            const duplicate = await tx.payment.findFirst({
              where: {
                propertyId,
                paymentMethod: dto.paymentMethod,
                externalReceiptNumber: dto.externalReceiptNumber,
                status: client_1.PaymentStatus.COMPLETED
              }
            });
            if (duplicate) {
              throw new common_1.ConflictException("This external receipt ID has already been used for this payment method.");
            }
          }
          const amount = new client_1.Prisma.Decimal(dto.amount);
          const paidTotal = order.payments.filter((payment2) => payment2.status === client_1.PaymentStatus.COMPLETED).reduce((sum, payment2) => sum.plus(payment2.amount), new client_1.Prisma.Decimal(0));
          const remaining = order.grandTotal.minus(paidTotal);
          if (amount.lte(0)) {
            throw new common_1.BadRequestException("Payment amount must be greater than zero.");
          }
          if (amount.gt(remaining)) {
            throw new common_1.BadRequestException("Payment amount cannot exceed the order balance.");
          }
          const systemReceiptNumber = await this.nextReceiptNumber(tx, propertyId, /* @__PURE__ */ new Date());
          const payment = await tx.payment.create({
            data: {
              propertyId,
              orderId: order.id,
              shiftId: order.shiftId,
              sourceType: "POS_ORDER",
              sourceId: order.id,
              paymentMethod: dto.paymentMethod,
              amount,
              currencyCode: order.currencyCode,
              systemReceiptNumber,
              externalReceiptNumber: dto.externalReceiptNumber,
              authorizationCode: dto.authorizationCode,
              externalReference: dto.externalReference,
              idempotencyKey: dto.idempotencyKey,
              collectedByUserId: user.userId,
              collectedByName: user.fullName
            }
          });
          if (dto.paymentMethod === client_1.PaymentMethod.ROOM_CHARGE && order.folioId) {
            await tx.folioItem.create({
              data: {
                folioId: order.folioId,
                itemType: client_1.FolioItemType.POS_CHARGE,
                sourceType: "POS_ORDER",
                sourceId: order.id,
                description: (0, pos_charge_description_1.posChargeDescription)(order.orderNumber, order.items),
                quantity: new client_1.Prisma.Decimal(1),
                unitPrice: amount,
                totalAmount: amount
              }
            });
            await tx.folio.update({
              where: { id: order.folioId },
              data: {
                balance: {
                  increment: amount
                }
              }
            });
          }
          const orderPaid = paidTotal.plus(amount).eq(order.grandTotal);
          const updatedOrder = await tx.posOrder.update({
            where: { id: order.id },
            data: {
              status: orderPaid ? client_1.PosOrderStatus.PAID : client_1.PosOrderStatus.OPEN
            },
            include: {
              items: {
                include: {
                  productVariant: {
                    include: {
                      product: true
                    }
                  }
                }
              },
              outlet: true,
              payments: true,
              table: true
            }
          });
          if (orderPaid && order.tableId) {
            await tx.diningTable.update({
              where: { id: order.tableId },
              data: { status: "AVAILABLE" }
            });
          }
          await tx.auditLog.create({
            data: (0, audit_service_1.auditData)({
              organizationId: user.organizationId,
              propertyId,
              userId: user.userId,
              actorName: user.fullName,
              module: "pos",
              action: "take_payment",
              recordType: "payment",
              recordId: payment.id,
              summary: `Collected ${payment.currencyCode} ${payment.amount.toFixed(2)} by ${payment.paymentMethod.replaceAll("_", " ").toLowerCase()} for ${order.orderNumber} (receipt ${payment.systemReceiptNumber}).`,
              newValue: {
                orderNumber: order.orderNumber,
                orderId: order.id,
                systemReceiptNumber: payment.systemReceiptNumber,
                externalReceiptNumber: payment.externalReceiptNumber,
                paymentMethod: payment.paymentMethod,
                amount: payment.amount.toString()
              }
            })
          });
          return updatedOrder;
        });
      }
      // Corrects the items on an unpaid order. Prices are re-read from the outlet menu in the order's currency.
      async updateOrder(user, orderId, dto) {
        const propertyId = this.requireProperty(user);
        return this.prisma.$transaction(async (tx) => {
          const order = await tx.posOrder.findFirst({
            where: { id: orderId, propertyId },
            include: { outlet: true, payments: true, items: true }
          });
          if (!order) {
            throw new common_1.NotFoundException("POS order was not found.");
          }
          assertOutletAccess(user, order.outlet);
          if (order.status !== client_1.PosOrderStatus.OPEN && order.status !== client_1.PosOrderStatus.HELD) {
            throw new common_1.ConflictException("Only open orders can be edited. Void a paid order and ring it again instead.");
          }
          if (order.payments.some((payment) => payment.status === client_1.PaymentStatus.COMPLETED)) {
            throw new common_1.ConflictException("This order already has a payment. Void it and ring it again instead of editing.");
          }
          const variants = dto.items.map((item) => item.productVariantId);
          const outletProducts = await tx.outletProduct.findMany({
            where: {
              outletId: order.outletId,
              productVariantId: { in: variants },
              productVariant: { active: true, product: { active: true } }
            },
            include: { productVariant: { include: { product: true } } }
          });
          const catalogByVariant = new Map(outletProducts.map((item) => [item.productVariantId, item]));
          const existingVariants = new Set(order.items.map((item) => item.productVariantId));
          const missingItem = dto.items.find((item) => {
            const catalogItem = catalogByVariant.get(item.productVariantId);
            return !catalogItem || !catalogItem.available && !existingVariants.has(item.productVariantId);
          });
          if (missingItem) {
            throw new common_1.BadRequestException("One or more products are not available in this outlet.");
          }
          const unitPriceFor = (catalogItem) => {
            if (order.currencyCode !== "USD")
              return catalogItem.price;
            if (!catalogItem.priceUsd) {
              throw new common_1.BadRequestException(`${catalogItem.productVariant.product.name} has no USD price. Add one in Menu management.`);
            }
            return catalogItem.priceUsd;
          };
          let totals;
          try {
            totals = (0, pos_totals_1.calculatePosOrderTotals)(dto.items.map((item) => {
              const catalogItem = catalogByVariant.get(item.productVariantId);
              return {
                quantity: item.quantity,
                unitPrice: unitPriceFor(catalogItem).toString(),
                taxRate: catalogItem.taxRate.toString()
              };
            }));
          } catch (error) {
            if (error instanceof common_1.BadRequestException)
              throw error;
            throw new common_1.BadRequestException(error.message);
          }
          if (order.outlet.outletType === client_1.PosOutletType.BAR) {
            await this.returnBarStock(tx, propertyId, order, "Bar order edit", (0, stock_ledger_1.stockActor)(user));
          }
          await tx.posOrderItem.deleteMany({ where: { orderId: order.id } });
          const updatedOrder = await tx.posOrder.update({
            where: { id: order.id },
            data: {
              subtotal: totals.subtotal,
              discountTotal: totals.discountTotal,
              taxTotal: totals.taxTotal,
              grandTotal: totals.grandTotal,
              // Editing never changes the original seller (createdBy*).
              lastEditedByUserId: user.userId,
              lastEditedByName: user.fullName,
              lastEditedAt: /* @__PURE__ */ new Date(),
              items: {
                create: dto.items.map((item, index) => {
                  const catalogItem = catalogByVariant.get(item.productVariantId);
                  const itemTotal = totals.itemTotals[index];
                  return {
                    productVariantId: item.productVariantId,
                    quantity: itemTotal.quantity,
                    unitPrice: unitPriceFor(catalogItem),
                    discountAmount: itemTotal.discountAmount,
                    taxAmount: itemTotal.taxAmount,
                    totalAmount: itemTotal.totalAmount
                  };
                })
              }
            },
            include: orderInclude
          });
          if (order.outlet.outletType === client_1.PosOutletType.BAR) {
            await this.deductBarStock(tx, propertyId, updatedOrder, (0, stock_ledger_1.stockActor)(user));
          }
          await tx.auditLog.create({
            data: (0, audit_service_1.auditData)({
              organizationId: user.organizationId,
              propertyId,
              userId: user.userId,
              actorName: user.fullName,
              module: "pos",
              action: "edit_order",
              recordType: "pos_order",
              recordId: order.id,
              summary: `Edited ${order.orderNumber}: ${order.grandTotal.toFixed(2)} to ${updatedOrder.grandTotal.toFixed(2)} ${order.currencyCode}. Now ${itemSummary(updatedOrder.items)}.`,
              previousValue: {
                orderNumber: order.orderNumber,
                grandTotal: order.grandTotal.toString(),
                items: order.items.map((item) => ({ productVariantId: item.productVariantId, quantity: item.quantity.toString() }))
              },
              newValue: {
                orderNumber: order.orderNumber,
                grandTotal: updatedOrder.grandTotal.toString(),
                items: updatedOrder.items.map((item) => ({
                  productVariantId: item.productVariantId,
                  name: item.productVariant.product.name,
                  quantity: item.quantity.toString()
                }))
              }
            })
          });
          return updatedOrder;
        });
      }
      // Voids an order entered by mistake. Payments are voided, room charges are taken back off the guest
      // folio and bar stock is returned to the Bar Store. Paid orders need the pos.orders.void permission.
      async voidOrder(user, orderId, dto) {
        const propertyId = this.requireProperty(user);
        const reason = dto.reason.trim();
        if (reason.length < 3) {
          throw new common_1.BadRequestException("Give a short reason for voiding this order.");
        }
        return this.prisma.$transaction(async (tx) => {
          const order = await tx.posOrder.findFirst({
            where: { id: orderId, propertyId },
            include: { outlet: true, payments: true, items: { include: { productVariant: { include: { product: true } } } } }
          });
          if (!order) {
            throw new common_1.NotFoundException("POS order was not found.");
          }
          assertOutletAccess(user, order.outlet);
          if (order.status === client_1.PosOrderStatus.VOID) {
            throw new common_1.ConflictException(`${order.orderNumber} is already void.`);
          }
          if (order.status === client_1.PosOrderStatus.REFUNDED) {
            throw new common_1.ConflictException("Refunded orders cannot be voided.");
          }
          const completedPayments = order.payments.filter((payment) => payment.status === client_1.PaymentStatus.COMPLETED);
          if (completedPayments.length > 0 && !user.permissions.includes("pos.orders.void")) {
            throw new common_1.ForbiddenException("This order is already paid. Ask a supervisor with void permission to void it.");
          }
          const roomChargeTotal = completedPayments.filter((payment) => payment.paymentMethod === client_1.PaymentMethod.ROOM_CHARGE).reduce((sum, payment) => sum.plus(payment.amount), new client_1.Prisma.Decimal(0));
          if (roomChargeTotal.gt(0) && order.folioId) {
            const folio = await tx.folio.findFirst({ where: { id: order.folioId, propertyId } });
            if (!folio || folio.status !== client_1.FolioStatus.OPEN) {
              throw new common_1.ConflictException("The guest has already checked out, so this room charge can no longer be voided here.");
            }
            await tx.folioItem.create({
              data: {
                folioId: folio.id,
                itemType: client_1.FolioItemType.POS_CHARGE,
                sourceType: "POS_ORDER_VOID",
                sourceId: order.id,
                description: (0, pos_charge_description_1.posChargeDescription)(order.orderNumber, order.items, true),
                quantity: new client_1.Prisma.Decimal(1),
                unitPrice: roomChargeTotal.negated(),
                totalAmount: roomChargeTotal.negated()
              }
            });
            await tx.folio.update({
              where: { id: folio.id },
              data: { balance: { decrement: roomChargeTotal } }
            });
          }
          if (completedPayments.length > 0) {
            await tx.payment.updateMany({
              where: { id: { in: completedPayments.map((payment) => payment.id) } },
              data: { status: client_1.PaymentStatus.VOID, voidedByUserId: user.userId, voidedByName: user.fullName, voidedAt: /* @__PURE__ */ new Date() }
            });
          }
          if (order.outlet.outletType === client_1.PosOutletType.BAR) {
            await this.returnBarStock(tx, propertyId, order, "Bar order void", (0, stock_ledger_1.stockActor)(user));
          }
          const now = /* @__PURE__ */ new Date();
          const updatedOrder = await tx.posOrder.update({
            where: { id: order.id },
            data: {
              status: client_1.PosOrderStatus.VOID,
              voidReason: reason,
              voidedAt: now,
              voidedByUserId: user.userId,
              voidedByName: user.fullName
            },
            include: orderInclude
          });
          if (order.tableId) {
            const otherOpenOrders = await tx.posOrder.count({
              where: {
                tableId: order.tableId,
                id: { not: order.id },
                status: { in: [client_1.PosOrderStatus.OPEN, client_1.PosOrderStatus.HELD] }
              }
            });
            if (otherOpenOrders === 0) {
              await tx.diningTable.update({ where: { id: order.tableId }, data: { status: "AVAILABLE" } });
            }
          }
          await tx.auditLog.create({
            data: (0, audit_service_1.auditData)({
              organizationId: user.organizationId,
              propertyId,
              userId: user.userId,
              actorName: user.fullName,
              module: "pos",
              action: "void_order",
              recordType: "pos_order",
              recordId: order.id,
              summary: `Voided ${order.orderNumber} (${order.currencyCode} ${order.grandTotal.toFixed(2)}, sold by ${order.createdByName ?? "Not recorded"}). Reason: ${reason}.`,
              previousValue: {
                orderNumber: order.orderNumber,
                status: order.status,
                grandTotal: order.grandTotal.toString()
              },
              newValue: {
                status: client_1.PosOrderStatus.VOID,
                reason,
                voidedPayments: completedPayments.map((payment) => payment.systemReceiptNumber),
                roomChargeReversed: roomChargeTotal.toString()
              }
            })
          });
          return updatedOrder;
        });
      }
      // Puts back whatever is still issued from the Bar Store for this order (issues minus earlier returns).
      async returnBarStock(tx, propertyId, order, label, actor) {
        const barStore = await tx.inventoryLocation.findFirst({
          where: { propertyId, code: "BAR", active: true }
        });
        if (!barStore) {
          return;
        }
        const movements = await tx.inventoryMovement.findMany({
          where: { propertyId, sourceId: order.id, status: client_1.InventoryMovementStatus.POSTED }
        });
        const netByItem = /* @__PURE__ */ new Map();
        for (const movement of movements) {
          const entry = netByItem.get(movement.itemId) ?? { quantity: new client_1.Prisma.Decimal(0), unitCost: movement.unitCost };
          if (movement.movementType === client_1.InventoryMovementType.ISSUE && movement.fromLocationId === barStore.id) {
            entry.quantity = entry.quantity.plus(movement.quantity);
            entry.unitCost = movement.unitCost;
          } else if (movement.movementType === client_1.InventoryMovementType.ADJUSTMENT && movement.toLocationId === barStore.id) {
            entry.quantity = entry.quantity.minus(movement.quantity);
          }
          netByItem.set(movement.itemId, entry);
        }
        const now = /* @__PURE__ */ new Date();
        const businessDate = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()));
        for (const [itemId, { quantity, unitCost }] of netByItem) {
          if (quantity.lte(0))
            continue;
          await (0, stock_ledger_1.lockBalance)(tx, itemId, barStore.id);
          const balance = await tx.inventoryBalance.upsert({
            where: { itemId_locationId: { itemId, locationId: barStore.id } },
            update: { quantityOnHand: { increment: quantity } },
            create: { itemId, locationId: barStore.id, quantityOnHand: quantity, averageCost: unitCost },
            include: { item: true }
          });
          const movement = await tx.inventoryMovement.create({
            data: {
              propertyId,
              itemId,
              toLocationId: barStore.id,
              movementType: client_1.InventoryMovementType.ADJUSTMENT,
              status: client_1.InventoryMovementStatus.POSTED,
              sourceType: `${label} ${order.orderNumber}`,
              sourceId: order.id,
              quantity,
              unitCost,
              totalCost: quantity.mul(unitCost),
              businessDate,
              postedAt: now,
              performedByUserId: actor.userId,
              performedByName: actor.name,
              reason: `${label} ${order.orderNumber}`,
              toQuantityBefore: balance.quantityOnHand.minus(quantity),
              toQuantityAfter: balance.quantityOnHand
            }
          });
          await (0, stock_ledger_1.recordStockMovementAudit)(tx, actor, {
            action: "sale_return",
            propertyId,
            movement,
            item: balance.item,
            to: barStore
          });
        }
      }
      // Bar sales relieve the Bar Store. Menu items are matched to inventory materials by
      // variant SKU, then product SKU, then name; unmatched items (e.g. cocktails) are skipped.
      async deductBarStock(tx, propertyId, order, actor) {
        const barStore = await tx.inventoryLocation.findFirst({
          where: { propertyId, code: "BAR", active: true }
        });
        if (!barStore) {
          return;
        }
        const items = await tx.inventoryItem.findMany({
          where: { propertyId, active: true }
        });
        const bySku = new Map(items.map((item) => [item.sku.toUpperCase(), item]));
        const byName = new Map(items.map((item) => [item.name.trim().toLowerCase(), item]));
        const now = /* @__PURE__ */ new Date();
        const businessDate = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()));
        for (const line of order.items) {
          const variant = line.productVariant;
          const item = bySku.get(variant.sku.toUpperCase()) ?? bySku.get(variant.product.sku.toUpperCase()) ?? byName.get(variant.product.name.trim().toLowerCase());
          if (!item) {
            continue;
          }
          await (0, stock_ledger_1.lockBalance)(tx, item.id, barStore.id);
          const balance = await tx.inventoryBalance.findUnique({
            where: {
              itemId_locationId: {
                itemId: item.id,
                locationId: barStore.id
              }
            }
          });
          const unitCost = balance?.averageCost ?? new client_1.Prisma.Decimal(0);
          const updatedBalance = await tx.inventoryBalance.upsert({
            where: {
              itemId_locationId: {
                itemId: item.id,
                locationId: barStore.id
              }
            },
            update: {
              quantityOnHand: {
                decrement: line.quantity
              }
            },
            create: {
              itemId: item.id,
              locationId: barStore.id,
              quantityOnHand: line.quantity.negated(),
              averageCost: unitCost
            }
          });
          const movement = await tx.inventoryMovement.create({
            data: {
              propertyId,
              itemId: item.id,
              fromLocationId: barStore.id,
              movementType: client_1.InventoryMovementType.ISSUE,
              status: client_1.InventoryMovementStatus.POSTED,
              sourceType: `Bar sale ${order.orderNumber}`,
              sourceId: order.id,
              quantity: line.quantity,
              unitCost,
              totalCost: line.quantity.mul(unitCost),
              businessDate,
              postedAt: now,
              performedByUserId: actor.userId,
              performedByName: actor.name,
              reason: `Bar sale ${order.orderNumber}`,
              fromQuantityBefore: updatedBalance.quantityOnHand.plus(line.quantity),
              fromQuantityAfter: updatedBalance.quantityOnHand
            }
          });
          await (0, stock_ledger_1.recordStockMovementAudit)(tx, actor, {
            action: "sale_deduction",
            propertyId,
            movement,
            item,
            from: barStore
          });
        }
      }
      async nextOrderNumber(tx, propertyId, date) {
        const year = date.getUTCFullYear();
        const count = await tx.posOrder.count({
          where: {
            propertyId,
            orderNumber: {
              startsWith: `POS-${year}-`
            }
          }
        });
        return `POS-${year}-${String(count + 1).padStart(5, "0")}`;
      }
      async nextReceiptNumber(tx, propertyId, date) {
        const year = date.getUTCFullYear();
        const count = await tx.payment.count({
          where: {
            propertyId,
            systemReceiptNumber: {
              startsWith: `RCT-${year}-`
            }
          }
        });
        return `RCT-${year}-${String(count + 1).padStart(5, "0")}`;
      }
      requireProperty(user) {
        if (!user.propertyId) {
          throw new common_1.BadRequestException("A property context is required.");
        }
        return user.propertyId;
      }
    };
    exports.PosService = PosService;
    exports.PosService = PosService = __decorate([
      (0, common_1.Injectable)(),
      __metadata("design:paramtypes", [prisma_service_1.PrismaService])
    ], PosService);
    var orderInclude = {
      items: {
        include: {
          productVariant: {
            include: {
              product: true
            }
          }
        }
      },
      outlet: true,
      payments: true,
      table: true
    };
    function itemSummary(items) {
      return items.map((item) => {
        const variant = item.productVariant.name;
        const showVariant = variant && !["regular", "standard", "default"].includes(variant.toLowerCase());
        return `${item.quantity.toNumber()} x ${item.productVariant.product.name}${showVariant ? ` (${variant})` : ""}`;
      }).join(", ");
    }
    function money(value) {
      return new client_1.Prisma.Decimal(value).toFixed(2);
    }
    function allowedOutletTypes(user) {
      return Object.values(client_1.PosOutletType).filter((outletType) => (0, shared_1.canUseOutlet)(user.permissions, outletType));
    }
    function assertOutletAccess(user, outlet) {
      if (!(0, shared_1.canUseOutlet)(user.permissions, outlet.outletType)) {
        throw new common_1.ForbiddenException(`You do not have access to the ${outlet.name} outlet.`);
      }
    }
    function prepStationFor(category, outletType) {
      if (outletType === "BAR") {
        return "Bar Printer";
      }
      const normalized = category.toLowerCase();
      if (normalized.includes("drink") || normalized.includes("bar") || normalized.includes("beverage")) {
        return "Bar Printer";
      }
      if (normalized.includes("service")) {
        return "Service Desk";
      }
      return "Restaurant Kitchen";
    }
    function currencyLabel(code) {
      return code === "USD" ? "USD" : "TSh";
    }
  }
});

// apps/api/dist/modules/pos/pos.controller.js
var require_pos_controller = __commonJS({
  "apps/api/dist/modules/pos/pos.controller.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = exports && exports.__metadata || function(k, v) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var __param = exports && exports.__param || function(paramIndex, decorator) {
      return function(target, key) {
        decorator(target, key, paramIndex);
      };
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.PosController = void 0;
    var common_1 = __require("@nestjs/common");
    var current_user_decorator_1 = require_current_user_decorator();
    var require_any_permissions_decorator_1 = require_require_any_permissions_decorator();
    var require_permissions_decorator_1 = require_require_permissions_decorator();
    var create_pos_order_dto_1 = require_create_pos_order_dto();
    var pay_pos_order_dto_1 = require_pay_pos_order_dto();
    var update_pos_order_dto_1 = require_update_pos_order_dto();
    var void_pos_order_dto_1 = require_void_pos_order_dto();
    var pos_service_1 = require_pos_service();
    var PosController = class PosController {
      pos;
      constructor(pos) {
        this.pos = pos;
      }
      listOutlets(user) {
        return this.pos.listOutlets(user);
      }
      listCatalog(user, outletId) {
        return this.pos.listCatalog(user, outletId);
      }
      listOrders(user) {
        return this.pos.listOrders(user);
      }
      listPrepNotifications(user, station) {
        return this.pos.listPrepNotifications(user, station);
      }
      listChargeableRooms(user) {
        return this.pos.listChargeableRooms(user);
      }
      listBarLowStock(user) {
        return this.pos.listBarLowStock(user);
      }
      createOrder(user, dto) {
        return this.pos.createOrder(user, dto);
      }
      payOrder(user, orderId, dto) {
        return this.pos.payOrder(user, orderId, dto);
      }
      updateOrder(user, orderId, dto) {
        return this.pos.updateOrder(user, orderId, dto);
      }
      // Cashiers can void unpaid orders; voiding a paid order also needs pos.orders.void (checked in the service).
      voidOrder(user, orderId, dto) {
        return this.pos.voidOrder(user, orderId, dto);
      }
    };
    exports.PosController = PosController;
    __decorate([
      (0, require_permissions_decorator_1.RequirePermissions)("pos.view"),
      (0, common_1.Get)("outlets"),
      __param(0, (0, current_user_decorator_1.CurrentUser)()),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", [Object]),
      __metadata("design:returntype", void 0)
    ], PosController.prototype, "listOutlets", null);
    __decorate([
      (0, require_permissions_decorator_1.RequirePermissions)("pos.view"),
      (0, common_1.Get)("outlets/:outletId/catalog"),
      __param(0, (0, current_user_decorator_1.CurrentUser)()),
      __param(1, (0, common_1.Param)("outletId")),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", [Object, String]),
      __metadata("design:returntype", void 0)
    ], PosController.prototype, "listCatalog", null);
    __decorate([
      (0, require_permissions_decorator_1.RequirePermissions)("pos.view"),
      (0, common_1.Get)("orders"),
      __param(0, (0, current_user_decorator_1.CurrentUser)()),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", [Object]),
      __metadata("design:returntype", void 0)
    ], PosController.prototype, "listOrders", null);
    __decorate([
      (0, require_permissions_decorator_1.RequirePermissions)("pos.view"),
      (0, common_1.Get)("prep-notifications"),
      __param(0, (0, current_user_decorator_1.CurrentUser)()),
      __param(1, (0, common_1.Query)("station")),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", [Object, String]),
      __metadata("design:returntype", void 0)
    ], PosController.prototype, "listPrepNotifications", null);
    __decorate([
      (0, require_permissions_decorator_1.RequirePermissions)("pos.view"),
      (0, common_1.Get)("chargeable-rooms"),
      __param(0, (0, current_user_decorator_1.CurrentUser)()),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", [Object]),
      __metadata("design:returntype", void 0)
    ], PosController.prototype, "listChargeableRooms", null);
    __decorate([
      (0, require_permissions_decorator_1.RequirePermissions)("pos.view"),
      (0, common_1.Get)("bar-low-stock"),
      __param(0, (0, current_user_decorator_1.CurrentUser)()),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", [Object]),
      __metadata("design:returntype", void 0)
    ], PosController.prototype, "listBarLowStock", null);
    __decorate([
      (0, require_permissions_decorator_1.RequirePermissions)("pos.orders.create"),
      (0, common_1.Post)("orders"),
      __param(0, (0, current_user_decorator_1.CurrentUser)()),
      __param(1, (0, common_1.Body)()),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", [Object, create_pos_order_dto_1.CreatePosOrderDto]),
      __metadata("design:returntype", void 0)
    ], PosController.prototype, "createOrder", null);
    __decorate([
      (0, require_permissions_decorator_1.RequirePermissions)("pos.orders.pay"),
      (0, common_1.Post)("orders/:orderId/payments"),
      __param(0, (0, current_user_decorator_1.CurrentUser)()),
      __param(1, (0, common_1.Param)("orderId")),
      __param(2, (0, common_1.Body)()),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", [Object, String, pay_pos_order_dto_1.PayPosOrderDto]),
      __metadata("design:returntype", void 0)
    ], PosController.prototype, "payOrder", null);
    __decorate([
      (0, require_permissions_decorator_1.RequirePermissions)("pos.orders.create"),
      (0, common_1.Patch)("orders/:orderId"),
      __param(0, (0, current_user_decorator_1.CurrentUser)()),
      __param(1, (0, common_1.Param)("orderId")),
      __param(2, (0, common_1.Body)()),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", [Object, String, update_pos_order_dto_1.UpdatePosOrderDto]),
      __metadata("design:returntype", void 0)
    ], PosController.prototype, "updateOrder", null);
    __decorate([
      (0, require_any_permissions_decorator_1.RequireAnyPermissions)("pos.orders.create", "pos.orders.void"),
      (0, common_1.Post)("orders/:orderId/void"),
      __param(0, (0, current_user_decorator_1.CurrentUser)()),
      __param(1, (0, common_1.Param)("orderId")),
      __param(2, (0, common_1.Body)()),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", [Object, String, void_pos_order_dto_1.VoidPosOrderDto]),
      __metadata("design:returntype", void 0)
    ], PosController.prototype, "voidOrder", null);
    exports.PosController = PosController = __decorate([
      (0, common_1.Controller)("pos"),
      __metadata("design:paramtypes", [pos_service_1.PosService])
    ], PosController);
  }
});

// apps/api/dist/modules/pos/pos.module.js
var require_pos_module = __commonJS({
  "apps/api/dist/modules/pos/pos.module.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.PosModule = void 0;
    var common_1 = __require("@nestjs/common");
    var pos_menu_controller_1 = require_pos_menu_controller();
    var pos_menu_service_1 = require_pos_menu_service();
    var pos_controller_1 = require_pos_controller();
    var pos_service_1 = require_pos_service();
    var PosModule = class PosModule {
    };
    exports.PosModule = PosModule;
    exports.PosModule = PosModule = __decorate([
      (0, common_1.Module)({
        controllers: [pos_controller_1.PosController, pos_menu_controller_1.PosMenuController],
        providers: [pos_service_1.PosService, pos_menu_service_1.PosMenuService],
        exports: [pos_service_1.PosService, pos_menu_service_1.PosMenuService]
      })
    ], PosModule);
  }
});

// apps/api/dist/modules/properties/dto/create-property.dto.js
var require_create_property_dto = __commonJS({
  "apps/api/dist/modules/properties/dto/create-property.dto.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = exports && exports.__metadata || function(k, v) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.CreatePropertyDto = void 0;
    var class_validator_1 = __require("class-validator");
    var CreatePropertyDto = class {
      name;
      code;
    };
    exports.CreatePropertyDto = CreatePropertyDto;
    __decorate([
      (0, class_validator_1.IsString)(),
      (0, class_validator_1.IsNotEmpty)(),
      (0, class_validator_1.MaxLength)(120),
      __metadata("design:type", String)
    ], CreatePropertyDto.prototype, "name", void 0);
    __decorate([
      (0, class_validator_1.IsString)(),
      (0, class_validator_1.IsNotEmpty)(),
      (0, class_validator_1.MaxLength)(20),
      (0, class_validator_1.Matches)(/^[A-Z0-9-]+$/),
      __metadata("design:type", String)
    ], CreatePropertyDto.prototype, "code", void 0);
  }
});

// apps/api/dist/modules/properties/dto/update-property-settings.dto.js
var require_update_property_settings_dto = __commonJS({
  "apps/api/dist/modules/properties/dto/update-property-settings.dto.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = exports && exports.__metadata || function(k, v) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.UpdatePropertySettingsDto = void 0;
    var class_validator_1 = __require("class-validator");
    var UpdatePropertySettingsDto = class {
      currencyCode;
      currencySymbol;
      currencyPrecision;
      fiscalYearStart;
      checkInTime;
      checkOutTime;
      numberingRules;
    };
    exports.UpdatePropertySettingsDto = UpdatePropertySettingsDto;
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsString)(),
      __metadata("design:type", String)
    ], UpdatePropertySettingsDto.prototype, "currencyCode", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsString)(),
      __metadata("design:type", String)
    ], UpdatePropertySettingsDto.prototype, "currencySymbol", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsInt)(),
      (0, class_validator_1.Min)(0),
      (0, class_validator_1.Max)(6),
      __metadata("design:type", Number)
    ], UpdatePropertySettingsDto.prototype, "currencyPrecision", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsISO8601)(),
      __metadata("design:type", String)
    ], UpdatePropertySettingsDto.prototype, "fiscalYearStart", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsString)(),
      __metadata("design:type", String)
    ], UpdatePropertySettingsDto.prototype, "checkInTime", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsString)(),
      __metadata("design:type", String)
    ], UpdatePropertySettingsDto.prototype, "checkOutTime", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsObject)(),
      __metadata("design:type", Object)
    ], UpdatePropertySettingsDto.prototype, "numberingRules", void 0);
  }
});

// apps/api/dist/modules/properties/properties.service.js
var require_properties_service = __commonJS({
  "apps/api/dist/modules/properties/properties.service.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = exports && exports.__metadata || function(k, v) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.PropertiesService = void 0;
    var common_1 = __require("@nestjs/common");
    var prisma_service_1 = require_prisma_service();
    var audit_service_1 = require_audit_service();
    var PropertiesService = class PropertiesService {
      audit;
      prisma;
      constructor(audit, prisma) {
        this.audit = audit;
        this.prisma = prisma;
      }
      list(organizationId) {
        return this.prisma.property.findMany({
          where: { organizationId },
          include: { propertySettings: true },
          orderBy: { name: "asc" }
        });
      }
      async create(user, dto) {
        const existing = await this.prisma.property.findUnique({
          where: {
            organizationId_code: {
              organizationId: user.organizationId,
              code: dto.code
            }
          }
        });
        if (existing) {
          throw new common_1.ConflictException("A property with this code already exists.");
        }
        const property = await this.prisma.property.create({
          data: {
            organizationId: user.organizationId,
            name: dto.name,
            code: dto.code,
            propertySettings: {
              create: {
                fiscalYearStart: /* @__PURE__ */ new Date(`${(/* @__PURE__ */ new Date()).getUTCFullYear()}-01-01T00:00:00.000Z`)
              }
            }
          },
          include: { propertySettings: true }
        });
        await this.audit.record({
          organizationId: user.organizationId,
          propertyId: property.id,
          userId: user.userId,
          module: "properties",
          action: "create",
          recordType: "property",
          recordId: property.id,
          newValue: {
            id: property.id,
            code: property.code,
            name: property.name,
            status: property.status
          }
        });
        return property;
      }
      async getSettings(user, propertyId) {
        await this.assertPropertyAccess(user, propertyId);
        return this.prisma.propertySetting.findUniqueOrThrow({
          where: { propertyId }
        });
      }
      async updateSettings(user, propertyId, dto) {
        await this.assertPropertyAccess(user, propertyId);
        const previous = await this.prisma.propertySetting.findUnique({
          where: { propertyId }
        });
        const numberingRules = dto.numberingRules;
        const updated = await this.prisma.propertySetting.upsert({
          where: { propertyId },
          update: {
            currencyCode: dto.currencyCode,
            currencySymbol: dto.currencySymbol,
            currencyPrecision: dto.currencyPrecision,
            fiscalYearStart: dto.fiscalYearStart ? new Date(dto.fiscalYearStart) : void 0,
            checkInTime: dto.checkInTime,
            checkOutTime: dto.checkOutTime,
            numberingRules
          },
          create: {
            propertyId,
            currencyCode: dto.currencyCode ?? "USD",
            currencySymbol: dto.currencySymbol ?? "$",
            currencyPrecision: dto.currencyPrecision ?? 2,
            fiscalYearStart: dto.fiscalYearStart ? new Date(dto.fiscalYearStart) : /* @__PURE__ */ new Date(`${(/* @__PURE__ */ new Date()).getUTCFullYear()}-01-01T00:00:00.000Z`),
            checkInTime: dto.checkInTime ?? "14:00",
            checkOutTime: dto.checkOutTime ?? "11:00",
            numberingRules: numberingRules ?? {}
          }
        });
        await this.audit.record({
          organizationId: user.organizationId,
          propertyId,
          userId: user.userId,
          module: "settings",
          action: "update",
          recordType: "property_settings",
          recordId: updated.id,
          previousValue: previous ? {
            currencyCode: previous.currencyCode,
            currencySymbol: previous.currencySymbol,
            currencyPrecision: previous.currencyPrecision,
            checkInTime: previous.checkInTime,
            checkOutTime: previous.checkOutTime,
            numberingRules: previous.numberingRules
          } : void 0,
          newValue: {
            currencyCode: updated.currencyCode,
            currencySymbol: updated.currencySymbol,
            currencyPrecision: updated.currencyPrecision,
            checkInTime: updated.checkInTime,
            checkOutTime: updated.checkOutTime,
            numberingRules: updated.numberingRules
          }
        });
        return updated;
      }
      async assertPropertyAccess(user, propertyId) {
        const property = await this.prisma.property.findFirst({
          where: {
            id: propertyId,
            organizationId: user.organizationId
          }
        });
        if (!property) {
          throw new common_1.NotFoundException("Property was not found.");
        }
      }
    };
    exports.PropertiesService = PropertiesService;
    exports.PropertiesService = PropertiesService = __decorate([
      (0, common_1.Injectable)(),
      __metadata("design:paramtypes", [
        audit_service_1.AuditService,
        prisma_service_1.PrismaService
      ])
    ], PropertiesService);
  }
});

// apps/api/dist/modules/properties/properties.controller.js
var require_properties_controller = __commonJS({
  "apps/api/dist/modules/properties/properties.controller.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = exports && exports.__metadata || function(k, v) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var __param = exports && exports.__param || function(paramIndex, decorator) {
      return function(target, key) {
        decorator(target, key, paramIndex);
      };
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.PropertiesController = void 0;
    var common_1 = __require("@nestjs/common");
    var current_user_decorator_1 = require_current_user_decorator();
    var require_permissions_decorator_1 = require_require_permissions_decorator();
    var create_property_dto_1 = require_create_property_dto();
    var update_property_settings_dto_1 = require_update_property_settings_dto();
    var properties_service_1 = require_properties_service();
    var PropertiesController = class PropertiesController {
      properties;
      constructor(properties) {
        this.properties = properties;
      }
      list(user) {
        return this.properties.list(user.organizationId);
      }
      create(user, dto) {
        return this.properties.create(user, dto);
      }
      getSettings(user, propertyId) {
        return this.properties.getSettings(user, propertyId);
      }
      updateSettings(user, propertyId, dto) {
        return this.properties.updateSettings(user, propertyId, dto);
      }
    };
    exports.PropertiesController = PropertiesController;
    __decorate([
      (0, require_permissions_decorator_1.RequirePermissions)("properties.view"),
      (0, common_1.Get)(),
      __param(0, (0, current_user_decorator_1.CurrentUser)()),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", [Object]),
      __metadata("design:returntype", void 0)
    ], PropertiesController.prototype, "list", null);
    __decorate([
      (0, require_permissions_decorator_1.RequirePermissions)("properties.manage"),
      (0, common_1.Post)(),
      __param(0, (0, current_user_decorator_1.CurrentUser)()),
      __param(1, (0, common_1.Body)()),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", [Object, create_property_dto_1.CreatePropertyDto]),
      __metadata("design:returntype", void 0)
    ], PropertiesController.prototype, "create", null);
    __decorate([
      (0, require_permissions_decorator_1.RequirePermissions)("settings.view"),
      (0, common_1.Get)(":propertyId/settings"),
      __param(0, (0, current_user_decorator_1.CurrentUser)()),
      __param(1, (0, common_1.Param)("propertyId")),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", [Object, String]),
      __metadata("design:returntype", void 0)
    ], PropertiesController.prototype, "getSettings", null);
    __decorate([
      (0, require_permissions_decorator_1.RequirePermissions)("settings.manage"),
      (0, common_1.Patch)(":propertyId/settings"),
      __param(0, (0, current_user_decorator_1.CurrentUser)()),
      __param(1, (0, common_1.Param)("propertyId")),
      __param(2, (0, common_1.Body)()),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", [Object, String, update_property_settings_dto_1.UpdatePropertySettingsDto]),
      __metadata("design:returntype", void 0)
    ], PropertiesController.prototype, "updateSettings", null);
    exports.PropertiesController = PropertiesController = __decorate([
      (0, common_1.Controller)("properties"),
      __metadata("design:paramtypes", [properties_service_1.PropertiesService])
    ], PropertiesController);
  }
});

// apps/api/dist/modules/properties/properties.module.js
var require_properties_module = __commonJS({
  "apps/api/dist/modules/properties/properties.module.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.PropertiesModule = void 0;
    var common_1 = __require("@nestjs/common");
    var audit_module_1 = require_audit_module();
    var properties_controller_1 = require_properties_controller();
    var properties_service_1 = require_properties_service();
    var PropertiesModule = class PropertiesModule {
    };
    exports.PropertiesModule = PropertiesModule;
    exports.PropertiesModule = PropertiesModule = __decorate([
      (0, common_1.Module)({
        imports: [audit_module_1.AuditModule],
        controllers: [properties_controller_1.PropertiesController],
        providers: [properties_service_1.PropertiesService]
      })
    ], PropertiesModule);
  }
});

// apps/api/dist/modules/purchasing/dto/create-purchase-order.dto.js
var require_create_purchase_order_dto = __commonJS({
  "apps/api/dist/modules/purchasing/dto/create-purchase-order.dto.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = exports && exports.__metadata || function(k, v) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.CreatePurchaseOrderDto = exports.CreatePurchaseOrderLineDto = void 0;
    var class_transformer_1 = __require("class-transformer");
    var class_validator_1 = __require("class-validator");
    var CreatePurchaseOrderLineDto = class {
      inventoryItemId;
      quantity;
      unitCost;
      taxAmount;
      description;
    };
    exports.CreatePurchaseOrderLineDto = CreatePurchaseOrderLineDto;
    __decorate([
      (0, class_validator_1.IsUUID)(),
      __metadata("design:type", String)
    ], CreatePurchaseOrderLineDto.prototype, "inventoryItemId", void 0);
    __decorate([
      (0, class_validator_1.IsNumberString)(),
      __metadata("design:type", String)
    ], CreatePurchaseOrderLineDto.prototype, "quantity", void 0);
    __decorate([
      (0, class_validator_1.IsNumberString)(),
      __metadata("design:type", String)
    ], CreatePurchaseOrderLineDto.prototype, "unitCost", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsNumberString)(),
      __metadata("design:type", String)
    ], CreatePurchaseOrderLineDto.prototype, "taxAmount", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsString)(),
      (0, class_validator_1.MaxLength)(200),
      __metadata("design:type", String)
    ], CreatePurchaseOrderLineDto.prototype, "description", void 0);
    var CreatePurchaseOrderDto = class {
      supplierId;
      expectedAt;
      notes;
      lines;
    };
    exports.CreatePurchaseOrderDto = CreatePurchaseOrderDto;
    __decorate([
      (0, class_validator_1.IsUUID)(),
      __metadata("design:type", String)
    ], CreatePurchaseOrderDto.prototype, "supplierId", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsISO8601)(),
      __metadata("design:type", String)
    ], CreatePurchaseOrderDto.prototype, "expectedAt", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsString)(),
      (0, class_validator_1.MaxLength)(500),
      __metadata("design:type", String)
    ], CreatePurchaseOrderDto.prototype, "notes", void 0);
    __decorate([
      (0, class_validator_1.IsArray)(),
      (0, class_validator_1.ArrayMinSize)(1),
      (0, class_validator_1.ArrayMaxSize)(100),
      (0, class_validator_1.ValidateNested)({ each: true }),
      (0, class_transformer_1.Type)(() => CreatePurchaseOrderLineDto),
      __metadata("design:type", Array)
    ], CreatePurchaseOrderDto.prototype, "lines", void 0);
  }
});

// apps/api/dist/modules/purchasing/dto/create-supplier.dto.js
var require_create_supplier_dto = __commonJS({
  "apps/api/dist/modules/purchasing/dto/create-supplier.dto.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = exports && exports.__metadata || function(k, v) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.CreateSupplierDto = void 0;
    var class_validator_1 = __require("class-validator");
    var CreateSupplierDto = class {
      name;
      supplierCode;
      email;
      phone;
      taxNumber;
      paymentTerms;
    };
    exports.CreateSupplierDto = CreateSupplierDto;
    __decorate([
      (0, class_validator_1.IsString)(),
      (0, class_validator_1.IsNotEmpty)(),
      (0, class_validator_1.MaxLength)(160),
      __metadata("design:type", String)
    ], CreateSupplierDto.prototype, "name", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsString)(),
      (0, class_validator_1.MaxLength)(40),
      __metadata("design:type", String)
    ], CreateSupplierDto.prototype, "supplierCode", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsEmail)(),
      (0, class_validator_1.MaxLength)(160),
      __metadata("design:type", String)
    ], CreateSupplierDto.prototype, "email", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsString)(),
      (0, class_validator_1.MaxLength)(40),
      __metadata("design:type", String)
    ], CreateSupplierDto.prototype, "phone", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsString)(),
      (0, class_validator_1.MaxLength)(60),
      __metadata("design:type", String)
    ], CreateSupplierDto.prototype, "taxNumber", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsString)(),
      (0, class_validator_1.MaxLength)(60),
      __metadata("design:type", String)
    ], CreateSupplierDto.prototype, "paymentTerms", void 0);
  }
});

// apps/api/dist/modules/purchasing/dto/receive-purchase-order.dto.js
var require_receive_purchase_order_dto = __commonJS({
  "apps/api/dist/modules/purchasing/dto/receive-purchase-order.dto.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = exports && exports.__metadata || function(k, v) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.ReceivePurchaseOrderDto = exports.ReceivePurchaseOrderLineDto = void 0;
    var class_transformer_1 = __require("class-transformer");
    var class_validator_1 = __require("class-validator");
    var ReceivePurchaseOrderLineDto = class {
      lineId;
      quantity;
    };
    exports.ReceivePurchaseOrderLineDto = ReceivePurchaseOrderLineDto;
    __decorate([
      (0, class_validator_1.IsUUID)(),
      __metadata("design:type", String)
    ], ReceivePurchaseOrderLineDto.prototype, "lineId", void 0);
    __decorate([
      (0, class_validator_1.IsNumberString)(),
      __metadata("design:type", String)
    ], ReceivePurchaseOrderLineDto.prototype, "quantity", void 0);
    var ReceivePurchaseOrderDto = class {
      // When omitted, every outstanding quantity on the order is received in full.
      lines;
      deliveryNote;
    };
    exports.ReceivePurchaseOrderDto = ReceivePurchaseOrderDto;
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsArray)(),
      (0, class_validator_1.ArrayMaxSize)(100),
      (0, class_validator_1.ValidateNested)({ each: true }),
      (0, class_transformer_1.Type)(() => ReceivePurchaseOrderLineDto),
      __metadata("design:type", Array)
    ], ReceivePurchaseOrderDto.prototype, "lines", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsString)(),
      (0, class_validator_1.MaxLength)(80),
      __metadata("design:type", String)
    ], ReceivePurchaseOrderDto.prototype, "deliveryNote", void 0);
  }
});

// apps/api/dist/modules/purchasing/dto/record-supplier-invoice.dto.js
var require_record_supplier_invoice_dto = __commonJS({
  "apps/api/dist/modules/purchasing/dto/record-supplier-invoice.dto.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = exports && exports.__metadata || function(k, v) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.RecordSupplierInvoiceDto = void 0;
    var class_validator_1 = __require("class-validator");
    var RecordSupplierInvoiceDto = class {
      invoiceNumber;
      invoiceDate;
      dueDate;
      // Invoice value before tax; this is what is matched against the value of goods received.
      subtotal;
      taxTotal;
    };
    exports.RecordSupplierInvoiceDto = RecordSupplierInvoiceDto;
    __decorate([
      (0, class_validator_1.IsString)(),
      (0, class_validator_1.IsNotEmpty)(),
      (0, class_validator_1.MaxLength)(80),
      __metadata("design:type", String)
    ], RecordSupplierInvoiceDto.prototype, "invoiceNumber", void 0);
    __decorate([
      (0, class_validator_1.IsISO8601)(),
      __metadata("design:type", String)
    ], RecordSupplierInvoiceDto.prototype, "invoiceDate", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsISO8601)(),
      __metadata("design:type", String)
    ], RecordSupplierInvoiceDto.prototype, "dueDate", void 0);
    __decorate([
      (0, class_validator_1.IsNumberString)(),
      __metadata("design:type", String)
    ], RecordSupplierInvoiceDto.prototype, "subtotal", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsNumberString)(),
      __metadata("design:type", String)
    ], RecordSupplierInvoiceDto.prototype, "taxTotal", void 0);
  }
});

// apps/api/dist/modules/purchasing/purchasing.service.js
var require_purchasing_service = __commonJS({
  "apps/api/dist/modules/purchasing/purchasing.service.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = exports && exports.__metadata || function(k, v) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.PurchasingService = void 0;
    var common_1 = __require("@nestjs/common");
    var shared_1 = __require("@hms/shared");
    var client_1 = __require("@prisma/client");
    var prisma_service_1 = require_prisma_service();
    var journal_balancer_1 = require_journal_balancer();
    var audit_service_1 = require_audit_service();
    var stock_ledger_1 = require_stock_ledger();
    var stock_receipt_1 = require_stock_receipt();
    var MAIN_STORE_CODE = "MAIN";
    var INVENTORY_ACCOUNT_CODE = "1400";
    var ACCOUNTS_PAYABLE_ACCOUNT_CODE = "2100";
    var MATCH_TOLERANCE = new client_1.Prisma.Decimal("0.01");
    var ZERO = new client_1.Prisma.Decimal(0);
    var orderInclude = {
      supplier: true,
      lines: {
        include: { inventoryItem: true },
        orderBy: { createdAt: "asc" }
      },
      supplierInvoices: {
        orderBy: { createdAt: "asc" }
      }
    };
    var PurchasingService = class PurchasingService {
      prisma;
      audit;
      constructor(prisma, audit) {
        this.prisma = prisma;
        this.audit = audit;
      }
      async getOverview(user) {
        const propertyId = this.requireProperty(user);
        const mainStore = await this.ensureMainStore(propertyId);
        const [suppliers, orders, items] = await Promise.all([
          this.prisma.supplier.findMany({
            where: { propertyId },
            orderBy: { name: "asc" }
          }),
          this.prisma.purchaseOrder.findMany({
            where: { propertyId },
            include: orderInclude,
            orderBy: { orderedAt: "desc" },
            take: 200
          }),
          this.prisma.inventoryItem.findMany({
            where: { propertyId, active: true },
            include: {
              balances: { where: { locationId: mainStore.id } }
            },
            orderBy: { name: "asc" }
          })
        ]);
        const mappedOrders = orders.map(mapOrder);
        const openStatuses = [
          client_1.PurchaseOrderStatus.DRAFT,
          client_1.PurchaseOrderStatus.PENDING_APPROVAL,
          client_1.PurchaseOrderStatus.APPROVED,
          client_1.PurchaseOrderStatus.PARTIALLY_RECEIVED
        ];
        return {
          canReceive: (0, shared_1.canUseStore)(user.permissions, MAIN_STORE_CODE),
          mainStore: { id: mainStore.id, name: mainStore.name },
          suppliers: suppliers.map((supplier) => ({
            ...mapSupplier(supplier),
            openOrders: orders.filter((order) => order.supplierId === supplier.id && openStatuses.includes(order.status)).length
          })),
          items: items.map((item) => ({
            id: item.id,
            sku: item.sku,
            name: item.name,
            unit: item.unitOfMeasure,
            onHand: Number(item.balances[0]?.quantityOnHand ?? 0),
            lastCost: Number(item.balances[0]?.averageCost ?? 0)
          })),
          orders: mappedOrders,
          summary: {
            awaitingApproval: mappedOrders.filter((order) => order.status === "DRAFT" || order.status === "PENDING_APPROVAL").length,
            awaitingReceipt: mappedOrders.filter((order) => order.status === "APPROVED" || order.status === "PARTIALLY_RECEIVED").length,
            receivedNotInvoiced: round2(mappedOrders.reduce((sum, order) => sum + Math.max(order.receivedValue - order.invoicedValue, 0), 0)),
            openPayables: round2(mappedOrders.reduce((sum, order) => sum + order.invoices.filter((invoice) => invoice.status !== "VOID" && invoice.status !== "PAID").reduce((total, invoice) => total + invoice.grandTotal - invoice.paidTotal, 0), 0)),
            varianceCount: mappedOrders.filter((order) => order.hasVariance).length
          }
        };
      }
      async createSupplier(user, dto) {
        const propertyId = this.requireProperty(user);
        const name = dto.name.trim();
        if (!name) {
          throw new common_1.BadRequestException("Supplier name is required.");
        }
        const requestedCode = dto.supplierCode?.trim().toUpperCase();
        const data = {
          propertyId,
          name,
          email: dto.email?.trim() || null,
          phone: dto.phone?.trim() || null,
          taxNumber: dto.taxNumber?.trim() || null,
          paymentTerms: dto.paymentTerms?.trim() || null
        };
        const duplicateName = await this.prisma.supplier.findFirst({
          where: { propertyId, name: { equals: name, mode: "insensitive" } }
        });
        if (duplicateName) {
          throw new common_1.ConflictException(`Supplier ${duplicateName.name} already exists.`);
        }
        let supplier = null;
        if (requestedCode) {
          const existing = await this.prisma.supplier.findFirst({ where: { propertyId, supplierCode: requestedCode } });
          if (existing) {
            throw new common_1.ConflictException(`Supplier code ${requestedCode} is already used by ${existing.name}.`);
          }
          supplier = await this.prisma.supplier.create({ data: { ...data, supplierCode: requestedCode } });
        } else {
          supplier = await withUniqueRetry(async () => {
            const last = await this.prisma.supplier.findFirst({
              where: { propertyId, supplierCode: { startsWith: "SUP-" } },
              orderBy: { supplierCode: "desc" }
            });
            return this.prisma.supplier.create({
              data: { ...data, supplierCode: nextNumber("SUP-", last?.supplierCode) }
            });
          });
        }
        await this.audit.record({
          organizationId: user.organizationId,
          propertyId,
          userId: user.userId,
          module: "purchasing",
          action: "create_supplier",
          recordType: "supplier",
          recordId: supplier.id,
          newValue: { supplierCode: supplier.supplierCode, name: supplier.name, paymentTerms: supplier.paymentTerms }
        });
        return { ...mapSupplier(supplier), openOrders: 0 };
      }
      async createOrder(user, dto) {
        const propertyId = this.requireProperty(user);
        const supplier = await this.prisma.supplier.findFirst({
          where: { id: dto.supplierId, propertyId }
        });
        if (!supplier) {
          throw new common_1.NotFoundException("Supplier was not found.");
        }
        if (supplier.status !== client_1.RecordStatus.ACTIVE) {
          throw new common_1.BadRequestException(`${supplier.name} is not an active supplier.`);
        }
        const itemIds = [...new Set(dto.lines.map((line) => line.inventoryItemId))];
        const items = await this.prisma.inventoryItem.findMany({
          where: { id: { in: itemIds }, propertyId, active: true }
        });
        const itemsById = new Map(items.map((item) => [item.id, item]));
        let subtotal = ZERO;
        let taxTotal = ZERO;
        const lines = dto.lines.map((line, index) => {
          const item = itemsById.get(line.inventoryItemId);
          if (!item) {
            throw new common_1.NotFoundException(`Material on line ${index + 1} was not found.`);
          }
          const quantity = new client_1.Prisma.Decimal(line.quantity);
          const unitCost = new client_1.Prisma.Decimal(line.unitCost);
          const taxAmount = new client_1.Prisma.Decimal(line.taxAmount || "0");
          if (quantity.lte(0)) {
            throw new common_1.BadRequestException(`Quantity on line ${index + 1} must be greater than zero.`);
          }
          if (unitCost.lt(0) || taxAmount.lt(0)) {
            throw new common_1.BadRequestException(`Cost and tax on line ${index + 1} cannot be negative.`);
          }
          const lineSubtotal = quantity.mul(unitCost);
          subtotal = subtotal.plus(lineSubtotal);
          taxTotal = taxTotal.plus(taxAmount);
          return {
            inventoryItemId: item.id,
            description: line.description?.trim() || item.name,
            quantityOrdered: quantity,
            unitCost,
            taxAmount,
            totalAmount: lineSubtotal.plus(taxAmount)
          };
        });
        const expectedAt = dto.expectedAt ? parseDateOnly(dto.expectedAt, "Expected delivery date") : null;
        const year = (/* @__PURE__ */ new Date()).getUTCFullYear();
        const order = await withUniqueRetry(async () => {
          const last = await this.prisma.purchaseOrder.findFirst({
            where: { propertyId, orderNumber: { startsWith: `PO-${year}-` } },
            orderBy: { orderNumber: "desc" }
          });
          return this.prisma.purchaseOrder.create({
            data: {
              propertyId,
              supplierId: supplier.id,
              orderNumber: nextNumber(`PO-${year}-`, last?.orderNumber),
              status: client_1.PurchaseOrderStatus.DRAFT,
              expectedAt,
              subtotal,
              taxTotal,
              grandTotal: subtotal.plus(taxTotal),
              notes: dto.notes?.trim() || null,
              lines: { create: lines }
            },
            include: orderInclude
          });
        });
        await this.audit.record({
          organizationId: user.organizationId,
          propertyId,
          userId: user.userId,
          module: "purchasing",
          action: "create_purchase_order",
          recordType: "purchase_order",
          recordId: order.id,
          newValue: {
            orderNumber: order.orderNumber,
            supplierId: supplier.id,
            supplierName: supplier.name,
            lineCount: order.lines.length,
            grandTotal: order.grandTotal.toFixed(2)
          }
        });
        return mapOrder(order);
      }
      submitOrder(user, orderId) {
        return this.transitionOrder(user, orderId, "submit_purchase_order", [client_1.PurchaseOrderStatus.DRAFT], {
          status: client_1.PurchaseOrderStatus.PENDING_APPROVAL
        });
      }
      approveOrder(user, orderId) {
        return this.transitionOrder(user, orderId, "approve_purchase_order", [client_1.PurchaseOrderStatus.DRAFT, client_1.PurchaseOrderStatus.PENDING_APPROVAL], { status: client_1.PurchaseOrderStatus.APPROVED, approvedAt: /* @__PURE__ */ new Date() });
      }
      async cancelOrder(user, orderId) {
        const propertyId = this.requireProperty(user);
        const order = await this.findOrder(this.prisma, propertyId, orderId);
        if (order.lines.some((line) => line.quantityReceived.gt(0))) {
          throw new common_1.ConflictException(`${order.orderNumber} already has goods received and cannot be cancelled.`);
        }
        return this.transitionOrder(user, orderId, "cancel_purchase_order", [client_1.PurchaseOrderStatus.DRAFT, client_1.PurchaseOrderStatus.PENDING_APPROVAL, client_1.PurchaseOrderStatus.APPROVED], { status: client_1.PurchaseOrderStatus.CANCELLED });
      }
      async receiveOrder(user, orderId, dto) {
        const propertyId = this.requireProperty(user);
        if (!(0, shared_1.canUseStore)(user.permissions, MAIN_STORE_CODE)) {
          throw new common_1.ForbiddenException("Receiving goods requires access to the Main Store.");
        }
        const mainStore = await this.ensureMainStore(propertyId);
        const businessDate = todayDateOnly();
        const deliveryNote = dto.deliveryNote?.trim() || null;
        const result = await this.prisma.$transaction(async (tx) => {
          await tx.$executeRaw`SELECT 1 FROM purchase_orders WHERE id = ${orderId}::uuid AND property_id = ${propertyId}::uuid FOR UPDATE`;
          const order = await this.findOrder(tx, propertyId, orderId);
          if (order.status !== client_1.PurchaseOrderStatus.APPROVED && order.status !== client_1.PurchaseOrderStatus.PARTIALLY_RECEIVED) {
            throw new common_1.ConflictException(`${order.orderNumber} is ${statusLabel(order.status)}. Only approved orders can be received.`);
          }
          const linesById = new Map(order.lines.map((line) => [line.id, line]));
          const requested = dto.lines?.length ? dto.lines.map((entry) => {
            const line = linesById.get(entry.lineId);
            if (!line) {
              throw new common_1.NotFoundException("A receipt line does not belong to this purchase order.");
            }
            return { line, quantity: new client_1.Prisma.Decimal(entry.quantity) };
          }) : order.lines.map((line) => ({ line, quantity: line.quantityOrdered.minus(line.quantityReceived) }));
          const seen = /* @__PURE__ */ new Set();
          const receipts = requested.filter((entry) => {
            if (seen.has(entry.line.id)) {
              throw new common_1.BadRequestException("Each order line can only appear once in a receipt.");
            }
            seen.add(entry.line.id);
            if (entry.quantity.lt(0)) {
              throw new common_1.BadRequestException("Received quantities cannot be negative.");
            }
            const outstanding = entry.line.quantityOrdered.minus(entry.line.quantityReceived);
            if (entry.quantity.gt(outstanding)) {
              throw new common_1.BadRequestException(`Only ${outstanding.toFixed(2)} of ${entry.line.description} is still outstanding on ${order.orderNumber}.`);
            }
            return entry.quantity.gt(0);
          });
          if (receipts.length === 0) {
            throw new common_1.BadRequestException("Enter a quantity received for at least one line.");
          }
          for (const { line } of receipts) {
            if (!line.inventoryItemId || !line.inventoryItem || !line.inventoryItem.active) {
              throw new common_1.BadRequestException(`${line.description} is no longer an active material and cannot be received into stock.`);
            }
          }
          const receiptValue = receipts.reduce((sum, { line, quantity }) => sum.plus(quantity.mul(line.unitCost)), ZERO);
          const journal = await this.postReceiptJournal(tx, user, propertyId, order, receiptValue, businessDate, deliveryNote);
          for (const { line, quantity } of receipts) {
            await (0, stock_receipt_1.applyStockReceipt)(tx, {
              propertyId,
              itemId: line.inventoryItemId,
              locationId: mainStore.id,
              quantity,
              unitCost: line.unitCost,
              businessDate,
              sourceType: "PURCHASE_ORDER",
              sourceId: order.id,
              journalEntryId: journal?.id ?? null,
              actor: (0, stock_ledger_1.stockActor)(user),
              auditAction: "purchase_receipt",
              reason: `Purchase order ${order.orderNumber}${deliveryNote ? `, delivery note ${deliveryNote}` : ""}`
            });
            await tx.purchaseOrderLine.update({
              where: { id: line.id },
              data: { quantityReceived: line.quantityReceived.plus(quantity) }
            });
          }
          const refreshedLines = await tx.purchaseOrderLine.findMany({ where: { purchaseOrderId: order.id } });
          const fullyReceived = refreshedLines.every((line) => line.quantityReceived.gte(line.quantityOrdered));
          const updated = await tx.purchaseOrder.update({
            where: { id: order.id },
            data: {
              status: fullyReceived ? client_1.PurchaseOrderStatus.RECEIVED : client_1.PurchaseOrderStatus.PARTIALLY_RECEIVED,
              receivedAt: /* @__PURE__ */ new Date()
            },
            include: orderInclude
          });
          return { order: updated, previousStatus: order.status, receipts, receiptValue, journal };
        }, { timeout: 2e4 });
        await this.audit.record({
          organizationId: user.organizationId,
          propertyId,
          userId: user.userId,
          module: "purchasing",
          action: "receive_purchase_order",
          recordType: "purchase_order",
          recordId: result.order.id,
          previousValue: { status: result.previousStatus },
          newValue: {
            status: result.order.status,
            location: mainStore.code,
            deliveryNote,
            receiptValue: result.receiptValue.toFixed(2),
            journalEntryNumber: result.journal?.entryNumber ?? null,
            lines: result.receipts.map(({ line, quantity }) => ({
              lineId: line.id,
              itemId: line.inventoryItemId,
              quantity: quantity.toFixed(4),
              unitCost: line.unitCost.toFixed(4)
            }))
          }
        });
        return {
          order: mapOrder(result.order),
          receiptValue: Number(result.receiptValue),
          journalEntryNumber: result.journal?.entryNumber ?? null,
          journalPosted: Boolean(result.journal)
        };
      }
      async recordInvoice(user, orderId, dto) {
        const propertyId = this.requireProperty(user);
        const invoiceNumber = dto.invoiceNumber.trim();
        const subtotal = new client_1.Prisma.Decimal(dto.subtotal);
        const taxTotal = new client_1.Prisma.Decimal(dto.taxTotal || "0");
        const invoiceDate = parseDateOnly(dto.invoiceDate, "Invoice date");
        const dueDate = dto.dueDate ? parseDateOnly(dto.dueDate, "Due date") : null;
        if (!invoiceNumber) {
          throw new common_1.BadRequestException("Supplier invoice number is required.");
        }
        if (subtotal.lt(0) || taxTotal.lt(0)) {
          throw new common_1.BadRequestException("Invoice amounts cannot be negative.");
        }
        if (dueDate && dueDate < invoiceDate) {
          throw new common_1.BadRequestException("Due date cannot be before the invoice date.");
        }
        const result = await this.prisma.$transaction(async (tx) => {
          await tx.$executeRaw`SELECT 1 FROM purchase_orders WHERE id = ${orderId}::uuid AND property_id = ${propertyId}::uuid FOR UPDATE`;
          const order = await this.findOrder(tx, propertyId, orderId);
          if (order.status !== client_1.PurchaseOrderStatus.PARTIALLY_RECEIVED && order.status !== client_1.PurchaseOrderStatus.RECEIVED) {
            throw new common_1.ConflictException(`${order.orderNumber} is ${statusLabel(order.status)}. Record supplier invoices after goods have been received.`);
          }
          const duplicate = await tx.supplierInvoice.findFirst({
            where: {
              propertyId,
              supplierId: order.supplierId,
              invoiceNumber: { equals: invoiceNumber, mode: "insensitive" },
              status: { not: client_1.SupplierInvoiceStatus.VOID }
            }
          });
          if (duplicate) {
            throw new common_1.ConflictException(`Invoice ${invoiceNumber} from ${order.supplier.name} has already been recorded.`);
          }
          const receivedValue = receivedValueOf(order);
          const previouslyInvoiced = order.supplierInvoices.filter((invoice2) => invoice2.status !== client_1.SupplierInvoiceStatus.VOID).reduce((sum, invoice2) => sum.plus(invoice2.subtotal), ZERO);
          const uninvoicedReceived = receivedValue.minus(previouslyInvoiced);
          const variance2 = subtotal.minus(uninvoicedReceived);
          const matched = variance2.abs().lte(MATCH_TOLERANCE);
          const exceedsOrder = previouslyInvoiced.plus(subtotal).gt(order.subtotal.plus(MATCH_TOLERANCE));
          const invoice = await tx.supplierInvoice.create({
            data: {
              propertyId,
              supplierId: order.supplierId,
              purchaseOrderId: order.id,
              invoiceNumber,
              invoiceDate,
              dueDate,
              status: matched ? client_1.SupplierInvoiceStatus.MATCHED : client_1.SupplierInvoiceStatus.DRAFT,
              subtotal,
              taxTotal,
              grandTotal: subtotal.plus(taxTotal)
            }
          });
          let updatedOrder = order;
          if (matched && order.status === client_1.PurchaseOrderStatus.RECEIVED) {
            updatedOrder = await tx.purchaseOrder.update({
              where: { id: order.id },
              data: { status: client_1.PurchaseOrderStatus.CLOSED },
              include: orderInclude
            });
          } else {
            updatedOrder = await this.findOrder(tx, propertyId, order.id);
          }
          return { invoice, order: updatedOrder, previousStatus: order.status, receivedValue, uninvoicedReceived, variance: variance2, matched, exceedsOrder };
        }, { timeout: 2e4 });
        await this.audit.record({
          organizationId: user.organizationId,
          propertyId,
          userId: user.userId,
          module: "purchasing",
          action: result.matched ? "record_supplier_invoice" : "record_supplier_invoice_variance",
          recordType: "supplier_invoice",
          recordId: result.invoice.id,
          previousValue: { orderStatus: result.previousStatus },
          newValue: {
            orderNumber: result.order.orderNumber,
            invoiceNumber: result.invoice.invoiceNumber,
            subtotal: result.invoice.subtotal.toFixed(2),
            taxTotal: result.invoice.taxTotal.toFixed(2),
            expectedSubtotal: result.uninvoicedReceived.toFixed(2),
            variance: result.variance.toFixed(2),
            status: result.invoice.status,
            orderStatus: result.order.status
          }
        });
        const variance = Number(result.variance);
        return {
          invoice: mapInvoice(result.invoice),
          order: mapOrder(result.order),
          match: {
            matched: result.matched,
            expectedSubtotal: Number(result.uninvoicedReceived),
            invoicedSubtotal: Number(result.invoice.subtotal),
            variance,
            exceedsOrder: result.exceedsOrder,
            message: result.matched ? `Invoice matches goods received (${result.uninvoicedReceived.toFixed(2)}).` : `Variance of ${result.variance.toFixed(2)}: invoice ${variance > 0 ? "is higher" : "is lower"} than goods received not yet invoiced (${result.uninvoicedReceived.toFixed(2)}). Held for review.`
          }
        };
      }
      async transitionOrder(user, orderId, action, allowedFrom, data) {
        const propertyId = this.requireProperty(user);
        const order = await this.findOrder(this.prisma, propertyId, orderId);
        if (!allowedFrom.includes(order.status)) {
          throw new common_1.ConflictException(`${order.orderNumber} is ${statusLabel(order.status)} and cannot be changed this way.`);
        }
        const changed = await this.prisma.purchaseOrder.updateMany({
          where: { id: order.id, propertyId, status: order.status },
          data
        });
        if (changed.count !== 1) {
          throw new common_1.ConflictException(`${order.orderNumber} was changed by someone else. Refresh and try again.`);
        }
        const updated = await this.findOrder(this.prisma, propertyId, order.id);
        await this.audit.record({
          organizationId: user.organizationId,
          propertyId,
          userId: user.userId,
          module: "purchasing",
          action,
          recordType: "purchase_order",
          recordId: order.id,
          previousValue: { status: order.status },
          newValue: { status: updated.status, orderNumber: updated.orderNumber }
        });
        return mapOrder(updated);
      }
      /**
       * Dr Inventory (1400) / Cr Accounts Payable (2100) for the value received. Only posted when the
       * property has both accounts and an open financial period covering the business date; otherwise
       * the receipt still goes through and finance can journal it manually.
       */
      async postReceiptJournal(tx, user, propertyId, order, amount, businessDate, deliveryNote) {
        if (amount.lte(0)) {
          return null;
        }
        const [period, accounts] = await Promise.all([
          tx.financialPeriod.findFirst({
            where: {
              propertyId,
              status: client_1.FinancialPeriodStatus.OPEN,
              startDate: { lte: businessDate },
              endDate: { gte: businessDate }
            },
            orderBy: { startDate: "desc" }
          }),
          tx.account.findMany({
            where: {
              organizationId: user.organizationId,
              active: true,
              accountCode: { in: [INVENTORY_ACCOUNT_CODE, ACCOUNTS_PAYABLE_ACCOUNT_CODE] },
              OR: [{ propertyId }, { propertyId: null }]
            }
          })
        ]);
        const pick = (code) => accounts.find((account) => account.accountCode === code && account.propertyId === propertyId) ?? accounts.find((account) => account.accountCode === code);
        const inventoryAccount = pick(INVENTORY_ACCOUNT_CODE);
        const payableAccount = pick(ACCOUNTS_PAYABLE_ACCOUNT_CODE);
        if (!period || !inventoryAccount || !payableAccount) {
          return null;
        }
        const amountText = amount.toFixed(4);
        try {
          (0, journal_balancer_1.validateBalancedJournal)([
            { accountCode: INVENTORY_ACCOUNT_CODE, debitAmount: amountText },
            { accountCode: ACCOUNTS_PAYABLE_ACCOUNT_CODE, creditAmount: amountText }
          ]);
        } catch (error) {
          if (error instanceof journal_balancer_1.JournalValidationError) {
            throw new common_1.BadRequestException(error.message);
          }
          throw error;
        }
        const receiptCount = await tx.journalEntry.count({
          where: { propertyId, sourceType: "PURCHASE_RECEIPT", sourceId: order.id }
        });
        const sequence = receiptCount + 1;
        const description = `Goods received on ${order.orderNumber} from ${order.supplier.name}${deliveryNote ? ` (${deliveryNote})` : ""}`;
        return tx.journalEntry.create({
          data: {
            propertyId,
            financialPeriodId: period.id,
            entryNumber: `GRN-${order.orderNumber}-${sequence}`,
            sourceType: "PURCHASE_RECEIPT",
            sourceId: order.id,
            sourceNumber: order.orderNumber,
            status: client_1.JournalStatus.POSTED,
            idempotencyKey: `purchase-receipt:${order.id}:${sequence}`,
            postedAt: /* @__PURE__ */ new Date(),
            lines: {
              create: [
                { accountId: inventoryAccount.id, debitAmount: amount, description },
                { accountId: payableAccount.id, creditAmount: amount, description }
              ]
            }
          }
        });
      }
      async findOrder(tx, propertyId, orderId) {
        const order = await tx.purchaseOrder.findFirst({
          where: { id: orderId, propertyId },
          include: orderInclude
        });
        if (!order) {
          throw new common_1.NotFoundException("Purchase order was not found.");
        }
        return order;
      }
      async ensureMainStore(propertyId) {
        const label = shared_1.storeAccess.find((store) => store.locationCode === MAIN_STORE_CODE)?.label ?? "Main Store";
        return this.prisma.inventoryLocation.upsert({
          where: { propertyId_code: { propertyId, code: MAIN_STORE_CODE } },
          update: {},
          create: { propertyId, code: MAIN_STORE_CODE, name: label, locationType: "STORE" }
        });
      }
      requireProperty(user) {
        if (!user.propertyId) {
          throw new common_1.BadRequestException("A property context is required.");
        }
        return user.propertyId;
      }
    };
    exports.PurchasingService = PurchasingService;
    exports.PurchasingService = PurchasingService = __decorate([
      (0, common_1.Injectable)(),
      __metadata("design:paramtypes", [
        prisma_service_1.PrismaService,
        audit_service_1.AuditService
      ])
    ], PurchasingService);
    function receivedValueOf(order) {
      return order.lines.reduce((sum, line) => sum.plus(line.quantityReceived.mul(line.unitCost)), ZERO);
    }
    function mapSupplier(supplier) {
      return {
        id: supplier.id,
        code: supplier.supplierCode,
        name: supplier.name,
        email: supplier.email,
        phone: supplier.phone,
        taxNumber: supplier.taxNumber,
        paymentTerms: supplier.paymentTerms,
        status: supplier.status
      };
    }
    function mapInvoice(invoice) {
      return {
        id: invoice.id,
        invoiceNumber: invoice.invoiceNumber,
        invoiceDate: dateOnlyIso(invoice.invoiceDate),
        dueDate: invoice.dueDate ? dateOnlyIso(invoice.dueDate) : null,
        status: invoice.status,
        subtotal: Number(invoice.subtotal),
        taxTotal: Number(invoice.taxTotal),
        grandTotal: Number(invoice.grandTotal),
        paidTotal: Number(invoice.paidTotal)
      };
    }
    function mapOrder(order) {
      const receivedValue = receivedValueOf(order);
      const invoicedValue = order.supplierInvoices.filter((invoice) => invoice.status !== client_1.SupplierInvoiceStatus.VOID).reduce((sum, invoice) => sum.plus(invoice.subtotal), ZERO);
      const variance = order.supplierInvoices.length ? invoicedValue.minus(receivedValue) : ZERO;
      return {
        id: order.id,
        orderNumber: order.orderNumber,
        status: order.status,
        supplierId: order.supplierId,
        supplierName: order.supplier.name,
        orderedAt: order.orderedAt.toISOString(),
        expectedAt: order.expectedAt ? dateOnlyIso(order.expectedAt) : null,
        approvedAt: order.approvedAt?.toISOString() ?? null,
        receivedAt: order.receivedAt?.toISOString() ?? null,
        subtotal: Number(order.subtotal),
        taxTotal: Number(order.taxTotal),
        grandTotal: Number(order.grandTotal),
        receivedValue: Number(receivedValue),
        invoicedValue: Number(invoicedValue),
        variance: Number(variance),
        hasVariance: variance.abs().gt(MATCH_TOLERANCE) || order.supplierInvoices.some((invoice) => invoice.status === client_1.SupplierInvoiceStatus.DRAFT),
        notes: order.notes,
        lines: order.lines.map((line) => ({
          id: line.id,
          inventoryItemId: line.inventoryItemId,
          itemName: line.inventoryItem?.name ?? line.description,
          sku: line.inventoryItem?.sku ?? null,
          unit: line.inventoryItem?.unitOfMeasure ?? "EA",
          description: line.description,
          quantityOrdered: Number(line.quantityOrdered),
          quantityReceived: Number(line.quantityReceived),
          outstanding: Number(client_1.Prisma.Decimal.max(line.quantityOrdered.minus(line.quantityReceived), 0)),
          unitCost: Number(line.unitCost),
          taxAmount: Number(line.taxAmount),
          totalAmount: Number(line.totalAmount)
        })),
        invoices: order.supplierInvoices.map(mapInvoice)
      };
    }
    function nextNumber(prefix, last) {
      const current = last ? Number.parseInt(last.slice(prefix.length), 10) : 0;
      const next = Number.isFinite(current) ? current + 1 : 1;
      return `${prefix}${String(next).padStart(4, "0")}`;
    }
    function statusLabel(status) {
      return status.toLowerCase().replace(/_/g, " ");
    }
    async function withUniqueRetry(operation, attempts = 5) {
      for (let attempt = 1; ; attempt += 1) {
        try {
          return await operation();
        } catch (error) {
          const isUniqueConflict = error instanceof client_1.Prisma.PrismaClientKnownRequestError && error.code === "P2002";
          if (!isUniqueConflict || attempt >= attempts) {
            throw error;
          }
        }
      }
    }
    function parseDateOnly(value, label) {
      const match = /^(\d{4})-(\d{2})-(\d{2})/.exec(value);
      if (!match) {
        throw new common_1.BadRequestException(`${label} must be in YYYY-MM-DD format.`);
      }
      return new Date(Date.UTC(Number(match[1]), Number(match[2]) - 1, Number(match[3])));
    }
    function dateOnlyIso(value) {
      return value.toISOString().slice(0, 10);
    }
    function todayDateOnly() {
      const now = /* @__PURE__ */ new Date();
      return new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()));
    }
    function round2(value) {
      return Math.round(value * 100) / 100;
    }
  }
});

// apps/api/dist/modules/purchasing/purchasing.controller.js
var require_purchasing_controller = __commonJS({
  "apps/api/dist/modules/purchasing/purchasing.controller.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = exports && exports.__metadata || function(k, v) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var __param = exports && exports.__param || function(paramIndex, decorator) {
      return function(target, key) {
        decorator(target, key, paramIndex);
      };
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.PurchasingController = void 0;
    var common_1 = __require("@nestjs/common");
    var current_user_decorator_1 = require_current_user_decorator();
    var require_permissions_decorator_1 = require_require_permissions_decorator();
    var create_purchase_order_dto_1 = require_create_purchase_order_dto();
    var create_supplier_dto_1 = require_create_supplier_dto();
    var receive_purchase_order_dto_1 = require_receive_purchase_order_dto();
    var record_supplier_invoice_dto_1 = require_record_supplier_invoice_dto();
    var purchasing_service_1 = require_purchasing_service();
    var PurchasingController = class PurchasingController {
      purchasing;
      constructor(purchasing) {
        this.purchasing = purchasing;
      }
      overview(user) {
        return this.purchasing.getOverview(user);
      }
      createSupplier(user, dto) {
        return this.purchasing.createSupplier(user, dto);
      }
      createOrder(user, dto) {
        return this.purchasing.createOrder(user, dto);
      }
      submitOrder(user, id) {
        return this.purchasing.submitOrder(user, id);
      }
      approveOrder(user, id) {
        return this.purchasing.approveOrder(user, id);
      }
      cancelOrder(user, id) {
        return this.purchasing.cancelOrder(user, id);
      }
      receiveOrder(user, id, dto) {
        return this.purchasing.receiveOrder(user, id, dto);
      }
      recordInvoice(user, id, dto) {
        return this.purchasing.recordInvoice(user, id, dto);
      }
    };
    exports.PurchasingController = PurchasingController;
    __decorate([
      (0, require_permissions_decorator_1.RequirePermissions)("purchasing.view"),
      (0, common_1.Get)("overview"),
      __param(0, (0, current_user_decorator_1.CurrentUser)()),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", [Object]),
      __metadata("design:returntype", void 0)
    ], PurchasingController.prototype, "overview", null);
    __decorate([
      (0, require_permissions_decorator_1.RequirePermissions)("purchasing.view"),
      (0, common_1.Post)("suppliers"),
      __param(0, (0, current_user_decorator_1.CurrentUser)()),
      __param(1, (0, common_1.Body)()),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", [Object, create_supplier_dto_1.CreateSupplierDto]),
      __metadata("design:returntype", void 0)
    ], PurchasingController.prototype, "createSupplier", null);
    __decorate([
      (0, require_permissions_decorator_1.RequirePermissions)("purchasing.view"),
      (0, common_1.Post)("orders"),
      __param(0, (0, current_user_decorator_1.CurrentUser)()),
      __param(1, (0, common_1.Body)()),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", [Object, create_purchase_order_dto_1.CreatePurchaseOrderDto]),
      __metadata("design:returntype", void 0)
    ], PurchasingController.prototype, "createOrder", null);
    __decorate([
      (0, require_permissions_decorator_1.RequirePermissions)("purchasing.view"),
      (0, common_1.Post)("orders/:id/submit"),
      __param(0, (0, current_user_decorator_1.CurrentUser)()),
      __param(1, (0, common_1.Param)("id", common_1.ParseUUIDPipe)),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", [Object, String]),
      __metadata("design:returntype", void 0)
    ], PurchasingController.prototype, "submitOrder", null);
    __decorate([
      (0, require_permissions_decorator_1.RequirePermissions)("purchasing.view"),
      (0, common_1.Post)("orders/:id/approve"),
      __param(0, (0, current_user_decorator_1.CurrentUser)()),
      __param(1, (0, common_1.Param)("id", common_1.ParseUUIDPipe)),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", [Object, String]),
      __metadata("design:returntype", void 0)
    ], PurchasingController.prototype, "approveOrder", null);
    __decorate([
      (0, require_permissions_decorator_1.RequirePermissions)("purchasing.view"),
      (0, common_1.Post)("orders/:id/cancel"),
      __param(0, (0, current_user_decorator_1.CurrentUser)()),
      __param(1, (0, common_1.Param)("id", common_1.ParseUUIDPipe)),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", [Object, String]),
      __metadata("design:returntype", void 0)
    ], PurchasingController.prototype, "cancelOrder", null);
    __decorate([
      (0, require_permissions_decorator_1.RequirePermissions)("purchasing.view", "inventory.store.main"),
      (0, common_1.Post)("orders/:id/receive"),
      __param(0, (0, current_user_decorator_1.CurrentUser)()),
      __param(1, (0, common_1.Param)("id", common_1.ParseUUIDPipe)),
      __param(2, (0, common_1.Body)()),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", [Object, String, receive_purchase_order_dto_1.ReceivePurchaseOrderDto]),
      __metadata("design:returntype", void 0)
    ], PurchasingController.prototype, "receiveOrder", null);
    __decorate([
      (0, require_permissions_decorator_1.RequirePermissions)("purchasing.view"),
      (0, common_1.Post)("orders/:id/invoices"),
      __param(0, (0, current_user_decorator_1.CurrentUser)()),
      __param(1, (0, common_1.Param)("id", common_1.ParseUUIDPipe)),
      __param(2, (0, common_1.Body)()),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", [Object, String, record_supplier_invoice_dto_1.RecordSupplierInvoiceDto]),
      __metadata("design:returntype", void 0)
    ], PurchasingController.prototype, "recordInvoice", null);
    exports.PurchasingController = PurchasingController = __decorate([
      (0, common_1.Controller)("purchasing"),
      __metadata("design:paramtypes", [purchasing_service_1.PurchasingService])
    ], PurchasingController);
  }
});

// apps/api/dist/modules/purchasing/purchasing.module.js
var require_purchasing_module = __commonJS({
  "apps/api/dist/modules/purchasing/purchasing.module.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.PurchasingModule = void 0;
    var common_1 = __require("@nestjs/common");
    var audit_module_1 = require_audit_module();
    var purchasing_controller_1 = require_purchasing_controller();
    var purchasing_service_1 = require_purchasing_service();
    var PurchasingModule = class PurchasingModule {
    };
    exports.PurchasingModule = PurchasingModule;
    exports.PurchasingModule = PurchasingModule = __decorate([
      (0, common_1.Module)({
        imports: [audit_module_1.AuditModule],
        controllers: [purchasing_controller_1.PurchasingController],
        providers: [purchasing_service_1.PurchasingService]
      })
    ], PurchasingModule);
  }
});

// apps/api/dist/modules/reports/reports.service.js
var require_reports_service = __commonJS({
  "apps/api/dist/modules/reports/reports.service.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = exports && exports.__metadata || function(k, v) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.ReportsService = void 0;
    var common_1 = __require("@nestjs/common");
    var client_1 = __require("@prisma/client");
    var prisma_service_1 = require_prisma_service();
    var ReportsService = class ReportsService {
      prisma;
      constructor(prisma) {
        this.prisma = prisma;
      }
      async dailyReports(user, date) {
        const propertyId = this.requireProperty(user);
        const reportDate = parseReportDate(date);
        const nextDate = new Date(reportDate);
        nextDate.setUTCDate(nextDate.getUTCDate() + 1);
        const [roomChart, posOrders] = await Promise.all([
          this.roomChartReport(propertyId),
          this.posReport(propertyId, reportDate, nextDate)
        ]);
        return {
          date: reportDate.toISOString().slice(0, 10),
          generatedAt: (/* @__PURE__ */ new Date()).toISOString(),
          roomChart,
          pos: posOrders
        };
      }
      async roomChartReport(propertyId) {
        const rooms = await this.prisma.room.findMany({
          where: { propertyId, active: true },
          include: {
            floor: true,
            roomType: true,
            reservationRooms: {
              where: {
                status: {
                  in: [client_1.ReservationStatus.CONFIRMED, client_1.ReservationStatus.CHECKED_IN]
                },
                reservation: {
                  status: {
                    in: [client_1.ReservationStatus.CONFIRMED, client_1.ReservationStatus.CHECKED_IN]
                  }
                }
              },
              include: {
                reservation: {
                  include: {
                    primaryGuest: true,
                    folios: {
                      where: {
                        status: client_1.FolioStatus.OPEN
                      },
                      orderBy: {
                        openedAt: "desc"
                      },
                      take: 1
                    }
                  }
                }
              },
              orderBy: { createdAt: "desc" }
            }
          },
          orderBy: { roomNumber: "asc" }
        });
        const rows = rooms.map((room) => {
          const assignedRoom = room.reservationRooms.find((entry) => entry.reservation.status === client_1.ReservationStatus.CHECKED_IN) ?? room.reservationRooms.find((entry) => entry.reservation.status === client_1.ReservationStatus.CONFIRMED) ?? null;
          const reservation = assignedRoom?.reservation ?? null;
          const folio = reservation?.folios[0] ?? null;
          return {
            roomNumber: room.roomNumber,
            roomType: room.roomType.name,
            floor: room.floor?.name ?? "",
            occupancyStatus: room.occupancyStatus,
            housekeepingStatus: room.housekeepingStatus,
            maintenanceStatus: room.maintenanceStatus,
            guestName: reservation ? `${reservation.primaryGuest.firstName} ${reservation.primaryGuest.lastName}` : "",
            reservationNumber: reservation?.reservationNumber ?? "",
            arrivalDate: reservation?.arrivalDate ?? null,
            departureDate: reservation?.departureDate ?? null,
            folioNumber: folio?.folioNumber ?? "",
            balance: folio ? money(folio.balance) : "0.00"
          };
        });
        const occupied = rows.filter((room) => room.occupancyStatus === "OCCUPIED").length;
        const reserved = rows.filter((room) => room.occupancyStatus === "RESERVED").length;
        const available = rows.filter((room) => room.occupancyStatus === "AVAILABLE").length;
        const dirty = rows.filter((room) => room.housekeepingStatus === "DIRTY").length;
        const outOfService = rows.filter((room) => room.maintenanceStatus !== "AVAILABLE").length;
        const balance = rows.reduce((sum, room) => sum.plus(room.balance), new client_1.Prisma.Decimal(0));
        return {
          summary: {
            totalRooms: rows.length,
            occupied,
            reserved,
            available,
            dirty,
            outOfService,
            occupancyPercent: rows.length ? Math.round(occupied / rows.length * 100) : 0,
            openBalance: money(balance)
          },
          rows
        };
      }
      async posReport(propertyId, reportDate, nextDate) {
        const orders = await this.prisma.posOrder.findMany({
          where: {
            propertyId,
            createdAt: {
              gte: reportDate,
              lt: nextDate
            }
          },
          include: {
            items: {
              include: {
                productVariant: {
                  include: {
                    product: {
                      include: {
                        category: true
                      }
                    }
                  }
                }
              }
            },
            outlet: true,
            payments: true,
            table: true,
            terminal: true
          },
          orderBy: { createdAt: "asc" }
        });
        const outletTotals = /* @__PURE__ */ new Map();
        const paymentTotals = /* @__PURE__ */ new Map();
        const sellerTotals = /* @__PURE__ */ new Map();
        let grossSales = new client_1.Prisma.Decimal(0);
        let paidSales = new client_1.Prisma.Decimal(0);
        let taxTotal = new client_1.Prisma.Decimal(0);
        const rows = orders.map((order) => {
          const paidTotal = order.payments.filter((payment) => payment.status === client_1.PaymentStatus.COMPLETED).reduce((sum, payment) => sum.plus(payment.amount), new client_1.Prisma.Decimal(0));
          const itemCount = order.items.reduce((sum, item) => sum + Number(item.quantity), 0);
          if (order.status !== client_1.PosOrderStatus.VOID) {
            grossSales = grossSales.plus(order.grandTotal);
            paidSales = paidSales.plus(paidTotal);
            taxTotal = taxTotal.plus(order.taxTotal);
            outletTotals.set(order.outlet.name, (outletTotals.get(order.outlet.name) ?? new client_1.Prisma.Decimal(0)).plus(order.grandTotal));
            const sellerKey = order.createdByUserId ?? "not-recorded";
            const seller = sellerTotals.get(sellerKey) ?? { name: order.createdByName ?? NOT_RECORDED, orders: 0, amount: new client_1.Prisma.Decimal(0) };
            seller.orders += 1;
            seller.amount = seller.amount.plus(order.grandTotal);
            sellerTotals.set(sellerKey, seller);
          }
          for (const payment of order.payments) {
            if (payment.status !== client_1.PaymentStatus.COMPLETED)
              continue;
            paymentTotals.set(payment.paymentMethod, (paymentTotals.get(payment.paymentMethod) ?? new client_1.Prisma.Decimal(0)).plus(payment.amount));
          }
          return {
            orderNumber: order.orderNumber,
            outletName: order.outlet.name,
            terminalName: order.terminal?.name ?? "",
            tableNumber: order.table?.tableNumber ?? "",
            serviceType: order.serviceType,
            status: order.status,
            itemCount,
            subtotal: money(order.subtotal),
            taxTotal: money(order.taxTotal),
            grandTotal: money(order.grandTotal),
            paidTotal: money(paidTotal),
            createdAt: order.createdAt,
            // Original seller; unchanged when someone else edits the order or collects payment.
            soldBy: order.createdByName ?? NOT_RECORDED,
            lastEditedBy: order.lastEditedAt ? order.lastEditedByName ?? NOT_RECORDED : null,
            voidedBy: order.status === client_1.PosOrderStatus.VOID ? order.voidedByName ?? NOT_RECORDED : null,
            voidReason: order.voidReason,
            payments: order.payments.filter((payment) => payment.status === client_1.PaymentStatus.COMPLETED).map((payment) => ({
              collectedBy: payment.collectedByName ?? NOT_RECORDED,
              method: payment.paymentMethod,
              amount: money(payment.amount),
              receiptNumber: payment.systemReceiptNumber,
              externalReceiptNumber: payment.externalReceiptNumber,
              externalReference: payment.externalReference
            })),
            items: order.items.map((item) => ({
              name: item.productVariant.product.name,
              variant: item.productVariant.name,
              category: item.productVariant.product.category?.name ?? "",
              quantity: item.quantity.toString(),
              totalAmount: money(item.totalAmount)
            }))
          };
        });
        return {
          summary: {
            orderCount: orders.length,
            grossSales: money(grossSales),
            paidSales: money(paidSales),
            taxTotal: money(taxTotal),
            averageOrder: orders.length ? money(grossSales.div(orders.length)) : "0.00"
          },
          outletTotals: [...outletTotals.entries()].map(([name, amount]) => ({ name, amount: money(amount) })),
          paymentTotals: [...paymentTotals.entries()].map(([method, amount]) => ({ method, amount: money(amount) })),
          sellerTotals: [...sellerTotals.values()].sort((a, b) => b.amount.comparedTo(a.amount)).map((seller) => ({ name: seller.name, orders: seller.orders, amount: money(seller.amount) })),
          rows
        };
      }
      requireProperty(user) {
        if (!user.propertyId) {
          throw new common_1.BadRequestException("A property context is required.");
        }
        return user.propertyId;
      }
    };
    exports.ReportsService = ReportsService;
    exports.ReportsService = ReportsService = __decorate([
      (0, common_1.Injectable)(),
      __metadata("design:paramtypes", [prisma_service_1.PrismaService])
    ], ReportsService);
    function parseReportDate(value) {
      const datePart = value?.slice(0, 10) || (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
      const date = /* @__PURE__ */ new Date(`${datePart}T00:00:00.000Z`);
      if (Number.isNaN(date.getTime())) {
        throw new common_1.BadRequestException("Report date is invalid.");
      }
      return date;
    }
    var NOT_RECORDED = "Not recorded";
    function money(value) {
      return new client_1.Prisma.Decimal(value).toFixed(2);
    }
  }
});

// apps/api/dist/modules/reports/reports.controller.js
var require_reports_controller = __commonJS({
  "apps/api/dist/modules/reports/reports.controller.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = exports && exports.__metadata || function(k, v) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var __param = exports && exports.__param || function(paramIndex, decorator) {
      return function(target, key) {
        decorator(target, key, paramIndex);
      };
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.ReportsController = void 0;
    var common_1 = __require("@nestjs/common");
    var current_user_decorator_1 = require_current_user_decorator();
    var require_permissions_decorator_1 = require_require_permissions_decorator();
    var reports_service_1 = require_reports_service();
    var ReportsController = class ReportsController {
      reports;
      constructor(reports) {
        this.reports = reports;
      }
      dailyReports(user, date) {
        return this.reports.dailyReports(user, date);
      }
    };
    exports.ReportsController = ReportsController;
    __decorate([
      (0, require_permissions_decorator_1.RequirePermissions)("reports.view"),
      (0, common_1.Get)("daily"),
      __param(0, (0, current_user_decorator_1.CurrentUser)()),
      __param(1, (0, common_1.Query)("date")),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", [Object, String]),
      __metadata("design:returntype", void 0)
    ], ReportsController.prototype, "dailyReports", null);
    exports.ReportsController = ReportsController = __decorate([
      (0, common_1.Controller)("reports"),
      __metadata("design:paramtypes", [reports_service_1.ReportsService])
    ], ReportsController);
  }
});

// apps/api/dist/modules/reports/reports.module.js
var require_reports_module = __commonJS({
  "apps/api/dist/modules/reports/reports.module.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.ReportsModule = void 0;
    var common_1 = __require("@nestjs/common");
    var reports_controller_1 = require_reports_controller();
    var reports_service_1 = require_reports_service();
    var ReportsModule = class ReportsModule {
    };
    exports.ReportsModule = ReportsModule;
    exports.ReportsModule = ReportsModule = __decorate([
      (0, common_1.Module)({
        controllers: [reports_controller_1.ReportsController],
        providers: [reports_service_1.ReportsService]
      })
    ], ReportsModule);
  }
});

// apps/api/dist/modules/setup/dto/run-setup.dto.js
var require_run_setup_dto = __commonJS({
  "apps/api/dist/modules/setup/dto/run-setup.dto.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = exports && exports.__metadata || function(k, v) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.RunSetupDto = void 0;
    var class_validator_1 = __require("class-validator");
    var RunSetupDto = class {
      hotelName;
      currencyCode;
      currencySymbol;
      adminFullName;
      adminEmail;
      adminPassword;
      setupKey;
    };
    exports.RunSetupDto = RunSetupDto;
    __decorate([
      (0, class_validator_1.IsString)(),
      (0, class_validator_1.MinLength)(2),
      (0, class_validator_1.MaxLength)(120),
      __metadata("design:type", String)
    ], RunSetupDto.prototype, "hotelName", void 0);
    __decorate([
      (0, class_validator_1.Matches)(/^[A-Z]{3}$/, { message: "Currency code must be a 3-letter code such as TZS or USD." }),
      __metadata("design:type", String)
    ], RunSetupDto.prototype, "currencyCode", void 0);
    __decorate([
      (0, class_validator_1.IsString)(),
      (0, class_validator_1.MinLength)(1),
      (0, class_validator_1.MaxLength)(8),
      __metadata("design:type", String)
    ], RunSetupDto.prototype, "currencySymbol", void 0);
    __decorate([
      (0, class_validator_1.IsString)(),
      (0, class_validator_1.MinLength)(1),
      (0, class_validator_1.MaxLength)(120),
      __metadata("design:type", String)
    ], RunSetupDto.prototype, "adminFullName", void 0);
    __decorate([
      (0, class_validator_1.IsEmail)(),
      __metadata("design:type", String)
    ], RunSetupDto.prototype, "adminEmail", void 0);
    __decorate([
      (0, class_validator_1.IsString)(),
      (0, class_validator_1.MinLength)(8),
      __metadata("design:type", String)
    ], RunSetupDto.prototype, "adminPassword", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsString)(),
      __metadata("design:type", String)
    ], RunSetupDto.prototype, "setupKey", void 0);
  }
});

// apps/api/dist/modules/setup/default-catalog.js
var require_default_catalog = __commonJS({
  "apps/api/dist/modules/setup/default-catalog.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.kitchenStoreItems = exports.barDrinksMenu = exports.dailyBuffetMenu = exports.defaultMenu = exports.defaultRoomFloors = exports.defaultRoomType = void 0;
    exports.menuSku = menuSku;
    exports.dailyMenuSku = dailyMenuSku;
    exports.barDrinkSku = barDrinkSku;
    exports.defaultRoomType = { code: "STD", name: "Standard Room", baseOccupancy: 1, maxOccupancy: 2 };
    function roomRange(from, to, pad) {
      return Array.from({ length: to - from + 1 }, (_, index) => String(from + index).padStart(pad, "0"));
    }
    exports.defaultRoomFloors = [
      { name: "Ground Floor", sortOrder: 0, rooms: roomRange(5, 13, 3) },
      { name: "First Floor", sortOrder: 1, rooms: roomRange(101, 110, 3) },
      { name: "Second Floor", sortOrder: 2, rooms: roomRange(201, 210, 3) },
      { name: "Rooms 1-4", sortOrder: 3, rooms: roomRange(1, 4, 1) }
    ];
    exports.defaultMenu = [
      {
        category: "Buffet",
        skuPrefix: "BUF",
        // Full buffet: complimentary glass of wine, one soft drink and bottled water included.
        items: [["Buffet", 4e4, 15]]
      },
      {
        category: "Soups",
        skuPrefix: "SOUP",
        items: [
          ["Zesty Spicy Broccoli", 6e3, 3],
          ["Creamy Pumpkin and Leek Potage", 6e3, 3],
          ["Forest Mushroom Cream", 6e3, 3],
          ["Rustic Chicken and Vegetable Broth", 6e3, 3]
        ]
      },
      {
        category: "Appetizers",
        skuPrefix: "APP",
        items: [
          ["Chicken Nuggets", 6e3, 3],
          ["Bruschetta Classica", 6e3, 3]
        ]
      },
      {
        category: "Chicken Lovers",
        skuPrefix: "CHK",
        items: [
          ["Paprika Honey Soy Wings", 25e3, 10],
          ["Garlic and Herb Crispy Chicken", 25e3, 10],
          ["Coconut Infused Roast Chicken", 25e3, 10],
          ["Mixed Veggies Chicken Steak", 25e3, 10],
          ["Chargrilled Chicken Steak", 25e3, 10]
        ]
      },
      {
        category: "Beef Corner",
        skuPrefix: "BEEF",
        items: [
          ["Creamy Beef Fillet Strips", 2e4, 8],
          ["African Spiced Roast Beef", 2e4, 8],
          ["Swahili Grilled Beef", 2e4, 8]
        ]
      },
      {
        category: "Salads",
        skuPrefix: "SAL",
        items: [
          ["Coleslaw Salad", 1e4, 5],
          ["Garden Fresh Salad", 1e4, 5],
          ["Tropical Mango Cilantro", 1e4, 5],
          ["Avocado Bliss", 1e4, 5],
          ["Tropical Fruits Salad", 1e4, 5],
          ["Swahili Salad", 1e4, 5]
        ]
      },
      {
        category: "Desserts",
        skuPrefix: "DES",
        items: [
          ["Red Velvet Cake", 16e3, 7],
          ["Chocolate Cake", 16e3, 7],
          ["Lemon Cake", 16e3, 7]
        ]
      },
      {
        category: "Hot Beverages",
        skuPrefix: "HOT",
        items: [
          ["Ginger Tea", 5e3, 2],
          ["Tea Masala", 5e3, 2],
          ["Black Tea", 5e3, 2],
          ["Herbal Tea", 5e3, 2]
        ]
      },
      {
        category: "Oven Pizza",
        skuPrefix: "PIZ",
        items: [
          ["Margherita Pizza", 25e3, 10],
          ["Mediterranean Pizza", 28e3, 12],
          ["Four Season Pizza (Artichoke, Mushrooms)", 25e3, 10],
          ["BBQ Chicken Pizza", 25e3, 10]
        ]
      },
      {
        category: "Pasta",
        skuPrefix: "PAS",
        items: [
          ["Creamy Coconut Chicken Pasta", 15e3, 6],
          ["Savory Beef and Vegetable Pasta", 15e3, 6],
          ["Chef's Seasonal Vegetable Pasta", 15e3, 6]
        ]
      },
      {
        category: "Tanzania Local Menu",
        skuPrefix: "LOC",
        items: [
          ["Fries and Sausage", 1e4, 5],
          ["Chips Mayai", 1e4, 5],
          ["Chips Vuruga", 15e3, 6],
          ["Kisinia Pilau (4 portions)", 45e3, 18]
        ]
      },
      {
        category: "Side Dishes",
        skuPrefix: "SIDE",
        items: [
          ["Plain Ugali", 5e3, 2],
          ["Fluffy White Rice", 5e3, 2],
          ["Fried Fries", 5e3, 2],
          ["Pasta (Side)", 5e3, 2],
          ["Creamy Mashed Potatoes", 5e3, 2],
          ["Fried Plantains", 2e3, 1]
        ]
      },
      {
        category: "Vegetarian Options",
        skuPrefix: "VEG",
        items: [
          ["Creamy Peas", 1e4, 5],
          ["Seasonal Creamy Veggies", 1e4, 5],
          ["Creamy Green Beans", 1e4, 5],
          ["Spicy Lentils in Coconut Sauce", 1e4, 5]
        ]
      }
    ];
    function menuSku(section, index) {
      return `${section.skuPrefix}-${String(index + 1).padStart(2, "0")}`;
    }
    var SUN = 0;
    var MON = 1;
    var TUE = 2;
    var WED = 3;
    var THU = 4;
    var FRI = 5;
    var SAT = 6;
    exports.dailyBuffetMenu = [
      {
        category: "Buffet Appetizers",
        skuPrefix: "BDA",
        items: [
          ["Creamy Mushroom Soup", 6e3, 3, [SUN, TUE]],
          ["Pumpkin Soup", 6e3, 3, [MON, SAT]],
          ["Broccoli Soup", 6e3, 3, [WED]],
          ["Zesty Spicy Broccoli Soup (with bread rolls)", 6e3, 3, [THU]],
          ["Creamy Pumpkin and Leeks Potage Soup", 6e3, 3, [FRI]]
        ]
      },
      {
        category: "Buffet Protein & Starch",
        skuPrefix: "BDP",
        items: [
          ["Chicken BBQ", 2e4, 8, [SUN]],
          ["BBQ Chicken Drums", 2e4, 8, [TUE]],
          ["Marinated Roasted Beef Strips", 2e4, 8, [SUN, TUE]],
          ["Fried Rice", 5e3, 2, [SUN, TUE]],
          ["Wedges Fries", 5e3, 2, [SUN, TUE]],
          ["Grilled Chicken Steak", 2e4, 8, [MON, SAT]],
          ["Beef Strips in Sauce", 2e4, 8, [MON, SAT]],
          ["Plain Rice", 5e3, 2, [MON, SAT]],
          ["Chips", 5e3, 2, [MON, SAT]],
          ["Goat BBQ", 2e4, 8, [WED]],
          ["Roasted Chicken Steak", 2e4, 8, [WED]],
          ["Veggie Spaghetti", 5e3, 2, [WED]],
          ["French Fries", 5e3, 2, [WED]],
          ["Paprika Honey Soy Wings", 25e3, 10, [THU]],
          ["Creamy Beef Fillet Strips", 2e4, 8, [THU]],
          ["Mashed Potatoes", 5e3, 2, [THU]],
          ["Chef Seasonal Veggie Pasta", 15e3, 6, [THU]],
          ["Mixed Veggies Chicken Steak", 25e3, 10, [FRI]],
          ["Swahili Grilled Beef", 2e4, 8, [FRI]],
          ["Vegetable Rice", 5e3, 2, [FRI]],
          ["Chips Mayai", 8e3, 3, [FRI]]
        ]
      },
      {
        category: "Buffet Veggies & Salads",
        skuPrefix: "BDV",
        items: [
          ["Chef Choice (Veggies)", 1e4, 4, [SUN, MON, TUE, WED, THU, FRI, SAT]],
          ["Roasted Carrots", 1e4, 4, [SUN, TUE]],
          ["Sauteed Spinach", 1e4, 4, [SUN, TUE]],
          ["Greek Salad", 1e4, 4, [SUN]],
          ["Greek Salad", 1e4, 5, [TUE]],
          ["Mango Salsa", 1e4, 4, [SUN]],
          ["Mango Salsa", 1e4, 5, [TUE]],
          ["Spinach", 1e4, 4, [MON, SAT]],
          ["Peas with Coconut", 1e4, 4, [MON, SAT]],
          ["Avocado Salad", 1e4, 4, [MON, SAT]],
          ["Coleslaw Salad", 1e4, 4, [MON, SAT]],
          ["Mixed Veggies", 1e4, 4, [WED]],
          ["Roasted Zucchini", 1e4, 4, [WED]],
          ["Lettuce Salad", 1e4, 4, [WED]],
          ["Swahili Salad", 1e4, 4, [WED]],
          ["Creamy Green Beans", 1e4, 4, [THU]],
          ["Tropical Fruits Salad", 1e4, 4, [THU, FRI]],
          ["Avocado Bliss", 1e4, 4, [THU, FRI]],
          ["Mix Veggies (Broccoli, Cauliflower and Carrots)", 1e4, 4, [FRI]],
          ["Spicy Lentils in Coconut Sauce", 1e4, 4, [FRI]]
        ]
      },
      {
        category: "Buffet Dessert",
        skuPrefix: "BDD",
        items: [
          ["Ice Cream", 1e4, 5, [SUN, TUE]],
          ["Ice Cream", 15e3, 6, [MON, WED, SAT]],
          ["Seasonal Fruits", 15e3, 6, [MON, SAT]],
          ["Chocolate Cake", 15e3, 6, [WED]],
          ["Cake (Red Velvet, Lemon, Chocolate)", 15e3, 6, [THU, FRI]]
        ]
      }
    ];
    function dailyMenuSku(section, index) {
      return `${section.skuPrefix}-${String(index + 1).padStart(2, "0")}`;
    }
    exports.barDrinksMenu = [
      {
        category: "Beers",
        skuPrefix: "BEER",
        items: [
          ["Safari", 5e3],
          ["Castle Lite", 5e3],
          ["Kilimanjaro", 5e3],
          ["Serengeti Lager Kubwa", 5e3],
          ["Serengeti Lite", 5e3],
          ["Heineken Kubwa", 5e3],
          ["Windhoek", 5e3],
          ["Desperados", 5e3]
        ]
      },
      {
        category: "Ciders & Alcoholic Coolers",
        skuPrefix: "CIDR",
        items: [
          ["Savannah Dry", 5e3],
          ["Savanna", 5e3],
          ["Smirnoff Black Ice", 5e3]
        ]
      },
      {
        category: "Spirits",
        skuPrefix: "SPRT",
        items: [
          ["Amarula", 5e4],
          ["Absolut Vodka Ndogo", 2e4],
          ["Ballantine's", 2e4],
          ["Campari", 25e3],
          ["Captain Morgan", 2e4],
          ["Gordon's Ndogo", 2e4],
          ["Grant's Ndogo", 2e4],
          ["J&B Ndogo", 2e4],
          ["Jack Daniel's", 5e4],
          ["Konyagi Kubwa", 15e3],
          ["Konyagi Ndogo", 1e4],
          ["K-Vant Kubwa", 15e3],
          ["K-Vant Ndogo", 1e4],
          ["Smirnoff Vodka Ndogo", 15e3],
          ["Viceroy", 15e3],
          ["Hanson Choice", 1e4],
          ["Gilbey's", 15e3],
          ["Diamond Rock", 15e3],
          ["Bongo Don Ndogo", 1e4],
          ["Black & White Ndogo", 2e4],
          ["Jameson Ndogo", 45e3],
          ["Valuer Ndogo", 15e3],
          ["Jaguar Master", 5e4],
          ["Hennessy", 15e4]
        ]
      },
      {
        category: "Wines",
        skuPrefix: "WINE",
        items: [
          ["Francos Wine", 3e4],
          ["Dodoma Wine", 3e4],
          ["Dompo", 3e4],
          ["Drostdy-Hof Red & White Ndogo", 15e3],
          ["Drostdy-Hof Red & White Kubwa", 3e4],
          ["Image Red Ndogo", 1e4],
          ["Lions Hill White & Red", 3e4],
          ["Mohans Red & White", 3e4],
          ["Pearly Bay Red & White", 3e4],
          ["Personal Red & White", 3e4],
          ["Robertson Red & White", 3e4],
          ["Serengeti Wine", 3e4],
          ["Saint Celine", 3e4],
          ["Four Cousins White & Red", 3e4],
          ["Heaven Champion", 3e4]
        ]
      },
      {
        category: "Soft Drinks & Mixers",
        skuPrefix: "SOFT",
        items: [
          ["Alvaro", 3e3],
          ["Grand Malt", 5e3],
          ["Coca Zero", 3e3],
          ["Pepsi Zero", 3e3],
          ["Bitter Lemon", 3e3],
          ["Coca-Cola", 3e3],
          ["Fanta Black", 3e3],
          ["Fanta Orange", 3e3],
          ["Fanta Passion", 3e3],
          ["Fanta Pineapple", 3e3],
          ["Ginger Ale", 3e3],
          ["Soda Water", 3e3],
          ["Tonic Water", 3e3],
          ["Sparletta", 3e3],
          ["Sprite", 3e3],
          ["Stone Tangawizi", 3e3]
        ]
      },
      {
        category: "Energy Drinks",
        skuPrefix: "ENRG",
        items: [
          ["Red Bull", 5e3],
          ["Switch", 8e3]
        ]
      },
      {
        category: "Juice",
        skuPrefix: "JUIC",
        items: [["Azam Juice", 5e3]]
      },
      {
        category: "Water",
        skuPrefix: "WATR",
        items: [
          ["Sparkling Water", 5e3],
          ["Maji Kubwa", 5e3],
          ["Maji Ndogo", 3e3]
        ]
      },
      {
        category: "Hot Drinks",
        skuPrefix: "HDRK",
        items: [["Coffee", 2e3]]
      }
    ];
    function barDrinkSku(section, index) {
      return `${section.skuPrefix}-${String(index + 1).padStart(2, "0")}`;
    }
    exports.kitchenStoreItems = [
      ["KIT-01", "Chicken Steak", "PCS"],
      ["KIT-02", "Broilers", "PCS"],
      ["KIT-03", "Local Chicken", "PCS"],
      ["KIT-04", "Beef Steak (Fillet)", "KG"],
      ["KIT-05", "Goat Meat (Front Leg)", "KG"],
      ["KIT-06", "Goat Meat (Rear Leg)", "KG"],
      ["KIT-07", "Large Size Tilapia", "PCS"],
      ["KIT-08", "Small Size Tilapia", "PCS"],
      ["KIT-09", "Plantains (Mizuzu)", "PCS"],
      ["KIT-10", "Lamb Meat", "KG"],
      ["KIT-11", "Chicken Wings", "PCS"],
      ["KIT-12", "Ugali Portions", "PORTION"],
      ["KIT-13", "Rice Portions", "PORTION"],
      ["KIT-14", "French Fries Portions", "PORTION"],
      ["KIT-15", "Pasta", "KG"],
      ["KIT-16", "Eggs", "PCS"],
      ["KIT-17", "Sausages", "PCS"],
      ["KIT-18", "Fish Fillets", "PCS"],
      ["KIT-19", "Soup", "PORTION"],
      ["KIT-20", "Pizza", "PCS"],
      ["KIT-21", "Tea", "PORTION"],
      ["KIT-22", "Coffee", "PORTION"],
      ["KIT-23", "Ice Cream", "PORTION"],
      ["KIT-24", "Fresh Juice", "LTR"],
      ["KIT-25", "Cake", "PCS"],
      ["KIT-26", "Milk", "LTR"],
      ["KIT-27", "Salads", "PORTION"]
    ];
  }
});

// apps/api/dist/modules/setup/default-setup.js
var require_default_setup = __commonJS({
  "apps/api/dist/modules/setup/default-setup.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.defaultStoreTypes = exports.defaultNumberingRules = exports.defaultChartOfAccounts = void 0;
    var client_1 = __require("@prisma/client");
    exports.defaultChartOfAccounts = [
      ["1100", "Cash", client_1.AccountType.ASSET, true],
      ["1200", "Bank", client_1.AccountType.ASSET, true],
      ["1300", "Accounts Receivable", client_1.AccountType.ASSET, true],
      ["1400", "Inventory", client_1.AccountType.ASSET, true],
      ["2100", "Accounts Payable", client_1.AccountType.LIABILITY, true],
      ["2200", "Tax Payable", client_1.AccountType.LIABILITY, true],
      ["2300", "Customer Deposits", client_1.AccountType.LIABILITY, true],
      ["3100", "Owner Capital", client_1.AccountType.EQUITY, false],
      ["3200", "Retained Earnings", client_1.AccountType.EQUITY, false],
      ["4100", "Room Revenue", client_1.AccountType.REVENUE, false],
      ["4200", "Restaurant Revenue", client_1.AccountType.REVENUE, false],
      ["4300", "Bar Revenue", client_1.AccountType.REVENUE, false],
      ["4400", "Other Revenue", client_1.AccountType.REVENUE, false],
      ["5100", "Food Cost", client_1.AccountType.COST_OF_SALES, false],
      ["5200", "Beverage Cost", client_1.AccountType.COST_OF_SALES, false],
      ["6100", "Salaries", client_1.AccountType.EXPENSE, false],
      ["6200", "Utilities", client_1.AccountType.EXPENSE, false],
      ["6300", "Repairs", client_1.AccountType.EXPENSE, false],
      ["6400", "Marketing", client_1.AccountType.EXPENSE, false],
      ["6500", "Other Expenses", client_1.AccountType.EXPENSE, false]
    ];
    exports.defaultNumberingRules = {
      reservation: "RES-{YYYY}-{00000}",
      receipt: "RCT-{YYYY}-{00000}",
      invoice: "INV-{YYYY}-{00000}",
      journal: "JRN-{YYYY}-{00000}"
    };
    exports.defaultStoreTypes = { MAIN: "STORE", BAR: "BAR", KITCHEN: "KITCHEN" };
  }
});

// apps/api/dist/modules/setup/setup.service.js
var require_setup_service = __commonJS({
  "apps/api/dist/modules/setup/setup.service.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = exports && exports.__metadata || function(k, v) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var __importDefault = exports && exports.__importDefault || function(mod) {
      return mod && mod.__esModule ? mod : { "default": mod };
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.SetupService = void 0;
    var node_crypto_1 = __require("node:crypto");
    var common_1 = __require("@nestjs/common");
    var config_1 = __require("@nestjs/config");
    var client_1 = __require("@prisma/client");
    var bcryptjs_1 = __importDefault(__require("bcryptjs"));
    var shared_1 = __require("@hms/shared");
    var prisma_service_1 = require_prisma_service();
    var auth_service_1 = require_auth_service();
    var default_catalog_1 = require_default_catalog();
    var default_setup_1 = require_default_setup();
    var setupLockKey = 7301001;
    var SetupService = class SetupService {
      auth;
      config;
      prisma;
      constructor(auth, config2, prisma) {
        this.auth = auth;
        this.config = config2;
        this.prisma = prisma;
      }
      async status() {
        const users = await this.prisma.user.count();
        return {
          needsSetup: users === 0,
          setupKeyRequired: Boolean(this.config.get("HMS_SETUP_KEY"))
        };
      }
      async run(dto, metadata) {
        this.assertSetupKey(dto.setupKey);
        const adminEmail = dto.adminEmail.trim().toLowerCase();
        const passwordHash = await bcryptjs_1.default.hash(dto.adminPassword, 12);
        await this.prisma.$transaction(async (tx) => {
          await tx.$executeRaw`SELECT pg_advisory_xact_lock(${setupLockKey})`;
          if (await tx.user.count() > 0) {
            throw new common_1.ConflictException("This system is already set up. Sign in with an existing account.");
          }
          await this.createHotel(tx, dto, adminEmail, passwordHash);
        }, { timeout: 6e4, maxWait: 1e4 });
        return this.auth.login({ email: adminEmail, password: dto.adminPassword }, metadata);
      }
      assertSetupKey(provided) {
        const expected = this.config.get("HMS_SETUP_KEY");
        if (!expected)
          return;
        const a = Buffer.from(provided ?? "");
        const b = Buffer.from(expected);
        if (a.length !== b.length || !(0, node_crypto_1.timingSafeEqual)(a, b)) {
          throw new common_1.ForbiddenException("The setup key is not correct.");
        }
      }
      async createHotel(tx, dto, adminEmail, passwordHash) {
        const hotelName = dto.hotelName.trim();
        const today = startOfUtcDay(/* @__PURE__ */ new Date());
        const organization = await tx.organization.create({
          data: { code: organizationCodeFor(hotelName), name: hotelName }
        });
        const property = await tx.property.create({
          data: {
            organizationId: organization.id,
            code: "MAIN",
            name: hotelName,
            propertySettings: {
              create: {
                currencyCode: dto.currencyCode,
                currencySymbol: dto.currencySymbol.trim(),
                currencyPrecision: 2,
                fiscalYearStart: new Date(Date.UTC(today.getUTCFullYear(), 0, 1)),
                numberingRules: default_setup_1.defaultNumberingRules
              }
            }
          }
        });
        await tx.permission.createMany({ data: [...shared_1.permissions], skipDuplicates: true });
        const permissionIdsByCode = new Map((await tx.permission.findMany()).map((permission) => [permission.code, permission.id]));
        const roleIdsByKey = /* @__PURE__ */ new Map();
        for (const accessLevel of shared_1.roleAccessLevels) {
          const role = await tx.role.create({
            data: {
              organizationId: organization.id,
              propertyId: property.id,
              name: accessLevel.name,
              scope: client_1.RoleScope.PROPERTY
            }
          });
          await tx.rolePermission.createMany({
            data: accessLevel.permissionCodes.map((code) => permissionIdsByCode.get(code)).filter((permissionId) => Boolean(permissionId)).map((permissionId) => ({ roleId: role.id, permissionId })),
            skipDuplicates: true
          });
          roleIdsByKey.set(accessLevel.key, role.id);
        }
        const admin = await tx.user.create({
          data: {
            email: adminEmail,
            passwordHash,
            fullName: dto.adminFullName.trim(),
            organizationId: organization.id,
            defaultPropertyId: property.id
          }
        });
        await tx.userRole.create({
          data: { userId: admin.id, roleId: roleIdsByKey.get("super-admin"), propertyId: property.id }
        });
        await tx.businessDate.create({
          data: { propertyId: property.id, businessDate: today, openedById: admin.id }
        });
        await tx.financialPeriod.create({
          data: {
            propertyId: property.id,
            startDate: new Date(Date.UTC(today.getUTCFullYear(), today.getUTCMonth(), 1)),
            endDate: new Date(Date.UTC(today.getUTCFullYear(), today.getUTCMonth() + 1, 0))
          }
        });
        const accountIdsByCode = /* @__PURE__ */ new Map();
        for (const [accountCode, accountName, accountType, isControlAccount] of default_setup_1.defaultChartOfAccounts) {
          const account = await tx.account.create({
            data: {
              organizationId: organization.id,
              propertyId: property.id,
              accountCode,
              accountName,
              accountType,
              isControlAccount
            }
          });
          accountIdsByCode.set(accountCode, account.id);
        }
        const department = await tx.department.create({
          data: { propertyId: property.id, code: "FNB", name: "Food and Beverage" }
        });
        const outlets = [
          { name: "Restaurant", type: client_1.PosOutletType.RESTAURANT, revenue: "4200", device: "REST-POS-01", drawer: "Main Drawer" },
          { name: "Bar", type: client_1.PosOutletType.BAR, revenue: "4300", device: "BAR-POS-01", drawer: "Bar Drawer" }
        ];
        let restaurantOutletId;
        let barOutletId;
        for (const outlet of outlets) {
          const created = await tx.posOutlet.create({
            data: {
              propertyId: property.id,
              departmentId: department.id,
              name: outlet.name,
              outletType: outlet.type,
              defaultRevenueAccountId: accountIdsByCode.get(outlet.revenue)
            }
          });
          if (outlet.type === client_1.PosOutletType.RESTAURANT)
            restaurantOutletId = created.id;
          if (outlet.type === client_1.PosOutletType.BAR)
            barOutletId = created.id;
          const terminal = await tx.posTerminal.create({
            data: { outletId: created.id, name: `${outlet.name} POS 01`, deviceIdentifier: outlet.device }
          });
          await tx.cashDrawer.create({
            data: { outletId: created.id, terminalId: terminal.id, name: outlet.drawer }
          });
        }
        await tx.productCategory.createMany({
          data: [
            { propertyId: property.id, name: "Food", revenueAccountId: accountIdsByCode.get("4200"), costAccountId: accountIdsByCode.get("5100") },
            { propertyId: property.id, name: "Drinks", revenueAccountId: accountIdsByCode.get("4300"), costAccountId: accountIdsByCode.get("5200") }
          ]
        });
        await this.createRoomsAndMenu(tx, property.id, restaurantOutletId, accountIdsByCode);
        await this.createBarDrinks(tx, property.id, barOutletId, accountIdsByCode);
        await tx.inventoryLocation.createMany({
          data: shared_1.storeAccess.map((store) => ({
            propertyId: property.id,
            code: store.locationCode,
            name: store.label,
            locationType: default_setup_1.defaultStoreTypes[store.locationCode]
          }))
        });
        const kitchen = await tx.inventoryLocation.findUniqueOrThrow({
          where: { propertyId_code: { propertyId: property.id, code: "KITCHEN" } }
        });
        for (const [sku, name, unitOfMeasure] of default_catalog_1.kitchenStoreItems) {
          await tx.inventoryItem.create({
            data: { propertyId: property.id, sku, name, unitOfMeasure, balances: { create: { locationId: kitchen.id } } }
          });
        }
        await tx.auditLog.create({
          data: {
            organizationId: organization.id,
            propertyId: property.id,
            userId: admin.id,
            module: "setup",
            action: "initial_setup",
            recordType: "organization",
            recordId: organization.id,
            newValue: { hotel: hotelName, adminUser: adminEmail, currency: dto.currencyCode }
          }
        });
      }
      // Njiro Legacy bar drinks: a stock item and a stock-tracked Bar menu item per drink (same code).
      async createBarDrinks(tx, propertyId, barOutletId, accountIdsByCode) {
        for (const section of default_catalog_1.barDrinksMenu) {
          const category = await tx.productCategory.create({
            data: {
              propertyId,
              name: section.category,
              revenueAccountId: accountIdsByCode.get("4300"),
              costAccountId: accountIdsByCode.get("5200")
            }
          });
          for (const [index, [name, priceTzs]] of section.items.entries()) {
            const sku = (0, default_catalog_1.barDrinkSku)(section, index);
            await tx.inventoryItem.create({ data: { propertyId, sku, name, unitOfMeasure: "PCS" } });
            await tx.product.create({
              data: {
                propertyId,
                categoryId: category.id,
                name,
                sku,
                productType: client_1.ProductType.STOCKED,
                stockTracked: true,
                variants: {
                  create: {
                    name: "Standard",
                    sku,
                    basePrice: priceTzs,
                    outletProducts: { create: { outletId: barOutletId, price: priceTzs, available: true } }
                  }
                }
              }
            });
          }
        }
      }
      // Njiro Legacy rooms and restaurant menu (TSh and USD prices), see default-catalog.ts.
      async createRoomsAndMenu(tx, propertyId, restaurantOutletId, accountIdsByCode) {
        const roomType = await tx.roomType.create({ data: { propertyId, ...default_catalog_1.defaultRoomType, baseRate: 0 } });
        for (const floorDefinition of default_catalog_1.defaultRoomFloors) {
          const floor = await tx.floor.create({
            data: { propertyId, name: floorDefinition.name, sortOrder: floorDefinition.sortOrder }
          });
          await tx.room.createMany({
            data: floorDefinition.rooms.map((roomNumber) => ({ propertyId, roomTypeId: roomType.id, floorId: floor.id, roomNumber }))
          });
        }
        for (const section of default_catalog_1.defaultMenu) {
          const category = await tx.productCategory.create({
            data: {
              propertyId,
              name: section.category,
              revenueAccountId: accountIdsByCode.get("4200"),
              costAccountId: accountIdsByCode.get(section.category === "Hot Beverages" ? "5200" : "5100")
            }
          });
          for (const [index, [name, priceTzs, priceUsd]] of section.items.entries()) {
            const sku = (0, default_catalog_1.menuSku)(section, index);
            await tx.product.create({
              data: {
                propertyId,
                categoryId: category.id,
                name,
                sku,
                variants: {
                  create: {
                    name: "Standard",
                    sku,
                    basePrice: priceTzs,
                    outletProducts: {
                      create: { outletId: restaurantOutletId, price: priceTzs, priceUsd, available: true }
                    }
                  }
                }
              }
            });
          }
        }
        for (const section of default_catalog_1.dailyBuffetMenu) {
          const category = await tx.productCategory.create({
            data: {
              propertyId,
              name: section.category,
              revenueAccountId: accountIdsByCode.get("4200"),
              costAccountId: accountIdsByCode.get("5100")
            }
          });
          for (const [index, [name, priceTzs, priceUsd, days]] of section.items.entries()) {
            const sku = (0, default_catalog_1.dailyMenuSku)(section, index);
            await tx.product.create({
              data: {
                propertyId,
                categoryId: category.id,
                name,
                sku,
                menuDays: (0, shared_1.normalizeMenuDays)(days),
                variants: {
                  create: {
                    name: "Standard",
                    sku,
                    basePrice: priceTzs,
                    outletProducts: {
                      create: { outletId: restaurantOutletId, price: priceTzs, priceUsd, available: true }
                    }
                  }
                }
              }
            });
          }
        }
      }
    };
    exports.SetupService = SetupService;
    exports.SetupService = SetupService = __decorate([
      (0, common_1.Injectable)(),
      __metadata("design:paramtypes", [
        auth_service_1.AuthService,
        config_1.ConfigService,
        prisma_service_1.PrismaService
      ])
    ], SetupService);
    function startOfUtcDay(date) {
      return new Date(Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate()));
    }
    function organizationCodeFor(name) {
      const code = name.toUpperCase().replace(/[^A-Z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 30);
      return code || "HOTEL";
    }
  }
});

// apps/api/dist/modules/setup/setup.controller.js
var require_setup_controller = __commonJS({
  "apps/api/dist/modules/setup/setup.controller.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = exports && exports.__metadata || function(k, v) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var __param = exports && exports.__param || function(paramIndex, decorator) {
      return function(target, key) {
        decorator(target, key, paramIndex);
      };
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.SetupController = void 0;
    var common_1 = __require("@nestjs/common");
    var public_decorator_1 = require_public_decorator();
    var run_setup_dto_1 = require_run_setup_dto();
    var setup_service_1 = require_setup_service();
    var SetupController = class SetupController {
      setup;
      constructor(setup) {
        this.setup = setup;
      }
      status() {
        return this.setup.status();
      }
      run(dto, ipAddress, userAgent) {
        return this.setup.run(dto, { ipAddress, userAgent });
      }
    };
    exports.SetupController = SetupController;
    __decorate([
      (0, public_decorator_1.Public)(),
      (0, common_1.Get)("status"),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", []),
      __metadata("design:returntype", void 0)
    ], SetupController.prototype, "status", null);
    __decorate([
      (0, public_decorator_1.Public)(),
      (0, common_1.Post)(),
      __param(0, (0, common_1.Body)()),
      __param(1, (0, common_1.Ip)()),
      __param(2, (0, common_1.Headers)("user-agent")),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", [run_setup_dto_1.RunSetupDto, String, String]),
      __metadata("design:returntype", void 0)
    ], SetupController.prototype, "run", null);
    exports.SetupController = SetupController = __decorate([
      (0, common_1.Controller)("setup"),
      __metadata("design:paramtypes", [setup_service_1.SetupService])
    ], SetupController);
  }
});

// apps/api/dist/modules/setup/setup.module.js
var require_setup_module = __commonJS({
  "apps/api/dist/modules/setup/setup.module.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.SetupModule = void 0;
    var common_1 = __require("@nestjs/common");
    var auth_module_1 = require_auth_module();
    var setup_controller_1 = require_setup_controller();
    var setup_service_1 = require_setup_service();
    var SetupModule = class SetupModule {
    };
    exports.SetupModule = SetupModule;
    exports.SetupModule = SetupModule = __decorate([
      (0, common_1.Module)({
        imports: [auth_module_1.AuthModule],
        controllers: [setup_controller_1.SetupController],
        providers: [setup_service_1.SetupService]
      })
    ], SetupModule);
  }
});

// apps/api/dist/common/auth/jwt-auth.guard.js
var require_jwt_auth_guard = __commonJS({
  "apps/api/dist/common/auth/jwt-auth.guard.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = exports && exports.__metadata || function(k, v) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var __importDefault = exports && exports.__importDefault || function(mod) {
      return mod && mod.__esModule ? mod : { "default": mod };
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.JwtAuthGuard = void 0;
    var node_crypto_1 = __require("node:crypto");
    var common_1 = __require("@nestjs/common");
    var core_1 = __require("@nestjs/core");
    var jsonwebtoken_1 = __importDefault(__require("jsonwebtoken"));
    var prisma_service_1 = require_prisma_service();
    var iam_service_1 = require_iam_service();
    var jwt_secret_service_1 = require_jwt_secret_service();
    var public_decorator_1 = require_public_decorator();
    var JwtAuthGuard = class JwtAuthGuard {
      iam;
      jwtSecret;
      prisma;
      reflector;
      constructor(iam, jwtSecret, prisma, reflector) {
        this.iam = iam;
        this.jwtSecret = jwtSecret;
        this.prisma = prisma;
        this.reflector = reflector;
      }
      async canActivate(context) {
        const isPublic = this.reflector.getAllAndOverride(public_decorator_1.IS_PUBLIC_KEY, [
          context.getHandler(),
          context.getClass()
        ]);
        if (isPublic) {
          return true;
        }
        const request = context.switchToHttp().getRequest();
        const token = this.extractBearerToken(request);
        if (!token) {
          throw new common_1.UnauthorizedException("Missing bearer token.");
        }
        const secret = await this.jwtSecret.getSecret();
        let payload;
        try {
          payload = jsonwebtoken_1.default.verify(token, secret);
        } catch {
          throw new common_1.UnauthorizedException("Invalid or expired token.");
        }
        const tokenHash = (0, node_crypto_1.createHash)("sha256").update(token).digest("hex");
        const session = await this.prisma.userSession.findFirst({
          where: {
            id: payload.sid,
            tokenHash,
            revokedAt: null,
            expiresAt: {
              gt: /* @__PURE__ */ new Date()
            }
          },
          include: {
            user: true
          }
        });
        if (!session || session.user.status !== "ACTIVE") {
          throw new common_1.UnauthorizedException("Session is no longer active.");
        }
        const requestedPropertyId = this.getHeaderValue(request, "x-property-id");
        const propertyId = requestedPropertyId ?? session.user.defaultPropertyId ?? void 0;
        const permissions = await this.iam.getPermissionCodes(session.user.id, propertyId);
        request.user = {
          userId: session.user.id,
          sessionId: session.id,
          organizationId: session.user.organizationId,
          propertyId,
          email: session.user.email,
          fullName: session.user.fullName,
          permissions
        };
        return true;
      }
      extractBearerToken(request) {
        const authorization = request.headers.authorization;
        if (!authorization?.startsWith("Bearer ")) {
          return void 0;
        }
        return authorization.slice("Bearer ".length).trim();
      }
      getHeaderValue(request, name) {
        const value = request.headers[name];
        if (Array.isArray(value)) {
          return value[0];
        }
        return value;
      }
    };
    exports.JwtAuthGuard = JwtAuthGuard;
    exports.JwtAuthGuard = JwtAuthGuard = __decorate([
      (0, common_1.Injectable)(),
      __metadata("design:paramtypes", [
        iam_service_1.IamService,
        jwt_secret_service_1.JwtSecretService,
        prisma_service_1.PrismaService,
        core_1.Reflector
      ])
    ], JwtAuthGuard);
  }
});

// apps/api/dist/common/auth/permissions.guard.js
var require_permissions_guard = __commonJS({
  "apps/api/dist/common/auth/permissions.guard.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = exports && exports.__metadata || function(k, v) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.PermissionsGuard = void 0;
    var common_1 = __require("@nestjs/common");
    var core_1 = __require("@nestjs/core");
    var public_decorator_1 = require_public_decorator();
    var require_any_permissions_decorator_1 = require_require_any_permissions_decorator();
    var require_permissions_decorator_1 = require_require_permissions_decorator();
    var PermissionsGuard = class PermissionsGuard {
      reflector;
      constructor(reflector) {
        this.reflector = reflector;
      }
      canActivate(context) {
        const isPublic = this.reflector.getAllAndOverride(public_decorator_1.IS_PUBLIC_KEY, [
          context.getHandler(),
          context.getClass()
        ]);
        if (isPublic) {
          return true;
        }
        const requiredPermissions = this.reflector.getAllAndOverride(require_permissions_decorator_1.PERMISSIONS_KEY, [
          context.getHandler(),
          context.getClass()
        ]);
        const request = context.switchToHttp().getRequest();
        const granted = new Set(request.user?.permissions ?? []);
        const anyPermissions = this.reflector.getAllAndOverride(require_any_permissions_decorator_1.ANY_PERMISSIONS_KEY, [
          context.getHandler(),
          context.getClass()
        ]);
        if (anyPermissions?.length && !anyPermissions.some((permission) => granted.has(permission))) {
          throw new common_1.ForbiddenException(`Missing one of permissions: ${anyPermissions.join(", ")}`);
        }
        const missing = requiredPermissions?.filter((permission) => !granted.has(permission)) ?? [];
        if (missing.length > 0) {
          throw new common_1.ForbiddenException(`Missing permission: ${missing.join(", ")}`);
        }
        return true;
      }
    };
    exports.PermissionsGuard = PermissionsGuard;
    exports.PermissionsGuard = PermissionsGuard = __decorate([
      (0, common_1.Injectable)(),
      __metadata("design:paramtypes", [core_1.Reflector])
    ], PermissionsGuard);
  }
});

// apps/api/dist/common/prisma/prisma.module.js
var require_prisma_module = __commonJS({
  "apps/api/dist/common/prisma/prisma.module.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.PrismaModule = void 0;
    var common_1 = __require("@nestjs/common");
    var jwt_secret_service_1 = require_jwt_secret_service();
    var prisma_service_1 = require_prisma_service();
    var PrismaModule = class PrismaModule {
    };
    exports.PrismaModule = PrismaModule;
    exports.PrismaModule = PrismaModule = __decorate([
      (0, common_1.Global)(),
      (0, common_1.Module)({
        providers: [prisma_service_1.PrismaService, jwt_secret_service_1.JwtSecretService],
        exports: [prisma_service_1.PrismaService, jwt_secret_service_1.JwtSecretService]
      })
    ], PrismaModule);
  }
});

// apps/api/dist/modules/users/dto/create-user.dto.js
var require_create_user_dto = __commonJS({
  "apps/api/dist/modules/users/dto/create-user.dto.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = exports && exports.__metadata || function(k, v) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.CreateUserDto = void 0;
    var class_validator_1 = __require("class-validator");
    var CreateUserDto = class {
      email;
      username;
      fullName;
      password;
      defaultPropertyId;
      roleId;
      permissions;
      homePath;
    };
    exports.CreateUserDto = CreateUserDto;
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsEmail)(),
      __metadata("design:type", String)
    ], CreateUserDto.prototype, "email", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.Matches)(/^[a-z0-9][a-z0-9._-]{2,39}$/i, {
        message: "Username must be 3-40 characters: letters, numbers, dots, dashes or underscores."
      }),
      __metadata("design:type", String)
    ], CreateUserDto.prototype, "username", void 0);
    __decorate([
      (0, class_validator_1.IsString)(),
      (0, class_validator_1.MinLength)(1),
      __metadata("design:type", String)
    ], CreateUserDto.prototype, "fullName", void 0);
    __decorate([
      (0, class_validator_1.IsString)(),
      (0, class_validator_1.MinLength)(8),
      __metadata("design:type", String)
    ], CreateUserDto.prototype, "password", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsUUID)(),
      __metadata("design:type", String)
    ], CreateUserDto.prototype, "defaultPropertyId", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsUUID)(),
      __metadata("design:type", String)
    ], CreateUserDto.prototype, "roleId", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsArray)(),
      (0, class_validator_1.ArrayUnique)(),
      (0, class_validator_1.IsString)({ each: true }),
      __metadata("design:type", Array)
    ], CreateUserDto.prototype, "permissions", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsString)(),
      __metadata("design:type", Object)
    ], CreateUserDto.prototype, "homePath", void 0);
  }
});

// apps/api/dist/modules/users/dto/update-user.dto.js
var require_update_user_dto = __commonJS({
  "apps/api/dist/modules/users/dto/update-user.dto.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = exports && exports.__metadata || function(k, v) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.UpdateUserDto = void 0;
    var class_validator_1 = __require("class-validator");
    var UpdateUserDto = class {
      fullName;
      password;
      status;
      // When sent, these become exactly what the person can access and any role assignment is removed.
      permissions;
      homePath;
    };
    exports.UpdateUserDto = UpdateUserDto;
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsString)(),
      (0, class_validator_1.MinLength)(1),
      __metadata("design:type", String)
    ], UpdateUserDto.prototype, "fullName", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsString)(),
      (0, class_validator_1.MinLength)(8),
      __metadata("design:type", String)
    ], UpdateUserDto.prototype, "password", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsIn)(["ACTIVE", "SUSPENDED"]),
      __metadata("design:type", String)
    ], UpdateUserDto.prototype, "status", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsArray)(),
      (0, class_validator_1.ArrayUnique)(),
      (0, class_validator_1.IsString)({ each: true }),
      __metadata("design:type", Array)
    ], UpdateUserDto.prototype, "permissions", void 0);
    __decorate([
      (0, class_validator_1.IsOptional)(),
      (0, class_validator_1.IsString)(),
      __metadata("design:type", Object)
    ], UpdateUserDto.prototype, "homePath", void 0);
  }
});

// apps/api/dist/modules/users/users.service.js
var require_users_service = __commonJS({
  "apps/api/dist/modules/users/users.service.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = exports && exports.__metadata || function(k, v) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var __importDefault = exports && exports.__importDefault || function(mod) {
      return mod && mod.__esModule ? mod : { "default": mod };
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.UsersService = void 0;
    var common_1 = __require("@nestjs/common");
    var bcryptjs_1 = __importDefault(__require("bcryptjs"));
    var shared_1 = __require("@hms/shared");
    var prisma_service_1 = require_prisma_service();
    var audit_service_1 = require_audit_service();
    var iam_service_1 = require_iam_service();
    var userSelect = {
      id: true,
      email: true,
      username: true,
      fullName: true,
      defaultPropertyId: true,
      homePath: true,
      mfaEnabled: true,
      status: true,
      createdAt: true,
      userPermissions: {
        include: { permission: true }
      },
      userRoles: {
        include: {
          role: {
            include: {
              rolePermissions: {
                include: { permission: true }
              }
            }
          },
          property: true
        }
      }
    };
    var UsersService = class UsersService {
      audit;
      iam;
      prisma;
      constructor(audit, iam, prisma) {
        this.audit = audit;
        this.iam = iam;
        this.prisma = prisma;
      }
      async getMe(user) {
        const record = await this.prisma.user.findUnique({
          where: { id: user.userId },
          select: { username: true, homePath: true }
        });
        return {
          id: user.userId,
          email: user.email,
          username: record?.username ?? null,
          fullName: user.fullName,
          organizationId: user.organizationId,
          propertyId: user.propertyId,
          defaultPropertyId: user.propertyId,
          homePath: record?.homePath ?? null,
          permissions: user.permissions
        };
      }
      async list(organizationId) {
        const users = await this.prisma.user.findMany({
          where: { organizationId },
          select: userSelect,
          orderBy: { fullName: "asc" }
        });
        return users.map(toPublicUser);
      }
      async create(currentUser, dto) {
        const username = dto.username?.trim().toLowerCase() || null;
        const email = dto.email?.trim().toLowerCase() || (username ? `${username}@staff.local` : null);
        if (!email) {
          throw new common_1.BadRequestException("Enter a username or an email address.");
        }
        const existing = await this.prisma.user.findFirst({
          where: { OR: [{ email }, ...username ? [{ username }, { email: username }] : []] }
        });
        if (existing) {
          throw new common_1.ConflictException(username && (existing.username === username || existing.email === username) ? "That username is already taken." : "A user with this email already exists.");
        }
        const permissions = await this.resolveGrantedPermissions(currentUser, dto.permissions ?? []);
        if (!dto.roleId && permissions.length === 0) {
          throw new common_1.BadRequestException("Choose at least one system this person can open.");
        }
        const permissionIds = await this.findPermissionIds(permissions);
        const passwordHash = await bcryptjs_1.default.hash(dto.password, 12);
        const propertyId = dto.defaultPropertyId ?? currentUser.propertyId;
        const created = await this.prisma.user.create({
          data: {
            organizationId: currentUser.organizationId,
            defaultPropertyId: propertyId,
            email,
            username,
            homePath: resolveHomePath(dto.homePath, permissions),
            passwordHash,
            fullName: dto.fullName.trim(),
            userRoles: dto.roleId ? {
              create: {
                roleId: dto.roleId,
                propertyId
              }
            } : void 0,
            userPermissions: permissionIds.length ? { createMany: { data: permissionIds.map((permissionId) => ({ permissionId })) } } : void 0
          },
          select: userSelect
        });
        const result = toPublicUser(created);
        await this.audit.record({
          organizationId: currentUser.organizationId,
          propertyId: created.defaultPropertyId,
          userId: currentUser.userId,
          module: "users",
          action: "create",
          recordType: "user",
          recordId: created.id,
          newValue: auditSnapshot(result)
        });
        return result;
      }
      async update(currentUser, userId, dto) {
        const existing = await this.prisma.user.findFirst({
          where: { id: userId, organizationId: currentUser.organizationId },
          select: userSelect
        });
        if (!existing) {
          throw new common_1.NotFoundException("User not found.");
        }
        const isSelf = existing.id === currentUser.userId;
        const before = toPublicUser(existing);
        let permissions = before.permissions;
        if (dto.permissions !== void 0) {
          const requested = await this.resolveGrantedPermissions(currentUser, dto.permissions);
          const untouchable = before.permissions.filter((code) => !currentUser.permissions.includes(code));
          permissions = [.../* @__PURE__ */ new Set([...requested, ...untouchable])].sort();
          if (permissions.length === 0) {
            throw new common_1.BadRequestException("Choose at least one system this person can open.");
          }
          if (isSelf && !permissions.includes("users.manage")) {
            throw new common_1.BadRequestException("You cannot remove your own user management access.");
          }
        }
        if (isSelf && dto.status === "SUSPENDED") {
          throw new common_1.BadRequestException("You cannot suspend your own account.");
        }
        const homePath = resolveHomePath(dto.homePath !== void 0 ? dto.homePath : existing.homePath, permissions);
        const passwordHash = dto.password ? await bcryptjs_1.default.hash(dto.password, 12) : void 0;
        const permissionIds = dto.permissions !== void 0 ? await this.findPermissionIds(permissions) : null;
        const updated = await this.prisma.$transaction(async (tx) => {
          if (permissionIds) {
            await tx.userRole.deleteMany({ where: { userId } });
            await tx.userPermission.deleteMany({ where: { userId } });
            await tx.userPermission.createMany({ data: permissionIds.map((permissionId) => ({ userId, permissionId })) });
          }
          if (passwordHash || dto.status === "SUSPENDED") {
            await tx.userSession.updateMany({
              where: { userId, revokedAt: null, ...isSelf ? { id: { not: currentUser.sessionId } } : {} },
              data: { revokedAt: /* @__PURE__ */ new Date() }
            });
          }
          return tx.user.update({
            where: { id: userId },
            data: {
              fullName: dto.fullName?.trim() || void 0,
              status: dto.status,
              passwordHash,
              homePath
            },
            select: userSelect
          });
        });
        const result = toPublicUser(updated);
        await this.audit.record({
          organizationId: currentUser.organizationId,
          propertyId: updated.defaultPropertyId,
          userId: currentUser.userId,
          module: "users",
          action: "update",
          recordType: "user",
          recordId: updated.id,
          previousValue: auditSnapshot(before),
          newValue: { ...auditSnapshot(result), passwordChanged: Boolean(passwordHash) }
        });
        return result;
      }
      async resolveGrantedPermissions(currentUser, requested) {
        const known = new Set((await this.iam.listPermissions()).map((permission) => permission.code));
        const codes = new Set(requested.filter((code) => known.has(code)));
        for (const group of shared_1.systemAccessGroups) {
          if (group.actions.some((action) => codes.has(action.code)))
            codes.add(group.viewPermission);
        }
        return [...codes].filter((code) => currentUser.permissions.includes(code)).sort();
      }
      async findPermissionIds(codes) {
        if (codes.length === 0)
          return [];
        const rows = await this.prisma.permission.findMany({ where: { code: { in: codes } }, select: { id: true } });
        return rows.map((row) => row.id);
      }
    };
    exports.UsersService = UsersService;
    exports.UsersService = UsersService = __decorate([
      (0, common_1.Injectable)(),
      __metadata("design:paramtypes", [
        audit_service_1.AuditService,
        iam_service_1.IamService,
        prisma_service_1.PrismaService
      ])
    ], UsersService);
    function resolveHomePath(value, permissions) {
      if (!value)
        return null;
      const group = shared_1.systemAccessGroups.find((entry) => entry.href === value);
      return group && permissions.includes(group.viewPermission) ? group.href : null;
    }
    function toPublicUser(user) {
      const permissions = /* @__PURE__ */ new Set();
      for (const userRole of user.userRoles) {
        for (const rolePermission of userRole.role.rolePermissions)
          permissions.add(rolePermission.permission.code);
      }
      for (const userPermission of user.userPermissions)
        permissions.add(userPermission.permission.code);
      return {
        id: user.id,
        email: user.email,
        username: user.username,
        fullName: user.fullName,
        defaultPropertyId: user.defaultPropertyId,
        homePath: user.homePath,
        mfaEnabled: user.mfaEnabled,
        status: user.status,
        createdAt: user.createdAt,
        customAccess: user.userPermissions.length > 0,
        permissions: [...permissions].sort(),
        userRoles: user.userRoles.map((userRole) => ({
          role: {
            id: userRole.role.id,
            name: userRole.role.name,
            rolePermissions: userRole.role.rolePermissions.map((rolePermission) => ({ permission: rolePermission.permission }))
          },
          property: userRole.property
        }))
      };
    }
    function auditSnapshot(user) {
      return {
        email: user.email,
        username: user.username,
        fullName: user.fullName,
        status: user.status,
        homePath: user.homePath,
        permissions: user.permissions
      };
    }
  }
});

// apps/api/dist/modules/users/users.controller.js
var require_users_controller = __commonJS({
  "apps/api/dist/modules/users/users.controller.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = exports && exports.__metadata || function(k, v) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var __param = exports && exports.__param || function(paramIndex, decorator) {
      return function(target, key) {
        decorator(target, key, paramIndex);
      };
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.UsersController = void 0;
    var common_1 = __require("@nestjs/common");
    var current_user_decorator_1 = require_current_user_decorator();
    var require_permissions_decorator_1 = require_require_permissions_decorator();
    var create_user_dto_1 = require_create_user_dto();
    var update_user_dto_1 = require_update_user_dto();
    var users_service_1 = require_users_service();
    var UsersController = class UsersController {
      users;
      constructor(users) {
        this.users = users;
      }
      getMe(user) {
        return this.users.getMe(user);
      }
      list(user) {
        return this.users.list(user.organizationId);
      }
      create(user, dto) {
        return this.users.create(user, dto);
      }
      update(user, id, dto) {
        return this.users.update(user, id, dto);
      }
    };
    exports.UsersController = UsersController;
    __decorate([
      (0, common_1.Get)("me"),
      __param(0, (0, current_user_decorator_1.CurrentUser)()),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", [Object]),
      __metadata("design:returntype", void 0)
    ], UsersController.prototype, "getMe", null);
    __decorate([
      (0, require_permissions_decorator_1.RequirePermissions)("users.view"),
      (0, common_1.Get)(),
      __param(0, (0, current_user_decorator_1.CurrentUser)()),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", [Object]),
      __metadata("design:returntype", void 0)
    ], UsersController.prototype, "list", null);
    __decorate([
      (0, require_permissions_decorator_1.RequirePermissions)("users.manage"),
      (0, common_1.Post)(),
      __param(0, (0, current_user_decorator_1.CurrentUser)()),
      __param(1, (0, common_1.Body)()),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", [Object, create_user_dto_1.CreateUserDto]),
      __metadata("design:returntype", void 0)
    ], UsersController.prototype, "create", null);
    __decorate([
      (0, require_permissions_decorator_1.RequirePermissions)("users.manage"),
      (0, common_1.Patch)(":id"),
      __param(0, (0, current_user_decorator_1.CurrentUser)()),
      __param(1, (0, common_1.Param)("id", new common_1.ParseUUIDPipe())),
      __param(2, (0, common_1.Body)()),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", [Object, String, update_user_dto_1.UpdateUserDto]),
      __metadata("design:returntype", void 0)
    ], UsersController.prototype, "update", null);
    exports.UsersController = UsersController = __decorate([
      (0, common_1.Controller)("users"),
      __metadata("design:paramtypes", [users_service_1.UsersService])
    ], UsersController);
  }
});

// apps/api/dist/modules/users/users.module.js
var require_users_module = __commonJS({
  "apps/api/dist/modules/users/users.module.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.UsersModule = void 0;
    var common_1 = __require("@nestjs/common");
    var audit_module_1 = require_audit_module();
    var iam_module_1 = require_iam_module();
    var users_controller_1 = require_users_controller();
    var users_service_1 = require_users_service();
    var UsersModule = class UsersModule {
    };
    exports.UsersModule = UsersModule;
    exports.UsersModule = UsersModule = __decorate([
      (0, common_1.Module)({
        imports: [audit_module_1.AuditModule, iam_module_1.IamModule],
        controllers: [users_controller_1.UsersController],
        providers: [users_service_1.UsersService]
      })
    ], UsersModule);
  }
});

// apps/api/dist/app.module.js
var require_app_module = __commonJS({
  "apps/api/dist/app.module.js"(exports) {
    "use strict";
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.AppModule = void 0;
    var common_1 = __require("@nestjs/common");
    var core_1 = __require("@nestjs/core");
    var config_1 = __require("@nestjs/config");
    var accounting_module_1 = require_accounting_module();
    var audit_module_1 = require_audit_module();
    var auth_module_1 = require_auth_module();
    var health_module_1 = require_health_module();
    var front_office_module_1 = require_front_office_module();
    var iam_module_1 = require_iam_module();
    var inventory_module_1 = require_inventory_module();
    var invoices_module_1 = require_invoices_module();
    var organizations_module_1 = require_organizations_module();
    var persistence_module_1 = require_persistence_module();
    var pos_module_1 = require_pos_module();
    var properties_module_1 = require_properties_module();
    var purchasing_module_1 = require_purchasing_module();
    var reports_module_1 = require_reports_module();
    var setup_module_1 = require_setup_module();
    var jwt_auth_guard_1 = require_jwt_auth_guard();
    var permissions_guard_1 = require_permissions_guard();
    var prisma_module_1 = require_prisma_module();
    var users_module_1 = require_users_module();
    var AppModule = class AppModule {
    };
    exports.AppModule = AppModule;
    exports.AppModule = AppModule = __decorate([
      (0, common_1.Module)({
        imports: [
          config_1.ConfigModule.forRoot({ isGlobal: true }),
          prisma_module_1.PrismaModule,
          iam_module_1.IamModule,
          auth_module_1.AuthModule,
          front_office_module_1.FrontOfficeModule,
          inventory_module_1.InventoryModule,
          invoices_module_1.InvoicesModule,
          pos_module_1.PosModule,
          users_module_1.UsersModule,
          organizations_module_1.OrganizationsModule,
          properties_module_1.PropertiesModule,
          purchasing_module_1.PurchasingModule,
          persistence_module_1.PersistenceModule,
          reports_module_1.ReportsModule,
          setup_module_1.SetupModule,
          accounting_module_1.AccountingModule,
          audit_module_1.AuditModule,
          health_module_1.HealthModule
        ],
        providers: [
          {
            provide: core_1.APP_GUARD,
            useClass: jwt_auth_guard_1.JwtAuthGuard
          },
          {
            provide: core_1.APP_GUARD,
            useClass: permissions_guard_1.PermissionsGuard
          }
        ]
      })
    ], AppModule);
  }
});

// apps/api/dist/create-app.js
var require_create_app = __commonJS({
  "apps/api/dist/create-app.js"(exports) {
    "use strict";
    var __createBinding = exports && exports.__createBinding || (Object.create ? (function(o, m, k, k2) {
      if (k2 === void 0) k2 = k;
      var desc = Object.getOwnPropertyDescriptor(m, k);
      if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = { enumerable: true, get: function() {
          return m[k];
        } };
      }
      Object.defineProperty(o, k2, desc);
    }) : (function(o, m, k, k2) {
      if (k2 === void 0) k2 = k;
      o[k2] = m[k];
    }));
    var __setModuleDefault = exports && exports.__setModuleDefault || (Object.create ? (function(o, v) {
      Object.defineProperty(o, "default", { enumerable: true, value: v });
    }) : function(o, v) {
      o["default"] = v;
    });
    var __importStar = exports && exports.__importStar || /* @__PURE__ */ (function() {
      var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function(o2) {
          var ar = [];
          for (var k in o2) if (Object.prototype.hasOwnProperty.call(o2, k)) ar[ar.length] = k;
          return ar;
        };
        return ownKeys(o);
      };
      return function(mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) {
          for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        }
        __setModuleDefault(result, mod);
        return result;
      };
    })();
    var __importDefault = exports && exports.__importDefault || function(mod) {
      return mod && mod.__esModule ? mod : { "default": mod };
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.createApiApp = createApiApp2;
    __require("reflect-metadata");
    var helmet_1 = __importDefault(__require("helmet"));
    var common_1 = __require("@nestjs/common");
    var config_1 = __require("@nestjs/config");
    var core_1 = __require("@nestjs/core");
    async function createApiApp2(options = {}) {
      configureDatabaseUrl(options);
      const { AppModule } = await Promise.resolve().then(() => __importStar(require_app_module()));
      const app = await core_1.NestFactory.create(AppModule, {
        logger: options.serverless ? ["error", "warn"] : void 0
      });
      const config2 = app.get(config_1.ConfigService);
      if (options.serverless) {
        app.set("trust proxy", "loopback");
      }
      app.setGlobalPrefix("api");
      app.use((0, helmet_1.default)());
      const webOrigin = config2.get("WEB_ORIGIN");
      const allowedOrigins = webOrigin?.split(",").map((origin) => origin.trim()).filter(Boolean);
      app.enableCors({
        origin: allowedOrigins?.length ? allowedOrigins : true,
        credentials: true
      });
      app.useGlobalPipes(new common_1.ValidationPipe({
        whitelist: true,
        forbidNonWhitelisted: true,
        transform: true
      }));
      return { app, config: config2 };
    }
    function configureDatabaseUrl(options) {
      const netlifyDatabaseUrl = process.env.NETLIFY_DB_URL || process.env.NETLIFY_DATABASE_URL;
      const databaseUrl = netlifyDatabaseUrl || process.env.DATABASE_URL;
      if (!databaseUrl)
        return;
      process.env.DATABASE_URL = options.serverless ? withServerlessPoolSettings(databaseUrl) : databaseUrl;
    }
    function withServerlessPoolSettings(databaseUrl) {
      try {
        const url = new URL(databaseUrl);
        if (!url.searchParams.has("connection_limit"))
          url.searchParams.set("connection_limit", "3");
        if (!url.searchParams.has("pool_timeout"))
          url.searchParams.set("pool_timeout", "20");
        if (!url.searchParams.has("connect_timeout"))
          url.searchParams.set("connect_timeout", "15");
        if (url.hostname.includes("-pooler") && !url.searchParams.has("pgbouncer"))
          url.searchParams.set("pgbouncer", "true");
        return url.toString();
      } catch {
        return databaseUrl;
      }
    }
  }
});

// netlify/functions/api.mjs
var import_create_app = __toESM(require_create_app(), 1);
var { createApiApp } = import_create_app.default;
var hopByHopHeaders = ["connection", "keep-alive", "transfer-encoding", "content-length", "content-encoding", "host"];
var apiOrigin;
function startApi() {
  apiOrigin ??= (async () => {
    const { app } = await createApiApp({ serverless: true });
    await app.listen(0, "127.0.0.1");
    const { port } = app.getHttpServer().address();
    return `http://127.0.0.1:${port}`;
  })().catch((error) => {
    apiOrigin = void 0;
    throw error;
  });
  return apiOrigin;
}
var api_default = async (request, context) => {
  let origin;
  try {
    origin = await startApi();
  } catch (error) {
    console.error("HMS API failed to start", error);
    return Response.json({ statusCode: 503, message: "The hotel system is starting up or the database is unavailable. Try again shortly." }, { status: 503 });
  }
  const url = new URL(request.url);
  const headers = new Headers(request.headers);
  for (const name of hopByHopHeaders) headers.delete(name);
  if (context?.ip) headers.set("x-forwarded-for", context.ip);
  const hasBody = request.method !== "GET" && request.method !== "HEAD";
  const response = await fetch(`${origin}${url.pathname}${url.search}`, {
    method: request.method,
    headers,
    body: hasBody ? await request.arrayBuffer() : void 0,
    redirect: "manual"
  });
  const responseHeaders = new Headers(response.headers);
  for (const name of hopByHopHeaders) responseHeaders.delete(name);
  responseHeaders.set("cache-control", "no-store");
  return new Response(response.body, { status: response.status, headers: responseHeaders });
};
var config = {
  path: "/api/*"
};
export {
  config,
  api_default as default
};
