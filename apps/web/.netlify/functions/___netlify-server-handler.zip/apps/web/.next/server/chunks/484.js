"use strict";exports.id=484,exports.ids=[484],exports.modules={32238:(a,b,c)=>{c.d(b,{D:()=>o});var d=c(78157),e=c(31768),f=c(97452),g=c(95320),h=c(99395),i=c(32410),j=c(27462),k=c(32465),l=c(49170),m=c(69680);let n=new Set(["ROOM_CHARGE","POS_CHARGE","TAX","OTHER","TRANSFER"]);function o({compact:a=!1,initialQuery:b="",initialReservationId:c}){let[o,x]=(0,e.useState)(b),[y,z]=(0,e.useState)([]),[A,B]=(0,e.useState)(""),[C,D]=(0,e.useState)("all"),[E,F]=(0,e.useState)([]),[G,H]=(0,e.useState)("Search a guest name, reservation number, phone, or email."),[I,J]=(0,e.useState)(!1),K=(0,e.useMemo)(()=>y.find(a=>a.id===A)??null,[y,A]),L=(0,e.useMemo)(()=>K?r(K):[],[K]),M=(0,e.useMemo)(()=>{var a,b,c;return a=L,b=C,c=E,"room"===b?a.filter(a=>"ROOM_CHARGE"===a.itemType):"all"===b?a.filter(a=>n.has(a.itemType)):a.filter(a=>c.includes(a.id))},[L,C,E]),N=M.reduce((a,b)=>a+Number(b.totalAmount||0),0);async function O(a){if(a?.preventDefault(),o.trim().length<2)return void H("Enter at least 2 characters to search.");J(!0);let d=await (0,j.A)(`/invoices/reservations?query=${encodeURIComponent(o.trim())}`);if(J(!1),!d.ok)return void H(d.error);z(d.data);let e=c&&o.trim()===b.trim()?d.data.find(a=>a.id===c):d.data[0];B(e?.id??""),F(s(e?r(e):[])),D("all"),H(d.data.length?`${d.data.length} reservation invoice record${1===d.data.length?"":"s"} found.`:"No matching reservations found.")}function P(a){D(a),"room"===a&&F(L.filter(a=>"ROOM_CHARGE"===a.itemType).map(a=>a.id)),"all"===a&&F(s(L))}return(0,d.jsxs)("div",{className:"rounded border border-border bg-white p-4",children:[(0,d.jsxs)("div",{className:"mb-3 flex flex-wrap items-center justify-between gap-3",children:[(0,d.jsxs)("div",{className:"flex items-center gap-2",children:[(0,d.jsx)(f.A,{className:"h-4 w-4 text-primary","aria-hidden":"true"}),(0,d.jsx)("h4",{className:"font-bold",children:"Reservation Invoice"})]}),(0,d.jsxs)(k.E,{children:[M.length," lines"]})]}),(0,d.jsxs)("form",{onSubmit:O,className:a?"grid gap-3":"grid gap-3 sm:grid-cols-[1fr_auto]",children:[(0,d.jsx)(m.p,{"aria-label":"Search invoice guest",value:o,onChange:a=>x(a.target.value),placeholder:"Search guest name, reservation, phone, or email"}),(0,d.jsxs)(l.$,{disabled:I,children:[(0,d.jsx)(g.A,{className:"h-4 w-4","aria-hidden":"true"}),"Search"]})]}),(0,d.jsx)("p",{className:"mt-3 rounded border border-border bg-background/70 px-3 py-2 text-sm text-muted-foreground",children:G}),(0,d.jsxs)("div",{className:a?"mt-4 space-y-4":"mt-4 grid gap-4 xl:grid-cols-[0.85fr_1.15fr]",children:[(0,d.jsxs)("div",{className:"rounded border border-border",children:[(0,d.jsxs)("div",{className:"flex items-center justify-between gap-2 border-b border-border px-3 py-2",children:[(0,d.jsx)("p",{className:"text-sm font-bold",children:"Matches"}),(0,d.jsx)(l.$,{type:"button",variant:"secondary",className:"h-8 px-3",onClick:()=>void O(),disabled:I||o.trim().length<2,children:(0,d.jsx)(h.A,{className:"h-4 w-4","aria-hidden":"true"})})]}),(0,d.jsx)("div",{className:"max-h-72 overflow-auto divide-y divide-border",children:0===y.length?(0,d.jsx)("p",{className:"px-3 py-5 text-sm text-muted-foreground",children:"No invoice search results yet."}):y.map(a=>(0,d.jsxs)("button",{type:"button",className:a.id===A?"block w-full bg-muted px-3 py-3 text-left text-sm":"block w-full px-3 py-3 text-left text-sm hover:bg-muted/70",onClick:()=>{B(a.id),F(s(r(a))),D("all"),H(`${a.reservationNumber} selected for invoice.`)},children:[(0,d.jsx)("p",{className:"font-bold",children:t(a.guest)}),(0,d.jsxs)("p",{className:"text-xs text-muted-foreground",children:[a.reservationNumber," -"," ",a.room?.roomNumber?`Room ${a.room.roomNumber}`:"Room not assigned"]})]},a.id))})]}),(0,d.jsxs)("div",{className:"space-y-3",children:[(0,d.jsxs)("div",{className:"grid gap-2 sm:grid-cols-3",children:[(0,d.jsx)("button",{type:"button",onClick:()=>P("room"),className:"room"===C?p:q,children:"Room only"}),(0,d.jsx)("button",{type:"button",onClick:()=>P("all"),className:"all"===C?p:q,children:"Room + expenses"}),(0,d.jsx)("button",{type:"button",onClick:()=>D("custom"),className:"custom"===C?p:q,children:"Custom"})]}),(0,d.jsxs)("div",{className:"rounded border border-border",children:[(0,d.jsxs)("div",{className:"flex items-center justify-between gap-3 border-b border-border px-3 py-2",children:[(0,d.jsx)("p",{className:"text-sm font-bold",children:K?K.reservationNumber:"Invoice lines"}),(0,d.jsx)("span",{className:"text-sm font-bold tabular-nums",children:v(N)})]}),(0,d.jsx)("div",{className:"max-h-80 overflow-auto divide-y divide-border",children:0===L.length?(0,d.jsx)("p",{className:"px-3 py-5 text-sm text-muted-foreground",children:"Select a reservation to see invoice lines."}):L.map(a=>{let b=M.some(b=>b.id===a.id);return(0,d.jsxs)("label",{className:"flex cursor-pointer items-start gap-3 px-3 py-3 text-sm",children:[(0,d.jsx)("input",{type:"checkbox",className:"mt-1",checked:b,onChange:()=>{var b;return b=a.id,void(D("custom"),F(a=>a.includes(b)?a.filter(a=>a!==b):[...a,b]))}}),(0,d.jsxs)("span",{className:"min-w-0 flex-1",children:[(0,d.jsx)("span",{className:"block font-semibold",children:a.description}),(0,d.jsx)("span",{className:"block text-xs text-muted-foreground",children:a.itemType.replaceAll("_"," ").toLowerCase()})]}),(0,d.jsx)("span",{className:"font-bold tabular-nums",children:v(a.totalAmount)})]},a.id)})})]}),(0,d.jsxs)(l.$,{type:"button",onClick:function(){var a;if(!K||0===M.length)return void H("Select a reservation and at least one invoice line before printing.");let b=`INV-${K.reservationNumber}-${Date.now().toString().slice(-5)}`,c=t(K.guest),d=window.open("","_blank","width=860,height=920");d&&(d.document.write(`
      <!doctype html>
      <html>
        <head>
          <title>${w(b)}</title>
          <style>
            body { font-family: Arial, sans-serif; margin: 34px; color: #111; }
            header { display: flex; justify-content: space-between; gap: 24px; border-bottom: 2px solid #111; padding-bottom: 18px; }
            h1 { margin: 0; font-size: 28px; }
            h2 { margin: 20px 0 8px; font-size: 15px; text-transform: uppercase; letter-spacing: .04em; }
            p { margin: 4px 0; font-size: 13px; }
            table { width: 100%; border-collapse: collapse; margin-top: 18px; font-size: 13px; }
            th { border-bottom: 1px solid #999; padding: 9px 6px; text-align: left; }
            td { border-bottom: 1px solid #ddd; padding: 9px 6px; vertical-align: top; }
            .right { text-align: right; }
            .total { margin-top: 18px; display: flex; justify-content: flex-end; font-size: 18px; font-weight: 700; }
            .total span { min-width: 170px; text-align: right; }
            .muted { color: #555; }
          </style>
        </head>
        <body>
          <header>
            <div>
              <h1>Invoice</h1>
              <p><strong>Njiro Legacy</strong></p>
              <p>Phone: 0677234754</p>
              <p>Email: info@njirolegacy.com</p>
            </div>
            <div class="right">
              <p><strong>${w(b)}</strong></p>
              <p>${w(new Date().toLocaleString())}</p>
              <p>${w("room"===(a=C)?"Room charges only":"all"===a?"Room charges and expenses":"Custom invoice")}</p>
            </div>
          </header>
          <section>
            <h2>Guest</h2>
            <p><strong>${w(c)}</strong></p>
            <p>${w(K.guest.email??K.guest.phone??"")}</p>
            <h2>Reservation</h2>
            <p>${w(K.reservationNumber)} - ${w(K.status)}</p>
            <p>${w(u(K.arrivalDate))} to ${w(u(K.departureDate))}</p>
            <p>${w(K.room?.roomNumber?`Room ${K.room.roomNumber} - ${K.room.roomType}`:K.room?.roomType??"Room not assigned")}</p>
          </section>
          <table>
            <thead>
              <tr>
                <th>Description</th>
                <th>Type</th>
                <th class="right">Qty</th>
                <th class="right">Rate</th>
                <th class="right">Amount</th>
              </tr>
            </thead>
            <tbody>
              ${M.map(a=>`
                    <tr>
                      <td>${w(a.description)}</td>
                      <td>${w(a.itemType.replaceAll("_"," "))}</td>
                      <td class="right">${w(a.quantity)}</td>
                      <td class="right">${w(v(a.unitPrice))}</td>
                      <td class="right">${w(v(a.totalAmount))}</td>
                    </tr>
                  `).join("")}
            </tbody>
          </table>
          <div class="total">Total <span>${w(v(N))}</span></div>
        </body>
      </html>
    `),d.document.close(),d.focus(),d.print(),H(`${b} prepared for printing.`))},disabled:!K||0===M.length,children:[(0,d.jsx)(i.A,{className:"h-4 w-4","aria-hidden":"true"}),"Print invoice"]})]})]})]})}let p="h-10 rounded border border-primary bg-primary px-3 text-sm font-bold text-primary-foreground",q="h-10 rounded border border-border bg-background px-3 text-sm font-bold text-muted-foreground hover:bg-muted";function r(a){let b=a.items.some(a=>"ROOM_CHARGE"===a.itemType),c=a.items.filter(a=>n.has(a.itemType));return!b&&a.projectedRoomCharge?[a.projectedRoomCharge,...c]:c}function s(a){return a.filter(a=>n.has(a.itemType)).map(a=>a.id)}function t(a){return`${a.firstName} ${a.lastName}`.trim()}function u(a){return new Intl.DateTimeFormat("en",{month:"short",day:"numeric",year:"numeric"}).format(new Date(a))}function v(a){let b="number"==typeof a?a:Number(a);return new Intl.NumberFormat("en-US",{style:"currency",currency:"USD",minimumFractionDigits:2}).format(Number.isFinite(b)?b:0)}function w(a){return a.replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;").replaceAll('"',"&quot;").replaceAll("'","&#039;")}},32410:(a,b,c)=>{c.d(b,{A:()=>d});let d=(0,c(81744).A)("Printer",[["path",{d:"M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2",key:"143wyd"}],["path",{d:"M6 9V3a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v6",key:"1itne7"}],["rect",{x:"6",y:"14",width:"12",height:"8",rx:"1",key:"1ue0tg"}]])},69680:(a,b,c)=>{c.d(b,{p:()=>f});var d=c(78157),e=c(10573);function f({className:a,...b}){return(0,d.jsx)("input",{className:(0,e.cn)("h-10 w-full rounded border border-border bg-white px-3 text-sm outline-none transition focus:border-primary focus:ring-2 focus:ring-primary/20",a),...b})}},84457:(a,b,c)=>{c.d(b,{$P:()=>d,Ez:()=>e,vv:()=>f});let d=[{code:"TZS",label:"TSh"},{code:"USD",label:"USD"}];function e(a){return"USD"===a?"USD":"TSh"}function f(a,b){let c="number"==typeof a?a:Number(a),d=Number.isFinite(c)?c:0;return"USD"===b?new Intl.NumberFormat("en-US",{style:"currency",currency:"USD",minimumFractionDigits:2}).format(d):`TSh ${new Intl.NumberFormat("en-US",{maximumFractionDigits:2}).format(d)}`}},95320:(a,b,c)=>{c.d(b,{A:()=>d});let d=(0,c(81744).A)("Search",[["circle",{cx:"11",cy:"11",r:"8",key:"4ej97u"}],["path",{d:"m21 21-4.3-4.3",key:"1qie3q"}]])},97452:(a,b,c)=>{c.d(b,{A:()=>d});let d=(0,c(81744).A)("FileText",[["path",{d:"M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z",key:"1rqfz7"}],["path",{d:"M14 2v4a2 2 0 0 0 2 2h4",key:"tnqrlb"}],["path",{d:"M10 9H8",key:"b1mrlr"}],["path",{d:"M16 13H8",key:"t4e002"}],["path",{d:"M16 17H8",key:"z1uh3a"}]])}};